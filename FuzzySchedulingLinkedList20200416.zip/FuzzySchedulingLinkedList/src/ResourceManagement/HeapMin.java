package ResourceManagement;

import java.util.Random;

import Jobs.FTask;
import Tools.FO;
import element.C;

public class HeapMin {  
    public String[] getVmlist() {
		return vmlist;
	}


	private FTask[] Heap;  
    private String[] vmlist;
    private int maxsize;  
    public FTask[] getHeap() {
		return Heap;
	}


	public int getSize() {
		return size;
	}


	private int size;
  
    public HeapMin(int maxsize) {  
        this.maxsize = maxsize;  
        Heap = new FTask[maxsize];  
        vmlist = new String[maxsize];  
        size = 0;           
    }  
  
  
    private int leftchild(int pos) {  
        return 2 * pos+1;  
    }  
  
  
    private int rightchild(int pos) {  
        return 2 * pos + 2;  
    }  
  
  
    private int parent(int pos) {  
        return (pos-1) / 2;  
    }  
  
  
    private boolean isleaf(int pos) {  
        return ((pos >= size / 2) && (pos < size));  
    }  
  
  
    private void swap(int pos1, int pos2) {  
        FTask tmp;  
        tmp = Heap[pos1];  
        Heap[pos1] = Heap[pos2];  
        Heap[pos2] = tmp;  
        
        String tempvm;
        tempvm = vmlist[pos1];
        vmlist[pos1] = vmlist[pos2];  
        vmlist[pos2] = tempvm;  
    }  
  
  
    public void insert(FTask task,String vmid) {  
        
    	 Heap[size] = task;  
    	 vmlist[size] = vmid;
         int current = size;  
         while (FO.Comparison(Heap[current].getPriority1(), Heap[parent(current)].getPriority1())==C.LESS||
        		 (FO.Comparison(Heap[current].getPriority1(), Heap[parent(current)].getPriority1())==C.EQUARE&&
        		 FO.Comparison(Heap[current].getPriority2(), Heap[parent(current)].getPriority2())==C.LESS)
         ) {  
             swap(current, parent(current));  
             current = parent(current);  
         }  
         size++;  
    	
    	
//        Heap[size] = task;  
//        int current = size; 
//        FuzzyOperation operation=new FuzzyOperation();
//        FuzzyNumber temp=operation.Comparison(Heap[current].getEarliest() , Heap[parent(current)].getEarliest());
////        while (Heap[current].getEarliest() < Heap[parent(current)].getEarliest()) { 
//        while (temp==Heap[parent(current)].getEarliest()) {  
//            swap(current, parent(current));  
//            current = parent(current);  
//        }  
//        size++;  
    }  
  
    
    
  
    public void print() {  
        int i;  
        for (i = 0; i < size; i++)  
            Heap[i].print();  
    }  
  
  
    public FTask removemin() {  
        swap(0, size-1);  
        size--;  
        if (size >0 )  
            pushdown(0);  
        return Heap[size];  
    }  
  
    public boolean isEmpty()
    {
    	if(this.size==0) return true;
    	return false;
    }
//    private void pushdown(int position) {  
//        int smallestchild=0;  
//        FuzzyOperation operation=new FuzzyOperation();
//        FuzzyNumber temp=operation.Comparison(Heap[smallestchild].getEarliest(),Heap[smallestchild + 1].getEarliest());
//        while (!isleaf(position)) {  
//            smallestchild = leftchild(position);  
//            if ((smallestchild < size-1)  
//                    && (temp==Heap[smallestchild].getEarliest()))  
//                smallestchild = smallestchild + 1;  
//            FuzzyNumber temp2=operation.Comparison(Heap[smallestchild].getEarliest(),Heap[position].getEarliest());
//
//            if (temp2==Heap[smallestchild].getEarliest())  
//                return;  
//            swap(position, smallestchild);  
//            position = smallestchild;  
//        }  
//    }  
    
    private void pushdown(int position) {  
        int smallestchild;  
        while (!isleaf(position)) {  
            smallestchild = leftchild(position);  
            if ((smallestchild < size-1)  
                    && (FO.Comparison(Heap[smallestchild].getPriority1(), Heap[smallestchild + 1].getPriority1())==C.MORE ||
                    (FO.Comparison(Heap[smallestchild].getPriority1(), Heap[smallestchild + 1].getPriority1())==C.EQUARE&&
                    FO.Comparison(Heap[smallestchild].getPriority2(), Heap[smallestchild + 1].getPriority2())==C.MORE)))  
                smallestchild = smallestchild + 1;  
            if (FO.Comparison(Heap[position].getPriority1(), Heap[smallestchild].getPriority1())==C.LESS||
            	(FO.Comparison(Heap[position].getPriority1(), Heap[smallestchild].getPriority1())==C.EQUARE&&
            	FO.Comparison(Heap[position].getPriority2(), Heap[smallestchild].getPriority2())==C.LESS))  
                return;  
            swap(position, smallestchild);  
            position = smallestchild;  
        }  
    }  
    
    public void update()
    {
    	for(int i=size-1;i>=0;i--)
    	{
    		if(this.isleaf(i)) continue;
    		pushdown(i);
    	}
    }
  
  
    public static void main(String args[])  
    {  
      
    }  
}

