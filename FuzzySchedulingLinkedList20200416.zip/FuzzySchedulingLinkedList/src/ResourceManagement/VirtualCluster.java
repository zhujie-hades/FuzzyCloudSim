package ResourceManagement;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

import Jobs.FJOBS;
import Jobs.FTask;
import SchedulePlan.FAssignment;
import SchedulePlan.FPlan;
import SchedulePlan.Schedule;
import Tools.FO;
import Tools.CO;
import element.C;
import element.FuzzyNumber;
import element.Parameters;



public class VirtualCluster {

	int stage;
	int m_old;
	int m_new;
	int newindex;
	public int getNewindex() {
		return newindex;
	}

	HashMap<String,VirtualMachine> vmset;
	HashMap<Integer,String> jobMap;//jobid:vmid
	Parameters setting;
	final Slot emptyHead_old;
//	Slot emptyTail_old;
	final Slot emptyHead_new;
//	Slot emptyTail_new;
	
	
	public void CheckingLinkedList()
	{
		this.CheckingLinkedList(this.emptyHead_old);
		this.CheckingLinkedList(this.emptyHead_new);
	}
	
	private void CheckingLinkedList(Slot head)
	{
		if(head==null) return;
		Slot p = head;
		if(!head.getVmid().equalsIgnoreCase("HEAD")) System.out.println("ERROR: headnode is changed");
		ArrayList<Slot> forward = new ArrayList<Slot>();
		while(p!=null)
		{
			forward.add(p);
			p = p.getNextSlot();
		}
		int fsize = forward.size();
		 p = forward.get(fsize-1);	   
		   ArrayList<Slot> backward = new ArrayList<Slot>();
		   while(p!=null)
		   {
			   backward.add(p);
			   p = p.getPreSlot();
		   }
		   int bsize = backward.size();
		for(int i=0;i<fsize-1;i++)
		{
			Slot first = forward.get(i);
			Slot second = forward.get(i+1);
			if(second.getPreSlot()!=first)
			{
				System.out.println("Error checking 1:���ز���һ������ "+first.toString()+"<+"+second.toString()+" secondrealpre="+CO.getSlotString(second.getPreSlot())); 
				for(int k=0;k<fsize;k++) System.out.print(forward.get(k).toString()+"->");
				System.out.println();
				for(int k=bsize-1;k>=0;k--) System.out.print(backward.get(k).toString()+"->");
				System.out.println();
				return;
			}
		}
	
	  
		for(int i=0;i<bsize-1;i++)
		{
			Slot second = backward.get(i);
			Slot first = backward.get(i+1);
			if(first.getNextSlot()!=second)
			{
				System.out.println("Error checking 2:���ز���һ������ "+first.toString()+"+>"+second.toString()+" realnext="+CO.getSlotString(first.getNextSlot())); 
				for(int k=0;k<fsize;k++) System.out.print(forward.get(k).toString()+"->");
				System.out.println();
				for(int k=bsize-1;k>=0;k--) System.out.print(backward.get(k).toString()+"->");
				System.out.println();
				return;
			}
		}
		if(bsize!=fsize)
		{
			System.out.println("Error checking 3:����������һ�� ");
			for(int i=0;i<fsize;i++) System.out.print(forward.get(i).toString()+"->");
			System.out.println();
			for(int i=bsize-1;i>=0;i--) System.out.print(backward.get(i).toString()+"->");
			System.out.println();
		}
	}
	
	public String getOldEmptySlotString()
	{
		String str = "";
		Slot p = this.emptyHead_old;
		while(p!=null)
		{
			str+=p.toString();
			p = p.getNextSlot();
		}
		return str;
	}
	
	public String getNewEmptySlotString()
	{
		String str = "";
		Slot p = this.emptyHead_new;
		while(p!=null)
		{
			str+=p.toString();
			p = p.getNextSlot();
		}
		return str;
	}
	
	public void getChargingOnOnDemandInfor(HashMap<String, ChargingOnOnDemand> charge)
	{
		Iterator<String> it = this.vmset.keySet().iterator();
		while(it.hasNext())
		{
			String mid = it.next();
			if(CO.isNewVM(mid))
			{
				VirtualMachine vm = vmset.get(mid);
				vm.getChargingOnOnDemandInfor(charge);
			}
		}
	}
	
//	public void updateEmptySlotHead(int curT)
//	{
//		
//		Slot p = emptyHead_old.getNextSlot();
//		while(p!=null)
//		{
//			
//			if(FO.Comparison(p.getStart(), p.getEnd())==C.EQUARE)//����Ϊ0��slotҪȥ��
//			{
//				
//					p.getPreSlot().setNextSlot(p.getNextSlot());
//					if(p.getNextSlot()!=null) p.getNextSlot().setPreSlot(p.getPreSlot());
//				
//			}
//
//			p = p.getNextSlot();
//		}
//		
//		p = this.emptyHead_new.getNextSlot();
//		while(p!=null)
//		{
//			
//			if(FO.Comparison(p.getStart(), p.getEnd())==C.EQUARE)//����Ϊ0��slotҪȥ��
//			{
//				
//					p.getPreSlot().setNextSlot(p.getNextSlot());
//					if(p.getNextSlot()!=null) p.getNextSlot().setPreSlot(p.getPreSlot());
//				
//			}
//			p = p.getNextSlot();
//		}
//		
//
//	}
	
	public boolean CheckValidation()
	{
		Iterator<String> it = vmset.keySet().iterator();
		while(it.hasNext())
		{
			String vmid = it.next();
			VirtualMachine vm = vmset.get(vmid);
			if(vm.CheckValidation()==false) return false;
		}
		Slot p = emptyHead_old.getNextSlot();
		Slot pnext = p.getNextSlot();
		while(pnext!=null)
		{
			if(FO.Comparison(p.getStart(), pnext.getStart())==C.MORE)
			{
				System.out.println("ERROR: Empty slots on OLDVM are not ordered");
				
				return false;
			}
			p = pnext;
			pnext = pnext.getNextSlot();
		}
		
		if(FO.Comparison(p.getEnd(), C.Infinity)!=C.EQUARE)
		{
			System.out.println("ERROR: the last slot on OLDVM is not infinite "+p.getEnd().toString());
			return false;
		}
		
		p = emptyHead_new.getNextSlot();
		pnext = null;
		if(p!=null)
		pnext = p.getNextSlot();
		while(pnext!=null)
		{
			if(FO.Comparison(p.getStart(), pnext.getStart())==C.MORE)
			{
				System.out.println("ERROR: Empty slots on NEWVM are not ordered"+p.toString()+pnext.toString());
				return false;
			}
			p = pnext;
			pnext = pnext.getNextSlot();
		}
		
		if(p!=null)
		if(FO.Comparison(p.getEnd(), C.Infinity)!=C.EQUARE)
		{
			System.out.println("ERROR: the last slot on NEWVM is not infinite "+p.getEnd().toString());
			return false;
		}
		
		return true;
	}
	
	public double getDelayPentaly(Schedule schedule,double price)
	{
		Iterator<String> it = vmset.keySet().iterator();
		double result = 0;
		while(it.hasNext())
		{
			String vmid = it.next();
			VirtualMachine vm = vmset.get(vmid);
			result += vm.getDelayPenalty(schedule, price);
		}
		return result;
	}
	
	
	public void computeUtilizationRateInfo(int[] UtilizationRateNum,int[] lowUtilizationUsageTime,int t)
	{
		Iterator<String> it = vmset.keySet().iterator();
		while(it.hasNext())
		{
			String id = it.next();
			VirtualMachine vm = vmset.get(id);
			double urate = vm.getUtilizationRate(t)+0;
			int usageTime = vm.getTotalLengthBefore(t);
			try{
			int index = Integer.parseInt(String.valueOf(urate).substring(2, 3));
			UtilizationRateNum[index]++;
			lowUtilizationUsageTime[index] += usageTime;
			}
			catch(Exception e)
			{
				System.out.println(urate+":"+String.valueOf(urate).substring(2, 3)+" "+vm.getMid());
			}
			
		}		
	}
	
	
	public int gettotalRealUsageDuraionOnRented()//����real assignment�ĳ���
	{
		int totalusagetime = 0;
		Iterator<String> it = vmset.keySet().iterator();
		while(it.hasNext())
		{
			String id = it.next();
			if(id.contains("NEW"))
			{
				VirtualMachine vm = vmset.get(id);
				int usagetime = vm.getTotalRealDuraiton();
				totalusagetime += usagetime;
			}
		}		
		return totalusagetime;
	}
	
	public int gettotalUsageTimeOnRented()//����real assignment�ĳ���
	{
		int totalusagetime = 0;
		Iterator<String> it = vmset.keySet().iterator();
		while(it.hasNext())
		{
			String id = it.next();
			if(id.contains("NEW"))
			{
				VirtualMachine vm = vmset.get(id);
				int usagetime = vm.getTotalUsageTime();
				totalusagetime += usagetime;
			}
		}		
		return totalusagetime;
	}
	

	
//	public double getIdelLength()
//	{
//		if(m_new==0) return 0 ;
//		Iterator<String> it = vmset.keySet().iterator();
//		double result = 0;
//		while(it.hasNext())
//		{
//			String vmid = it.next();
//			if(!CO.isNewVM(vmid)) continue;
//			VirtualMachine vm = vmset.get(vmid);
//			result += vm.getIdleLength();
//		}
//		return result;
//	}
	
	public VirtualMachine getVM(String vmid)
	{
		return vmset.get(vmid);
	}
	
	public Slot getPreFAssignment(Slot fas)
	{
		Slot prefas = fas.getPreSlot();
		return prefas;
	}
	

	
	public String[] getMachineIDList()
	{
		String[] idlist = new String[vmset.size()];
		String[] oldlist = new String[m_old];
		String[] newlist = new String[m_new];
		int oldcount = 0;
		int newcount = 0;
		Iterator<String> it = vmset.keySet().iterator();
		while(it.hasNext())
		{
			String id = it.next();
			if(id.contains("OLD"))
			{
				oldlist[oldcount] = id;
				oldcount++;}
			else
			{
				newlist[newcount] = id;
				newcount++;
			}
		}		
		this.orderMachineIDList(oldlist);
		this.orderMachineIDList(newlist);
		for(int i=0;i<m_old;i++)
		{
			idlist[i] = oldlist[i];
		}
		for(int i=0;i<m_new;i++)
		{
			idlist[i+m_old] = newlist[i];
		}
		return idlist;
	}
	
	private void orderMachineIDList(String[] idlist)
	{
		for(int i=0;i<idlist.length;i++)
		{
			for(int j=i+1;j<idlist.length;j++)
			{				
				int id1 = CO.getMachineNumberID(idlist[i]);
				int id2 = CO.getMachineNumberID(idlist[j]);
				if(id1>id2)
				{
					String temp = idlist[i];
					idlist[i] = idlist[j];
					idlist[j] = temp;
				}
			}
		}
	}
	

	
	public FuzzyNumber getFuzzyMakespan()
	{
		FuzzyNumber makespan = new FuzzyNumber(0,0,0);
		Iterator<String> it = vmset.keySet().iterator();
		while(it.hasNext())
		{
			VirtualMachine vm = vmset.get(it.next());
			FuzzyNumber temp = vm.getFuzzyMakespan();
			if(FO.Comparison(temp, makespan)==1)
				makespan = temp;
		}
		return makespan;
	}
	
	
	
	public int getTotalMachineNum()
	{
		return m_old+m_new;
	}

	
	
	public VirtualMachine FindVM(String mid)
	{
		return this.vmset.get(mid);
	}
	
	

//	public void TrimLinkedList(int arriveTime,Schedule schedule)
//	{
//		Iterator<String> it = this.vmset.keySet().iterator();
//		while(it.hasNext())
//		{
//			String vmid = it.next();
//			VirtualMachine vm = vmset.get(vmid);
//			vm.TrimLinkedList(arriveTime, schedule);
//		}
//		
//	}
	
	public VirtualCluster(int stage,int onpremise,Parameters setting)
	{
		this.stage = stage;
		m_old = onpremise;
		m_new = 0;
		newindex=0;
		this.setting = setting;
		this.emptyHead_old = new Slot("HEAD",C.BelowZero,C.BelowZero);
		this.emptyHead_new = new Slot("HEAD",C.BelowZero,C.BelowZero);
		vmset = new HashMap<String,VirtualMachine>();
		for(int i=0;i<m_old;i++)
		{
			String mid = stage+"_OLD"+String.valueOf(i);
			VirtualMachine mch = new VirtualMachine(mid,this.stage);
			Slot firstslot = mch.initial();
			vmset.put(mid,mch);
			//������ʼoldtree�ϵı��ػ���slotset			
			this.addNewEmptySlottoOld(firstslot);
		}
		jobMap = new HashMap<Integer,String>();
	}
	
	public void addNewEmptySlottoOld(Slot slot)
	{
		
//			emptyTail_old.setNextSlot(slot);
//			slot.setPreSlot(emptyTail_old);
//			emptyTail_old = slot;
			slot.setPreSlot(this.emptyHead_old);
			slot.setNextSlot(emptyHead_old.getNextSlot());
			if(emptyHead_old.getNextSlot()!=null) emptyHead_old.getNextSlot().setPreSlot(slot);
			emptyHead_old.setNextSlot(slot);
			
		
	}
	
	//TODO �½�������Ĳ���
	public void addNewEmptySlottoNew(Slot slot)
	{
		slot.setPreSlot(this.emptyHead_new);
		slot.setNextSlot(emptyHead_new.getNextSlot());
		if(emptyHead_new.getNextSlot()!=null) emptyHead_new.getNextSlot().setPreSlot(slot);
		emptyHead_new.setNextSlot(slot);		
	}
	
	
	
	
	
	
	
	public Slot getEmptyHead_old() {
		return emptyHead_old;
	}

	
	public Slot getEmptyHead_new() {
		return emptyHead_new;
	}

	

//	public HashMap<Integer, String> getJobMap() {
//		return jobMap;
//	}


	public Parameters getSetting() {
		return setting;
	}


	public void setSetting(Parameters setting) {
		this.setting = setting;
	}


	public void setNewindex(int newindex) {
		this.newindex = newindex;
	}

	public HashMap<String,VirtualMachine> getSet() {
		return vmset;
	}
	public void setStage(int stage) {
		this.stage = stage;
	}
	public void setM_old(int m_old) {
		this.m_old = m_old;
	}
	public void setM_new(int m_new) {
		this.m_new = m_new;
	}
//	public void setNewindex(int newindex) {
//		this.newindex = newindex;
//	}
	
	public void printEmptySlot()
	{
		Slot p = this.emptyHead_old;
		
		while(p!=null)
		{
			System.out.print(p.toString()+"-->");
			p = p.getNextSlot();
		}
		System.out.println();
//		p = this.emptyTail_old;
//		while(p!=null)
//		{
//			System.out.print("<--"+p.toString());
//		
//			p = p.getPreSlot();
//		}
//		System.out.println();		
		
		p = this.emptyHead_new;
		while(p!=null)
		{
			System.out.print(p.toString()+"-->");
			p = p.getNextSlot();
		}
		System.out.println();
//		p = this.emptyTail_new;
//		while(p!=null)
//		{
//			System.out.print("<--"+p.toString());
//			p = p.getPreSlot();
//		}
//		System.out.println();
//		System.out.println();
	}
	
	public void print()
	{
		System.out.println("Stage "+stage+" m_old="+m_old+" m_new="+m_new );
		Iterator<String> it = vmset.keySet().iterator();
		while(it.hasNext())
		{
			VirtualMachine vm = vmset.get(it.next());
			vm.print();
			
		}
		
		Slot p = this.emptyHead_old;
		while(p!=null)
		{
			System.out.print(p.toString()+"-->");
			p = p.getNextSlot();
		}
		System.out.println();

		
		p = this.emptyHead_new;
		while(p!=null)
		{
			System.out.print(p.toString()+"-->");
			p = p.getNextSlot();
		}
		System.out.println();

	}

	
	public Slot findArrangement(int jobid)
	{
		Slot result = null;
		String mid = jobMap.get(jobid);
		if(mid!=null)
		{
			if(vmset.get(mid)==null)
			{
				System.out.println(mid);
				System.out.println(jobid);
			}
			result = vmset.get(mid).searchJob(jobid);
		}

		return result;
	}
	
	
	
	public void collectAssignmentAfter(ArrayList<Slot> collection,int arriveTime, int upperbound,Schedule schedule)
	{
		Iterator<String> it = vmset.keySet().iterator();
		while(it.hasNext())
		{
			String mid = it.next();
			VirtualMachine vm = vmset.get(mid);
			vm.collectbyEndTime(collection, arriveTime, upperbound, schedule);
		}
	}
	
	public void removeAssignment(Slot slot,int curTime) 
	{
		 
		 
		String mid = slot.getVmid();
//		if(jobMap.containsKey(slot.getJobid()))
//		{
			this.jobMap.remove(slot.getJobid());
//		}
//		else{
//			System.out.println("Error: remove a unexisted job "+slot.toString());
//		}
		
		VirtualMachine vm = this.vmset.get(mid);
		if(vm==null) System.out.println("vmid="+mid+" slot="+slot.toString());
		  
		vm.removeAssignment(slot,curTime);
		
		if(vm.getJobnum()==0&&CO.isNewVM(mid)) //ɾ���յ���vm
		{
//			System.out.println(mid+" is removed");
			this.removeVM(mid);			
		}
		  
		
	}
	
	public void removeVM(String mid)
	{
		VirtualMachine vm = this.vmset.get(mid);
		if(vm!=null)
		{
			
			if(CO.isNewVM(mid))
			{
				this.vmset.remove(mid);
				this.m_new--;
				Slot p = this.emptyHead_new.getNextSlot();				
				while(p!=null)
				{
					if(p.getVmid().equalsIgnoreCase(mid))
					{
						
							p.getPreSlot().setNextSlot(p.getNextSlot());
							if(p.getNextSlot()!=null)
							p.getNextSlot().setPreSlot(p.getPreSlot());

					}
					p = p.getNextSlot();
				}
			}

		}
		else System.out.println("ERROR: Remove an unexisted VM");
		
	}
	
	public FPlan getRealEarliestStart(FTask task)
	{
		if(FO.Comparison(task.getLength(), 0)==C.EQUARE)
		{
			return new FPlan(task.getEarliest(),FO.Addition(task.getEarliest(), task.getLength()),null);
		}
		FPlan result = FindFirstAvailableSlot(task,this.emptyHead_old);
		if(result==null)
			result = FindFirstAvailableSlot(task,this.emptyHead_new);
		//create new VM	
		if(result==null)
		{
			result = new FPlan(task.getEarliest(),FO.Addition(task.getEarliest(), task.getLength()),null);
		}
	
		return result;
	}
	
	private FPlan FindFirstAvailableSlot(FTask task,Slot head)//�ҵ���һ�����Ⱥ����������翪ʼʱ���slot
	{

		
		FPlan plan = null;
		Slot p = head.getNextSlot();
		while(p!=null)
		{
			//�������Ⱥ��ʵ�slot			
			FuzzyNumber start = FO.Max(p.getStart(), task.getEarliest());
			FuzzyNumber end = FO.Min(p.getEnd(), FO.Addition(task.getLatest(), task.getLength()));
			if(FO.Comparison(FO.Addition(start,task.getLength()),end)!=C.MORE)
			{
				plan = new FPlan(start,FO.Addition(start,task.getLength()),p);
				
				break;
			}
			if(FO.Comparison(p.getStart(), task.getLatest())==C.MORE) break;
			p = p.getNextSlot();
		}
		return plan;
	}
	
	private FPlan FindEarliestSlot(FTask task,Slot head)//�ҵ���һ�����Ⱥ����������翪ʼʱ���slot
	{

		
		FPlan plan = null;
		Slot p = head.getNextSlot();
		while(p!=null)
		{
			//�������Ⱥ��ʵ�slot			
			FuzzyNumber start = FO.Max(p.getStart(), task.getEarliest());
			if(FO.Comparison(FO.Addition(start,task.getLength()),p.getEnd())!=C.MORE)//ֻҪ�ܷ��¾���
			{
				plan = new FPlan(start,FO.Addition(start,task.getLength()),p);
				
				break;
			}
//			if(FO.Comparison(p.getStart(), task.getLatest())==C.MORE) break; ֻҪ�ҵ���һ���ܷ��¾��У������ǽ�ֹ����
			p = p.getNextSlot();
		}
		return plan;
	}
	
	
	public FAssignment Arrangement(FTask task) //���ھɻ������ң��Ҳ������»������ң��Ҳ����½�����
	{		
		FAssignment as = null;	
		boolean harddeadline = true;
		if(FO.Comparison(task.getEarliest(), task.getLatest())==C.MORE)
		{
//			System.out.println("Terrible Error: the task has to be arranged on new VM "+task.toString());
			harddeadline = false;
		}
//		if(FO.Comparison(task.getLength(), 0)==0)
//		{
//			as = new FAssignment(null,task.getEarliest(),task.getJobid(),task.getStage(),task.getEarliest(),task.getLength());
//			return as;
//		}
		if(harddeadline)
		{
			//find feasible slot firstly on old vm
			FPlan fplan = this.FindFirstAvailableSlot(task, this.emptyHead_old);
			if(fplan!=null)
			{
				String vmid = fplan.getPlanslot().getVmid();
//				FuzzyNumber end = FO.Addition(fplan.getPlanstart(),task.getLength());
				as = new FAssignment(vmid,fplan.getPlanstart(),task.getJobid(),task.getStage(),fplan.getPlanend(),task.getLength());
			    //ִ�в������
				VirtualMachine vm = this.vmset.get(vmid);
				int testjobid = 2;
				int teststageid = 0;
				vm.occupySlot(fplan.getPlanslot(), fplan.getPlanstart(), fplan.getPlanend(), task.getJobid());

			}
			else {
				fplan = this.FindFirstAvailableSlot(task, this.emptyHead_new);
				if(fplan!=null)
				{
					String vmid = fplan.getPlanslot().getVmid();
//					FuzzyNumber end = FO.Addition(task.getEarliest(),task.getLength());
					as = new FAssignment(vmid,fplan.getPlanstart(),task.getJobid(),task.getStage(),fplan.getPlanend(),task.getLength());
				    //ִ�в������
					VirtualMachine vm = this.vmset.get(vmid);
					vm.occupySlot(fplan.getPlanslot(), fplan.getPlanstart(), fplan.getPlanend(), task.getJobid());
				}
				else
				{
					VirtualMachine mch = this.addNewM();
					FuzzyNumber end = FO.Addition(task.getEarliest(),task.getLength());
					as = new FAssignment(mch.getMid(),task.getEarliest(),task.getJobid(),task.getStage(),end,task.getLength());			
					mch.occupySlot(mch.getFirstEmptySlot(), task.getEarliest(), end, task.getJobid());
					//�����δ��ռ�ã�����slotû�й���ȥ    
				}		
			}
		}
		else//softdeadline
		{
			//find feasible slot firstly on old vm
			FPlan fplan1 = this.FindEarliestSlot(task, this.emptyHead_old);
			FPlan fplan2 = 	this.FindEarliestSlot(task, this.emptyHead_new);
//			System.out.println(task.toString());
//			System.out.println("fplan1="+fplan1.toString());
//			if(fplan2!=null) System.out.println("fplan2="+fplan2.toString());
			if(fplan1!=null&&fplan2!=null)//���ϻ����϶��ܷŵ��£��ϻ����ȿ�ʼ��ѡ�ϻ���
			{
				if(FO.Comparison(fplan1.getPlanstart(), fplan2.getPlanstart())!=C.MORE)
				{
					String vmid = fplan1.getPlanslot().getVmid();
//					FuzzyNumber end = FO.Addition(fplan.getPlanstart(),task.getLength());
					as = new FAssignment(vmid,fplan1.getPlanstart(),task.getJobid(),task.getStage(),fplan1.getPlanend(),task.getLength());
				    //ִ�в������
					VirtualMachine vm = this.vmset.get(vmid);
					vm.occupySlot(fplan1.getPlanslot(), fplan1.getPlanstart(), fplan1.getPlanend(), task.getJobid());
				}
				else
					/**
					 * ���ò���1���������һ��ΥԼ��������������»��������������л��������翪ʼ��ʱ�򣬽���ǣ�����С���û��������������
					 * ����2�����fplan1����fplan2����ִ��fplan1�����򣬾ͱȽ�fplan2�������»����������ѡ��ʼʱ����С��
					 * ����2�Ĵ��۸��ڲ���1���û������Ҳ���ڲ���1����w=0.5������£�����2������ģ��LWS���ڲ���1
					 * ���Ǵ�ʱLWS�У����۲��ֹ�һ�����ͣ�ʹ���û������ռ�ȹ��ߣ����Ľ�
					 */					
				{
//					if(FO.Comparison(fplan2.getPlanstart(), task.getEarliest())!=C.MORE)//�Ѿ����޵��»����ȿ�ʼ����ѡ��
//					{
						String vmid = fplan2.getPlanslot().getVmid();
//						FuzzyNumber end = FO.Addition(fplan.getPlanstart(),task.getLength());
						as = new FAssignment(vmid,fplan2.getPlanstart(),task.getJobid(),task.getStage(),fplan2.getPlanend(),task.getLength());
					    //ִ�в������
						VirtualMachine vm = this.vmset.get(vmid);
						vm.occupySlot(fplan2.getPlanslot(), fplan2.getPlanstart(), fplan2.getPlanend(), task.getJobid());
//					}
//					else
//					{
//						VirtualMachine mch = this.addNewM();
//						FuzzyNumber end = FO.Addition(task.getEarliest(),task.getLength());
//						as = new FAssignment(mch.getMid(),task.getEarliest(),task.getJobid(),task.getStage(),end,task.getLength());			
//						mch.occupySlot(mch.getFirstEmptySlot(), task.getEarliest(), end, task.getJobid());
//						//�����δ��ռ�ã�����slotû�й���ȥ    
//						//�ж��Ƿ�Ա�ͷ�޸�
//					}
						//3_0_[1000,10000]_[10,15]_20_1.5_0.2 new
						//3_0_[1000,10000]_[10,15]_20_1.5_0.2	HEFT	127328	18480	0.9932	0.5691	12.89
						//3_0_[1000,10000]_[10,15]_20_1.5_0.2	FDES	112788	18360	0.9992	0.581	0
						//3_0_[1000,10000]_[10,15]_20_1.5_0.3	HEFT	131380	18480	0.9875	0.5641	15.32
						//3_0_[1000,10000]_[10,15]_20_1.5_0.3	FDES	113928	18240	0.9981	0.5791	0
					
//					3_0_[1000,10000]_[10,15]_20_1.5_0.2	HEFT	127328	18480	0.9932	0.5691	12.89
//					3_0_[1000,10000]_[10,15]_20_1.5_0.2	FDES	112788	18360	0.9992	0.581	0
//					3_0_[1000,10000]_[10,15]_20_1.5_0.3	HEFT	131380	18480	0.9875	0.5641	15.89
//					3_0_[1000,10000]_[10,15]_20_1.5_0.3	FDES	113364	18000	0.9977	0.5783	0
				}
			}
			else if(fplan1!=null&&fplan2==null)
			{
				String vmid = fplan1.getPlanslot().getVmid();
//				FuzzyNumber end = FO.Addition(fplan.getPlanstart(),task.getLength());
				as = new FAssignment(vmid,fplan1.getPlanstart(),task.getJobid(),task.getStage(),fplan1.getPlanend(),task.getLength());
			    //ִ�в������
				VirtualMachine vm = this.vmset.get(vmid);
				vm.occupySlot(fplan1.getPlanslot(), fplan1.getPlanstart(), fplan1.getPlanend(), task.getJobid());
			}
			else 
			{
				System.out.println("ERROR: cannot find long enough slot on old vm");
			}
//			System.out.println("final choice:"+as.toString());
		}
		
		
		//find feasible slot secondly on new tree
		
		String mid = as.getMid(); //TODO	it is possible that as is null
		VirtualMachine vm = vmset.get(mid);
		if(vm==null)
		{
			as.print();
			System.out.println(mid);
		}
		if(!jobMap.containsKey(as.getJobid()))
		this.jobMap.put(as.getJobid(), mid);
		else{
			vm.print();
			System.out.println("ERROR: add an existed job "+as.toString());
		}
		return as;
	}
	
	
	
	

	
	public void initial()
	{
		m_new = 0;
		newindex=0;
		vmset = new HashMap<String,VirtualMachine>();
		for(int i=0;i<m_old;i++)
		{
			VirtualMachine mch = new VirtualMachine(stage+"_OLD"+String.valueOf(i),stage);
			vmset.put(mch.getMid(),mch);
		}
		jobMap.clear();
	}
	
//	public String[] getMachineIDs()
//	{
//		String[] ids = new String[this.m_new+this.m_old];
//		for(int i=0;i<ids.length;i++)
//			ids[i] = vmset.get(i).getMid();
//		return ids;
//	}
	
	public VirtualMachine addNewM()
	{		
		VirtualMachine mch = new VirtualMachine(stage+"_NEW"+String.valueOf(newindex),this.stage);
		Slot newslot = mch.initial();
		this.addNewEmptySlottoNew(newslot);
		vmset.put(mch.getMid(),mch);
		m_new ++;
		newindex++;
		//System.out.println("----------------------------------------------------------------Add New VM "+mch.getMid());
		return mch;
	}
	public int getM_old() {
		return m_old;
	}

	public int getM_new() {
		return m_new;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		
	}

}
