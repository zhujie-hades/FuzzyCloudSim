package ResourceManagement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeMap;

import Jobs.FJOBS;
import Jobs.FTask;
import SchedulePlan.FAssignment;
import SchedulePlan.Schedule;
import Tools.FO;
import element.FuzzyNumber;
import element.Parameters;
public class VirtualClusterList {

	public int getM() {
		return m;
	}

	int m;
	ArrayList<VirtualCluster> list;
	

	public HashMap<String, ChargingOnOnDemand> getChargingOnOnDemandInfor()
	{
		 HashMap<String, ChargingOnOnDemand> charge = new HashMap<String, ChargingOnOnDemand>();
		 
		 for(int i=0;i<m;i++)
		 {
			 list.get(i).getChargingOnOnDemandInfor(charge);
		 }		 
		 return charge;
	}
	
	public double delayPenalty(double jobprice,Schedule schedule)
	{
		double cost = 0;		
		cost=list.get(m-1).getDelayPentaly(schedule, jobprice);
		return cost;
	}
	public double satisfactionRate(Schedule schedule)
	{
		return 1-this.delayPenalty(1, schedule)/(schedule.getN());
	}
	
//	public double CompletedelayedJobNumber(FJOBS jobs)
//	{
//		return list.get(m-1).getDelayJobNumber(jobs);
//	}
	
//	public double looseSRate(FJOBS jobs)
//	{
//		return 1-this.CompletedelayedJobNumber(jobs)/jobs.getN();
//	}
	
//	public double getIdleLength()
//	{
//		double result = 0;
//		for(int i=0;i<m;i++)
//		{
//			result+= list.get(i).getIdelLength();
//		}
//		return result;
//	}
	
//	public FuzzyNumber getTotalMakespan()
//	{
//		FuzzyNumber result = new FuzzyNumber(0);
//		
//		for(int i=0;i<m;i++)
//		{	
//			VirtualCluster ms = list.get(i);
//			FuzzyNumber makespan = ms.getTotalMakespan();
//			result = FO.Addition(makespan, result);
//		}
//		return result;
//	}
	
	
	
//	public int getTotalUsageDurationOnRentedVMs()
//	{
//		int totalusagetime = 0;
//		for(int i=0;i<m;i++)
//		{
//			VirtualCluster ms = list.get(i);
//			totalusagetime += ms.getTotalUsageDurationOnRentedVMs();
//		}
//		return totalusagetime;
//	}
	
	public void computeUtilizationInfor(int[] UtilizationRateNum,int[] lowUtilizationUsageTime,int t)
	{
		
		for(int i=0;i<m;i++)
		{
			VirtualCluster ms = list.get(i);
			ms.computeUtilizationRateInfo(UtilizationRateNum,lowUtilizationUsageTime,t);
		}

	}
	
//	public int getTotalUsageTimeOnRentedVMs()
//	{
//		int totalusagetime = 0;
//		for(int i=0;i<m;i++)
//		{
//			VirtualCluster ms = list.get(i);
//			totalusagetime += ms.getTotalUsageTimeOnRentedVMs();
//		}
//		return totalusagetime;
//	}
//	
//	public int getTotalUsageTimeOnRentedVMs(int adjustedtime,HashSet<String> on2re,HashSet<String> re2on)
//	{
//		int totalusagetime = 0;
//		for(int i=0;i<m;i++)
//		{
//			VirtualCluster ms = list.get(i);
//			totalusagetime += ms.getTotalUsageTimeOnRentedVMs(adjustedtime,on2re,re2on);
//		}
//		return totalusagetime;
//	}
	
//	public int getTotalUsageTimeOnOldVMs(int adjustedtime,HashSet<String> on2re,HashSet<String> re2on)
//	{
//		int totalusagetime = 0;
//		for(int i=0;i<m;i++)
//		{
//			VirtualCluster ms = list.get(i);
//			totalusagetime += ms.getTotalUsageTimeOnOldVMs(adjustedtime,on2re,re2on);
//		}
//		return totalusagetime;
//	}
	
//	public int getTotalUsageTimeOnOldVMs()
//	{
//		int totalusagetime = 0;
//		for(int i=0;i<m;i++)
//		{
//			VirtualCluster ms = list.get(i);
//			totalusagetime += ms.getTotalUsageTimeOnOldVMs();
//		}
//		return totalusagetime;
//	}
	
	
	
	public int gettotalRealUsageDuraionOnRented()
	{
		int totalusagetime = 0;
		for(int i=0;i<m;i++)
		{
			VirtualCluster vc = list.get(i);
			totalusagetime += vc.gettotalRealUsageDuraionOnRented();
		}
		return totalusagetime;
	}
	
	public int gettotalUsageTimeOnRented()
	{
		int totalusagetime = 0;
		for(int i=0;i<m;i++)
		{
			VirtualCluster vc = list.get(i);
			totalusagetime += vc.gettotalUsageTimeOnRented();
		}
		return totalusagetime;
	}
	
	public FuzzyNumber getFuzzyMakespan()
	{
		FuzzyNumber result = new FuzzyNumber(0);
//		for(int i=0;i<m;i++)
//		{
			VirtualCluster ms = list.get(m-1);
			FuzzyNumber makespan = ms.getFuzzyMakespan();
			if(FO.Comparison(makespan, result)==1) result = makespan.Clone();
//		}
		return result;
	}
	
	public int getNewMachineNum()
	{
		int total = 0;
		for(int i=0;i<m;i++)
		{
			VirtualCluster ms = list.get(i);
			total+=ms.getM_new();
		}
		return total;
	}
	
//	public void resetMachine(double threshold,HashSet<String> on2re,HashSet<String> re2on)
//	{
//		for(int i=0;i<m;i++)
//		{
//			int t = this.getMakespan().getHighValue();
//			list.get(i).resetMachine(threshold,on2re,re2on,t);
////			if(i==4) list.get(i).print();
//		}
//	}
	
	
	
	public VirtualMachine FindVM(String mid)
	{
		String[] arr = mid.split("_");
		int stageid = Integer.parseInt(arr[0]);
		return this.list.get(stageid).FindVM(mid);
	}
	
//	public void rollBaskAssignment(GEvent lastevent,ArrayList<Integer> rolljoblist,ArrayList<Integer> firstOrdinaryStage,ArrayList<Integer> earliest, int arriveTime)
//	{
//		for(int i=0;i<m;i++)
//		{
//			VirtualCluster vc = list.get(i);
//			vc.rollBaskAssignment(lastevent,rolljoblist, firstOrdinaryStage,earliest, arriveTime);
//		}
//	}
	
	public void rollbackAssignments(ArrayList<Slot> slotlist,int curTime)
	{
		
//		System.out.print("rollback slots:");
//		for(int i=0;i<slotlist.size();i++) 
//			System.out.print(slotlist.get(i).toString());
//		System.out.println();
		
		int size = slotlist.size();
		for(int i=0;i<size;i++)
		{
			Slot slot = slotlist.get(i);
		    int stage = Integer.parseInt(slot.getVmid().split("_")[0]);
		    VirtualCluster vc = list.get(stage);	
		  
		    vc.removeAssignment(slot, curTime);	  
		}
		
	}
	
	public ArrayList<Slot> collectAssignmentAfter(int time, int upperbound,Schedule schedule)
	{
		
		ArrayList<Slot> collection = new ArrayList<Slot>(); //jobid, stageid, assignment
		if(upperbound==0) return collection;
		for(int i=m-1;i>=0;i--)//�Ӻ���ǰ��
		{			
			VirtualCluster vc = list.get(i);
			vc.collectAssignmentAfter(collection, time, upperbound,schedule);
		}
		return collection;
	}
	
	public int[] getMachineArr()
	{
		int[] result = new int[m];
		for(int i=0;i<m;i++)
		{
			VirtualCluster ms = list.get(i);
			result[i] = ms.getM_new()+ms.getM_old();
		}
		return result;
	}

	public VirtualClusterList(int m,int[] oldlist,Parameters setting)
	{
		this.m = m;
		list = new ArrayList<VirtualCluster>();
		for(int i=0;i<m;i++)
		{
			VirtualCluster set = new VirtualCluster(i,oldlist[i],setting);
			list.add(set);
		}
	}
	public VirtualClusterList()
	{
		list = new ArrayList<VirtualCluster>();
	}
	
	public EmptySlotLinkedlist CloneEmptySlot(int curTime)
	{
		EmptySlotLinkedlist list = new EmptySlotLinkedlist(m);
		for(int i=0;i<m;i++)
		{
			VirtualCluster vc = this.list.get(i);
			int newvmindex = vc.getNewindex();
			list.setHead(vc.getEmptyHead_old(), vc.getEmptyHead_new(), i,curTime,newvmindex);
			
		}
		return list;
	}
	
//	public VirtualClusterList Clone()
//	{
//		VirtualClusterList copy = new VirtualClusterList();
//		copy.setM(m);
//		for(int i=0;i<m;i++)
//		{
//			VirtualCluster ms = this.list.get(i);
//			copy.getList().add(ms.Clone());			
//		}
//		return copy;
//	}
	
	public ArrayList<VirtualCluster> getList() {
		return list;
	}

	public void setM(int m) {
		this.m = m;
	}

	public void setList(ArrayList<VirtualCluster> list) {
		this.list = list;
	}

//	public String[] getMachineIDofStage(int i)
//	{
//		return list.get(i).getMachineIDs();
//	}
	
	public int getMachineNumOfStage(int i)
	{
		VirtualCluster ms = list.get(i);
		return ms.getM_new()+ms.getM_old();
	}
	
	public int getNewMachineNumOfStage(int i)
	{
		return list.get(i).getM_new();
	}
	
	public int getOldMachineNumOfStage(int i)
	{
		return list.get(i).getM_old();
	}
	
	public String[] getMachineIDList(int i)
	{
		VirtualCluster ms = list.get(i);
		return ms.getMachineIDList();
		
	}
	
	public Slot[] getSlotsOfJob(int jobid)
	{
		Slot[] slotlist = new Slot[m];
		for(int i=0;i<m;i++)
		{
			slotlist[i] = this.list.get(i).findArrangement(jobid);		
			if(slotlist[i]==null)
				{
				System.out.println("ERRORRRRRRRRRRRRRRRRR: return null slot");
				return null;
				}
		}
		return slotlist;
	}
	
	
	
	public int getTotalMachineNum()
	{
		int total = 0;
		for(int i=0;i<m;i++)
		{
			VirtualCluster ms = list.get(i);
			total += ms.getM_new()+ms.getM_old();
		}
		return total;
	}
	
	public int getTotalOldMachineNum()
	{
		return m*list.get(0).getM_old();
	}
	

	public void initial()
	{
		for(int i=0;i<m;i++)
		{
			list.get(i).initial();
		}
	}
	public VirtualCluster getMS(int stage)
	{
		return list.get(stage);
	}
	
	public void print()
	{
		for(int i=0;i<m;i++)
		{
			VirtualCluster ms = list.get(i);
			ms.print();
		}
	}
	
//	public FuzzyNumber getRealEarliestStart(FTask task)
//	{
//		VirtualCluster vc = this.list.get(task.getStage());
//		return vc.getRealEarliestStart(task).getPlanstart();
//	}
	
	
	public FAssignment Arrange(FTask task)
	{
		VirtualCluster vc = this.list.get(task.getStage());
        FAssignment as = vc.Arrangement(task);
        return as;
	}
	
//	public void updateEmptySlotHead(int curT)//�����ش���󣡣������ܶ����slot
//	{
//		for(int i=0;i<m;i++)
//		{
//			VirtualCluster ms = list.get(i);
////			System.out.println("Before Updating empty%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
////			System.out.println(ms.getOldEmptySlotString());
////			System.out.println(ms.getNewEmptySlotString());
//			ms.updateEmptySlotHead(curT);		
////			System.out.println("After Updating empty%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
////			System.out.println(ms.getOldEmptySlotString());
////			System.out.println(ms.getNewEmptySlotString());
//		}
//	}
	
	public void CheckingLinkedList()
	{
		for(int i=0;i<m;i++)
		{
			VirtualCluster ms = list.get(i);
			ms.CheckingLinkedList();
		}
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
