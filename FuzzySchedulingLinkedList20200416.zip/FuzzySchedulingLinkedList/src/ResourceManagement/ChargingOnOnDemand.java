package ResourceManagement;

import element.FuzzyNumber;

public class ChargingOnOnDemand {

	String vmid;
	FuzzyNumber start;
	FuzzyNumber end;
	
	public ChargingOnOnDemand(String vmid,FuzzyNumber start,FuzzyNumber end)
	{
		this.vmid = vmid;
		this.start = start;
		this.end = end;
	}

	public void setEnd(FuzzyNumber end) {
		this.end = end;
	}

	public String getVmid() {
		return vmid;
	}

	public FuzzyNumber getStart() {
		return start;
	}

	public FuzzyNumber getEnd() {
		return end;
	}
	
}
