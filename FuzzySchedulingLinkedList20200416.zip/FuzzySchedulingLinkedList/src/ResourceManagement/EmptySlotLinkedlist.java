package ResourceManagement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import Jobs.FTask;
import SchedulePlan.FAssignment;
import SchedulePlan.FPlan;
import Tools.CO;
import Tools.FO;
import element.C;
import element.FuzzyNumber;

public class EmptySlotLinkedlist {

	Slot[] oldheadlist;
	Slot[] newheadlist;
	int m;
	int[] newVMindex;
	
	public double computeprice(int totalOldVMNum,int curTime)
	{
		FuzzyNumber makespan = C.TimeZero;
		HashSet<String> vmlist = new HashSet<String>();
		for(int i=0;i<newheadlist.length;i++)
		{
			Slot p = newheadlist[i].getNextSlot();
			while(p!=null)
			{
				if(FO.Comparison(p.getStart(), makespan)==C.MORE) makespan = p.getStart().Clone();
				vmlist.add(p.getVmid());
				p = p.getNextSlot();
			}
		}
		for(int i=0;i<oldheadlist.length;i++)
		{
			Slot p = oldheadlist[i].getNextSlot();
			while(p!=null)
			{
				if(FO.Comparison(p.getStart(), makespan)==C.MORE) makespan = p.getStart().Clone();
				p = p.getNextSlot();
			}
		}
		int newvmnum = vmlist.size();
		double costR = (double)(makespan.getHighValue()-curTime)/C.Charge_Time_Unit*totalOldVMNum*C.Price_R;
		double costO = (double)(makespan.getHighValue()-curTime)/C.Charge_Time_Unit*newvmnum*C.Price_On;

		return costR+costO;
	}
	
	public double getAvgUtilization(int curTime)
	{
		double utilization = 0;
		FuzzyNumber makespan = C.TimeZero;
		HashMap<String,FuzzyNumber> emptylengthmap = new HashMap<String,FuzzyNumber>();
		for(int i=0;i<oldheadlist.length;i++)
		{
			Slot p = oldheadlist[i].getNextSlot();
			while(p!=null)
			{
				
				if(FO.Comparison(p.getStart(), makespan)==C.MORE) makespan = p.getStart().Clone();
				
				p = p.getNextSlot();
				
			}
		}
		
		return utilization;
	}
	
	public boolean isSameTest(EmptySlotLinkedlist list)
	{
		for(int i=0;i<oldheadlist.length;i++)
		{
			Slot p = oldheadlist[i];
			Slot q = list.getOldHead(i);
			while(p!=null)
			{
				if(!p.getStart().toString().equalsIgnoreCase(q.getStart().toString())) 
				{
					System.out.println(p.toString()+"!="+q.toString());
					return false;
				}
				if(!p.getEnd().toString().equalsIgnoreCase(q.getEnd().toString())) 
				{
					System.out.println(p.toString()+"!="+q.toString());
					return false;
				}
				p = p.getNextSlot();
				q = q.getNextSlot();
			}
		}
		return true;
	}
	
	public Slot[] getOldheadlist() {
		return oldheadlist;
	}

	public Slot[] getNewheadlist() {
		return newheadlist;
	}

	public void validation()
	{
		for(int i=0;i<m;i++)
		{
			Slot p = oldheadlist[i];
			while(p!=null)
			{
				Slot q = p.getNextSlot();
				if(q!=null)
				{
					if(FO.Comparison(p.getStart(), q.getStart())==C.MORE)
					{
						System.out.println("ERROR: successive old emptyslots is not ordered: "+p.getStart().toString()+" < "+q.getStart().toString());
						return;
					}
				}
				p = p.getNextSlot();
			}
			p = newheadlist[i];
			while(p!=null)
			{
				Slot q = p.getNextSlot();
				if(q!=null)
				{
					if(FO.Comparison(p.getStart(), q.getStart())==C.MORE)
					{
						System.out.println("ERROR: successive new emptyslots is not ordered: "+p.getStart().toString()+" < "+q.getStart().toString());
						return;
					}
				}
				p = p.getNextSlot();
			}
		}
	}

	public EmptySlotLinkedlist(int m) {
		oldheadlist = new Slot[m];
		newheadlist = new Slot[m];
		this.m = m;
		newVMindex = new int[m];
		for(int i=0;i<m;i++) newVMindex[i] = 0;
	}
	
	public void print(Slot head)
	{
		Slot p = head;
		while(p!=null)
		{
			System.out.print(p.toString()+"-->");
			p = p.getNextSlot();
		}
		System.out.println();
	}
	
	public void printStage(int stage)
	{
		if(oldheadlist[stage]!=null)
		{
			System.out.print("OLD-->");
			this.print(oldheadlist[stage]);
		}
		if(newheadlist[stage]!=null)
		{
			System.out.print("NEW-->");
			this.print(newheadlist[stage]);
		}
	}
	
	public void printAll()
	{
		for(int i=0;i<m;i++)
			this.printStage(i);
	}
	
	public void compareWith(EmptySlotLinkedlist copy)
	{
		for(int i=0;i<m;i++)
		{
			CO.checkingTwoCopyList(this.oldheadlist[i], copy.getOldHead(i));
			CO.checkingTwoCopyList(this.newheadlist[i], copy.getNewHead(i));
		}
	}
	
	
	public Slot getOldHead(int stageid)
	{
		return this.oldheadlist[stageid];
	}
	public Slot getNewHead(int stageid)
	{
		return this.newheadlist[stageid];
	}

	public EmptySlotLinkedlist Clone() {
		EmptySlotLinkedlist copy = new EmptySlotLinkedlist(m);
		for (int i = 0; i < m; i++) {
			copy.setHead(this.oldheadlist[i], this.newheadlist[i], i,newVMindex[i]);
		}

		return copy;
	}

	public void setHead(Slot emptyHead_old, Slot emptyHead_new, int stage,int curT,int newvmindex) {

		int earliest = curT +C.EVENTINTERVAL;
		this.newVMindex[stage] = newvmindex;
		ArrayList<Slot> oldtemp = new ArrayList<Slot>();
		Slot p = emptyHead_old;
		int newindex = -1;
		while (p != null) {
			Slot newslot = p.copy();
			if(newslot.getVmid().equalsIgnoreCase("HEAD"))
			{
				oldtemp.add(newslot);
				newindex++;				
			}
			else
			{
				if(FO.Comparison(newslot.getStart(), earliest)==C.LESS) newslot.setStart(new FuzzyNumber(earliest));
				if(FO.Comparison(newslot.getStart(), newslot.getEnd())==C.LESS)
				{
					oldtemp.add(newslot);
					newindex++;
					int preindex = newindex - 1;
					
						Slot preslot = oldtemp.get(preindex);
						preslot.setNextSlot(newslot);
						newslot.setPreSlot(preslot);
					
				}
			}
			
			p = p.getNextSlot();
		}
		if (newindex >= 0)
			oldheadlist[stage] = oldtemp.get(0);

		ArrayList<Slot> newtemp = new ArrayList<Slot>();
		p = emptyHead_new;
		newindex = -1;
		while (p != null) {
			Slot newslot = p.copy();
			if(newslot.getVmid().equalsIgnoreCase("HEAD"))
			{
				newtemp.add(newslot);
				newindex++;
				
			}
			else
			{
				if(FO.Comparison(newslot.getStart(), earliest)==C.LESS) newslot.setStart(new FuzzyNumber(earliest));
				if(FO.Comparison(newslot.getStart(), newslot.getEnd())==C.LESS)
				{
					newtemp.add(newslot);
					newindex++;
					int preindex = newindex - 1;
					
						Slot preslot = newtemp.get(preindex);
						preslot.setNextSlot(newslot);
						newslot.setPreSlot(preslot);
					
				}
			}
			
			p = p.getNextSlot();
		}
		if (newindex >= 0)
			newheadlist[stage] = newtemp.get(0);
	}
	
	public void setHead(Slot emptyHead_old, Slot emptyHead_new, int stage,int newvmindex) {

		ArrayList<Slot> oldtemp = new ArrayList<Slot>();
		this.newVMindex[stage] = newvmindex;
		Slot p = emptyHead_old;
		int newindex = -1;
		while (p != null) {
			Slot newslot = p.copy();
				oldtemp.add(newslot);
				newindex++;
				int preindex = newindex - 1;
				if (newindex > 0) {
					Slot preslot = oldtemp.get(preindex);
					preslot.setNextSlot(newslot);
					newslot.setPreSlot(preslot);
				}
			p = p.getNextSlot();
		}
		if (newindex >= 0)
		{
			oldheadlist[stage] = oldtemp.get(0);
		}

		ArrayList<Slot> newtemp = new ArrayList<Slot>();
		p = emptyHead_new;
		newindex = -1;
		while (p != null) {
			Slot newslot = p.copy();
			
				newtemp.add(newslot);
				newindex++;
				int preindex = newindex - 1;
				if (newindex > 0) {
					Slot preslot = newtemp.get(preindex);
					preslot.setNextSlot(newslot);
					newslot.setPreSlot(preslot);
				}
			p = p.getNextSlot();
		}
		if (newindex >= 0)
			newheadlist[stage] = newtemp.get(0);
	}

	public Slot getRealEarliestStart(FTask task) {
		// ��������»����Ͽ�ʼ�Ļ���Ӧ�ý������ȼ�
		int stage = task.getStage();
		// ����oldvm�ϲ���
		Slot p = this.oldheadlist[stage].getNextSlot();
		while (p != null) {
//			FuzzyNumber start = FO.Max(p.getStart(), task.getEarliest());
//			// ������slot�������Ŀ�ʼʱ�����������ʼʱ�䣬˵�������slotҲ���ڣ��˳�
//			if (FO.Comparison(start, task.getLatest()) == C.MORE) {
//				p = null;
//				break;
//			}
//			FuzzyNumber end = FO.Addition(start, task.getLength());
//			// ������һ���ܷ��µģ���������ֱ�ӷ���
//			if (FO.Comparison(end, p.getEnd()) != C.MORE) {
//
//				return new Slot(p.getVmid(), start, end);
//			}
//			p = p.getNextSlot();
			
			FuzzyNumber start = FO.Max(p.getStart(), task.getEarliest());
			FuzzyNumber end = FO.Min(p.getEnd(), FO.Addition(task.getLatest(), task.getLength()));
			if(FO.Comparison(FO.Addition(start,task.getLength()),end)!=C.MORE)
			{
//				plan = new FPlan(start,FO.Addition(start,task.getLength()),p);
				return new Slot(p.getVmid(), start, FO.Addition(start, task.getLength()));
//				break;
			}
			if(FO.Comparison(p.getStart(), task.getLatest())==C.MORE) break;
			p = p.getNextSlot();
		}

		if (p == null) // ���»�������
		{
			p = this.newheadlist[stage].getNextSlot();
			while (p != null) {
//				FuzzyNumber start = FO.Max(p.getStart(), task.getEarliest());
//				// ������slot�������Ŀ�ʼʱ�����������ʼʱ�䣬˵�������slotҲ���ڣ��˳�
//				if (FO.Comparison(start, task.getLatest()) == C.MORE) {
//					p = null;
//					break;
//				}
//				FuzzyNumber end = FO.Addition(start, task.getLength());
//				// ������һ���ܷ��µģ���������ֱ�ӷ���
//				if (FO.Comparison(end, p.getEnd()) != C.MORE) {
//					return new Slot(p.getVmid(), start, end);
//				}
//				p = p.getNextSlot();
				FuzzyNumber start = FO.Max(p.getStart(), task.getEarliest());
				FuzzyNumber end = FO.Min(p.getEnd(), FO.Addition(task.getLatest(), task.getLength()));
				if(FO.Comparison(FO.Addition(start,task.getLength()),end)!=C.MORE)
				{
//					plan = new FPlan(start,FO.Addition(start,task.getLength()),p);
					return new Slot(p.getVmid(), start, FO.Addition(start, task.getLength()));
//					break;
				}
				if(FO.Comparison(p.getStart(), task.getLatest())==C.MORE) break;
				p = p.getNextSlot();
			}
		}
		// ���ߵ�����˵����û���ҵ�������null��Ĭ��˵�������»����ϰ���
		return null;
	}
	
//	private boolean swapWithNext(Slot p, Slot q)//p��ǰ��q�ں�,p�϶���Ϊnull
//	{
//		if(q==null) return false;
//		if(FO.Comparison(p.getStart(), q.getStart())==C.MORE)
//		{
//			if(p.getPreSlot()!=null)
//				p.getPreSlot().setNextSlot(q);
//			q.setPreSlot(p.getPreSlot());
//			if(q.getNextSlot()!=null)
//				q.getNextSlot().setPreSlot(p);
//			p.setNextSlot(q.getNextSlot());
//			q.setNextSlot(p);
//			p.setPreSlot(q);
//			return true;
//		}
//		return false;
//	}
	
	private FPlan FindFirstAvailableSlot(FTask task,Slot head)//�ҵ���һ�����Ⱥ����������翪ʼʱ���slot
	{
		
		FPlan plan = null;
		Slot p = head.getNextSlot();
		while(p!=null)
		{
			//�������Ⱥ��ʵ�slot			
//			FuzzyNumber start = FO.Max(p.getStart(), task.getEarliest());
//			FuzzyNumber end = FO.Min(p.getEnd(), FO.Addition(task.getLatest(), task.getLength()));
//			if(FO.Comparison(FO.Addition(start,task.getLength()),end)!=C.MORE)
//			{
//				plan = new FPlan(start,FO.Addition(start,task.getLength()),p);				
//				break;
//			}
//			if(FO.Comparison(p.getStart(), task.getLatest())==C.MORE) break;
//			p = p.getNextSlot();
			FuzzyNumber start = FO.Max(p.getStart(), task.getEarliest());
			FuzzyNumber end = FO.Min(p.getEnd(), FO.Addition(task.getLatest(), task.getLength()));
			if(FO.Comparison(FO.Addition(start,task.getLength()),end)!=C.MORE)
			{
				plan = new FPlan(start,FO.Addition(start,task.getLength()),p);
				
				break;
			}
			if(FO.Comparison(p.getStart(), task.getLatest())==C.MORE) break;
			p = p.getNextSlot();
		}
		return plan;
	}
	
	private void SwapToTail(Slot slot)
	{
		
		Slot q = slot.getNextSlot();
		while(q!=null)
		{
			if(FO.Comparison(slot.getStart(), q.getStart())==C.MORE)
			{
				if(slot.getPreSlot()!=null)
					slot.getPreSlot().setNextSlot(q);
				q.setPreSlot(slot.getPreSlot());
				if(q.getNextSlot()!=null)
					q.getNextSlot().setPreSlot(slot);
				slot.setNextSlot(q.getNextSlot());
				q.setNextSlot(slot);
				slot.setPreSlot(q);
//				if(slot.getPreSlot()!=null)
//					slot.getPreSlot().setNextSlot(q);
//				q.setPreSlot(slot.getPreSlot());
//				slot.setNextSlot(q.getNextSlot());
//				slot.setPreSlot(q);
//				q.setNextSlot(slot);
//				if(slot.getNextSlot()!=null)
//					slot.getNextSlot().setPreSlot(slot);
//
				q = slot.getNextSlot();
			}
			else break;
		}
	}
	
	private void SwapToFront(Slot slot)
	{
		Slot p = slot.getPreSlot();
		while(p!=null)
		{
			if(FO.Comparison(p.getStart(), slot.getStart())==C.MORE) 
			{
//				this.SwapEmpty(p, q);
				if(p.getPreSlot()!=null)
					p.getPreSlot().setNextSlot(slot);
				slot.setPreSlot(p.getPreSlot());
				p.setPreSlot(slot);
				p.setNextSlot(slot.getNextSlot());
				slot.setNextSlot(p);
				if(p.getNextSlot()!=null)
					p.getNextSlot().setPreSlot(p);
	           p=slot.getPreSlot();
			}
			else break;
		}
	}
	
	public int occupySlot(Slot eslot, FuzzyNumber start, FuzzyNumber end) //flag==0 ��ȷ���; flag ==-1 �����������䱻ռ��ʱ�϶���fuzzy��ռ��
	{
		
		int flag = 0;
		//validation
		if(FO.Comparison(eslot.getStart(), start)==C.MORE)
		{
			flag = -1;
			System.out.println("ERROR: ���䲻��������1");
		}
		if(FO.Comparison(eslot.getEnd(), end)==C.LESS)
		{
			flag = -1;
			System.out.println("ERROR: ���䲻��������1");
		}
			
		int condition = 2;
		if(FO.Comparison(eslot.getStart(), start)==C.LESS&&FO.Comparison(end, eslot.getEnd())!=C.LESS) condition = 0;
		else if(FO.Comparison(eslot.getStart(), start)!=C.LESS&&FO.Comparison(end, eslot.getEnd())==C.LESS) condition = 1;
		else if(FO.Comparison(eslot.getStart(), start)==C.LESS&&FO.Comparison(end, eslot.getEnd())==C.LESS) condition = 3;
		else if(FO.Comparison(eslot.getStart(), start)==C.EQUARE&&FO.Comparison(end, eslot.getEnd())==C.EQUARE)
		{
			condition = 4;//�ص���ʱ����һ������Żص�ԭ��ȡ����λ��
			
		}
		
		if(condition==0)
		{			
			eslot.setEnd(start);//���¿���ʱ��Ƭ����
		}	
		else if(condition==1)
		{
			eslot.setStart(end);
			/*
			 * eslot��ʼʱ��仯�������ڿ������ϵ�λ�ÿ�����Ҫ����
			 * */
			
			this.SwapToTail(eslot);
			
		}
		else if(condition==3)
		{
			Slot newemptyslot = new Slot(eslot.getVmid(),end, eslot.getEnd());
			
			eslot.setEnd(start);
			newemptyslot.setPreSlot(eslot);
			newemptyslot.setNextSlot(eslot.getNextSlot());
			if(eslot.getNextSlot()!=null) eslot.getNextSlot().setPreSlot(newemptyslot);
			eslot.setNextSlot(newemptyslot);
			this.SwapToTail(newemptyslot);
		}
		else if(condition==4)
		{
			
				eslot.getPreSlot().setNextSlot(eslot.getNextSlot());
				if(eslot.getNextSlot()!=null)
					eslot.getNextSlot().setPreSlot(eslot.getPreSlot());
				eslot = null;
		}
		
		
		return flag;
	}
	
	private FPlan FindEarliestSlot(FTask task,Slot head)//�ҵ���һ�����Ⱥ����������翪ʼʱ���slot
	{

		
		FPlan plan = null;
		Slot p = head.getNextSlot();
		while(p!=null)
		{
			//�������Ⱥ��ʵ�slot			
			FuzzyNumber start = FO.Max(p.getStart(), task.getEarliest());
			if(FO.Comparison(FO.Addition(start,task.getLength()),p.getEnd())!=C.MORE)//ֻҪ�ܷ��¾���
			{
				plan = new FPlan(start,FO.Addition(start,task.getLength()),p);
				
				break;
			}
//			if(FO.Comparison(p.getStart(), task.getLatest())==C.MORE) break; ֻҪ�ҵ���һ���ܷ��¾��У������ǽ�ֹ����
			p = p.getNextSlot();
		}
		return plan;
	}
	
	private Slot addNewSlot(int stage,int curT)
	{
		String newvmid = stage+"_NEW" + this.newVMindex[stage];// ��������»������
		this.newVMindex[stage]++;
		Slot newslot = new Slot(newvmid,new FuzzyNumber(curT+C.EVENTINTERVAL),C.Infinity);
		Slot head = this.newheadlist[stage];
		newslot.setPreSlot(head);
		newslot.setNextSlot(head.getNextSlot());
		if(head.getNextSlot()!=null) head.getNextSlot().setPreSlot(newslot);
		head.setNextSlot(newslot);
		this.SwapToTail(newslot);
		return newslot;
	}

	public FAssignment Arrange(FTask task, int curT) {//�ҵ����̲���
		FAssignment as = null;
		// ��������»����Ͽ�ʼ�Ļ���Ӧ�ý������ȼ�
		int stage = task.getStage();
		boolean harddeadline = true;
		if(FO.Comparison(task.getEarliest(), task.getLatest())==C.MORE)
		{
//			System.out.println("Terrible Error: the task has to be arranged on new VM "+task.toString());
			harddeadline = false;
		}
		if(harddeadline)
		{
			FPlan fplan = this.FindFirstAvailableSlot(task, this.oldheadlist[stage]);
			if(fplan!=null)
			{
				String vmid = fplan.getPlanslot().getVmid();
//				FuzzyNumber end = FO.Addition(fplan.getPlanstart(),task.getLength());
				as = new FAssignment(vmid,fplan.getPlanstart(),task.getJobid(),task.getStage(),fplan.getPlanend(),task.getLength());
			    //ִ�в������
				this.occupySlot(fplan.getPlanslot(), fplan.getPlanstart(), fplan.getPlanend());

			}
			else {
				fplan = this.FindFirstAvailableSlot(task, this.newheadlist[stage]);
				if(fplan!=null)
				{
					String vmid = fplan.getPlanslot().getVmid();
//					FuzzyNumber end = FO.Addition(task.getEarliest(),task.getLength());
					as = new FAssignment(vmid,fplan.getPlanstart(),task.getJobid(),task.getStage(),fplan.getPlanend(),task.getLength());
				    //ִ�в������
					
					this.occupySlot(fplan.getPlanslot(), fplan.getPlanstart(), fplan.getPlanend());
				}
				else
				{
					Slot eslot = this.addNewSlot(stage,curT);
					FuzzyNumber end = FO.Addition(task.getEarliest(),task.getLength());
					as = new FAssignment(eslot.getVmid(),task.getEarliest(),task.getJobid(),task.getStage(),end,task.getLength());			
					this.occupySlot(eslot, task.getEarliest(), end);
				}		
			}
		}
		else
		{

			//find feasible slot firstly on old vm
			FPlan fplan1 = this.FindEarliestSlot(task, this.oldheadlist[stage]);
			FPlan fplan2 = 	this.FindEarliestSlot(task, this.newheadlist[stage]);
			if(fplan1!=null&&fplan2!=null)//���ϻ����϶��ܷŵ��£��ϻ����ȿ�ʼ��ѡ�ϻ���
			{
				if(FO.Comparison(fplan1.getPlanstart(), fplan2.getPlanstart())!=C.MORE)
				{
					String vmid = fplan1.getPlanslot().getVmid();
//					FuzzyNumber end = FO.Addition(fplan.getPlanstart(),task.getLength());
					as = new FAssignment(vmid,fplan1.getPlanstart(),task.getJobid(),task.getStage(),fplan1.getPlanend(),task.getLength());
				    //ִ�в������
					
					this.occupySlot(fplan1.getPlanslot(), fplan1.getPlanstart(), fplan1.getPlanend());
				}
				else
					/**
					 * ���ò���1���������һ��ΥԼ��������������»��������������л��������翪ʼ��ʱ�򣬽���ǣ�����С���û��������������
					 * ����2�����fplan1����fplan2����ִ��fplan1�����򣬾ͱȽ�fplan2�������»����������ѡ��ʼʱ����С��
					 * ����2�Ĵ��۸��ڲ���1���û������Ҳ���ڲ���1����w=0.5������£�����2������ģ��LWS���ڲ���1
					 * ���Ǵ�ʱLWS�У����۲��ֹ�һ�����ͣ�ʹ���û������ռ�ȹ��ߣ����Ľ�
					 */					
				{
//					if(FO.Comparison(fplan2.getPlanstart(), task.getEarliest())!=C.MORE)//�Ѿ����޵��»����ȿ�ʼ����ѡ��
//					{
						String vmid = fplan2.getPlanslot().getVmid();
//						FuzzyNumber end = FO.Addition(fplan.getPlanstart(),task.getLength());
						as = new FAssignment(vmid,fplan2.getPlanstart(),task.getJobid(),task.getStage(),fplan2.getPlanend(),task.getLength());
					    //ִ�в������
						
						this.occupySlot(fplan2.getPlanslot(), fplan2.getPlanstart(), fplan2.getPlanend());
//					}
//					else
//					{
//						VirtualMachine mch = this.addNewM();
//						FuzzyNumber end = FO.Addition(task.getEarliest(),task.getLength());
//						as = new FAssignment(mch.getMid(),task.getEarliest(),task.getJobid(),task.getStage(),end,task.getLength());			
//						mch.occupySlot(mch.getFirstEmptySlot(), task.getEarliest(), end, task.getJobid());
//						//�����δ��ռ�ã�����slotû�й���ȥ    
//						//�ж��Ƿ�Ա�ͷ�޸�
//					}
						//3_0_[1000,10000]_[10,15]_20_1.5_0.2 new
						//3_0_[1000,10000]_[10,15]_20_1.5_0.2	HEFT	127328	18480	0.9932	0.5691	12.89
						//3_0_[1000,10000]_[10,15]_20_1.5_0.2	FDES	112788	18360	0.9992	0.581	0
						//3_0_[1000,10000]_[10,15]_20_1.5_0.3	HEFT	131380	18480	0.9875	0.5641	15.32
						//3_0_[1000,10000]_[10,15]_20_1.5_0.3	FDES	113928	18240	0.9981	0.5791	0
					
//					3_0_[1000,10000]_[10,15]_20_1.5_0.2	HEFT	127328	18480	0.9932	0.5691	12.89
//					3_0_[1000,10000]_[10,15]_20_1.5_0.2	FDES	112788	18360	0.9992	0.581	0
//					3_0_[1000,10000]_[10,15]_20_1.5_0.3	HEFT	131380	18480	0.9875	0.5641	15.89
//					3_0_[1000,10000]_[10,15]_20_1.5_0.3	FDES	113364	18000	0.9977	0.5783	0
				}
			}
			else if(fplan1!=null&&fplan2==null)
			{
				String vmid = fplan1.getPlanslot().getVmid();
//				FuzzyNumber end = FO.Addition(fplan.getPlanstart(),task.getLength());
				as = new FAssignment(vmid,fplan1.getPlanstart(),task.getJobid(),task.getStage(),fplan1.getPlanend(),task.getLength());
			    //ִ�в������
				
				this.occupySlot(fplan1.getPlanslot(), fplan1.getPlanstart(), fplan1.getPlanend());
			}
			else 
			{
				System.out.println("ERROR: cannot find long enough slot on old vm");
			}
//			System.out.println("final choice:"+as.toString());
		
		}
		
		
		return as;
	}

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
