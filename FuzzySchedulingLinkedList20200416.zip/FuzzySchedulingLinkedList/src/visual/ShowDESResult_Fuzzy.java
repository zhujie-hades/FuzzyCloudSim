package visual;

import java.awt.Dimension;
import java.awt.Font;
//import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Jobs.FJOB;
import Jobs.FJOBS;
import ResourceManagement.Slot;
import ResourceManagement.VirtualCluster;
import ResourceManagement.VirtualClusterList;
import SchedulePlan.FAssignment;
import SchedulePlan.Schedule;
import Tools.FO;
import element.C;
import element.FuzzyNumber;

import javax.swing.JScrollPane;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
//import java.util.Iterator;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JComboBox;
//import javax.swing.JLabel;

public class ShowDESResult_Fuzzy extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JPanel showpanel;
	BufferedImage image;
//	FJOBS jobs;
	VirtualClusterList vclist;
	Schedule schedule;
	ArrayList<ArrayList<Integer>> arriveSeq;
	ArrayList<Integer> arriveTime;
	int m;
	int n;
	double ratio = 1.5;
	int height;
	int width;
	int startX = 50;
	int startY = 100;
	int endX;
	int endY;
	int heightunit = 30;
//	int[] xPoints;
//	int[] yPoints;
	JTextField newStage1MID;
	JTextField newStage2MID;
	JButton AddStage1MachineButton;
	JButton AddStage2MachineButton;
	JButton RemoveStage1MachineButton;
	JButton RemoveStage2MachineButton;
	JButton btnMove;
	JComboBox<Integer> comboBox_job;
	JComboBox<String> comboBox_stage;
	JComboBox<String> comboBox_machine;
	JButton button_shift_to_left;
	JButton button_shift_to_right;
	JComboBox<Integer> comboBox_job1;
	JComboBox<Integer> comboBox_job2;
	JComboBox<String> comboBox_shiftmachine;
//	HashMap<Integer, Color> cmap;
	
	JButton checkTardiness;
	JButton switchButton;
	
	JButton saveButton;

	HashMap<String,Integer> machineX;
	HashMap<String,Integer> machineY;

	/**
	 * Launch the application.
	 */
	
	
	public static void main(String[] args) {
//       Graphics2D Graphics2D = null;
//	ShowDESResult show=new ShowDESResult(Graphics2D);
//       System.out.println("1234");
	}

	private int estimateHeight() {
		int height = 0;
		int linenum = vclist.getTotalMachineNum();
		
		
		height = (linenum+m+1) * heightunit;
		height += 10*m;
		this.endY = height - this.heightunit;
		return height;
	}

	private int estimateWidth() {
		double width = 0;
		double unit = 50;
		int makespan = vclist.getFuzzyMakespan().getHighValue();
//		System.out.println("makespan="+makespan);
		ratio = (int)(makespan / 2000);
		if (ratio == 0) {
			width = 2 * unit + makespan;
			ratio = 1;
		} else
			width = 2 * unit + makespan / ratio;
		this.endX = (int)(width - 50);
//		System.out.println("ratio="+ratio+",makespan="+makespan);
		return (int)width;
	}

	private void drawMachine(Graphics2D g2d) {

		
		
		int startx = this.startX;
		int starty = this.startY;
		g2d.setColor(Color.black);

		for(int i=0;i<m;i++)
		{
			int linenum = vclist.getMachineNumOfStage(i);
			int oldnum = vclist.getOldMachineNumOfStage(i);
			String[] mids = vclist.getMachineIDList(i);
			//System.out.println("machinenumer="+linenum+" mn="+mids.length);

			for(int j=0;j<oldnum;j++)
			{
				g2d.setColor(Color.BLACK);
				g2d.drawString(mids[j], startx - 40, starty);
				g2d.setColor(Color.green);

				g2d.drawLine(startx, starty, startx + this.width, starty);
				machineX.put(mids[j], startx);
				machineY.put(mids[j], starty);
				starty += this.heightunit;
			}
			g2d.setColor(Color.BLACK);
			for(int j=oldnum;j<linenum;j++)
			{
				g2d.drawString(mids[j], startx - 40, starty);
				g2d.drawLine(startx, starty, startx + this.width, starty);
				machineX.put(mids[j], startx);
				machineY.put(mids[j], starty);
				starty += this.heightunit;
			}
			g2d.setColor(Color.BLACK);
			g2d.fillRect(0, starty, width, 10);
			starty += 10 + this.heightunit;
		}		
	}

//	private void genRanColor() {
//		Random r = new Random();
//		if(cmap==null)
//		{
//		cmap = new HashMap<Integer, Color>();
//		for (int i = 0; i < n; i++)
//			cmap.put(i,new Color(r.nextInt(255), r.nextInt(255), r.nextInt(255)));
//		}
//		else if(cmap.size()<n)
//		{
//			for(int i=cmap.size();i<n;i++)
//			{
//				cmap.put(i,new Color(r.nextInt(255), r.nextInt(255), r.nextInt(255)));
//			}
//		}
//	}
	
	private void drawArriveInfo(Graphics2D g2d,int eventNum)
	{
		int startx = this.startX;
		int starty = this.startY;
		g2d.setColor(Color.gray);
		int size = this.arriveSeq.size();
		for(int i=0;i<eventNum;i++)
		{
			int atime = i*C.EVENTINTERVAL;
			ArrayList<Integer> joblist = null;
			if(i<arriveSeq.size()) this.arriveSeq.get(i);
			else joblist = new ArrayList<Integer>();
			if(i==eventNum-1)
			g2d.drawLine(startx+atime/(int) ratio, starty+this.estimateHeight(), startx+atime/(int) ratio, starty-60);

//			if(i%3==0)
//			{
//				g2d.drawLine(startx+atime/(int) ratio, starty-100, startx+atime/(int) ratio, starty-60);
////				g2d.drawString(joblist.toString(), startx+atime/(int) ratio, starty-50);
//			}
//			else if(i%3==1)
//			{
//				g2d.drawLine(startx+atime/(int) ratio, starty-100, startx+atime/(int) ratio, starty-60);
////				g2d.drawString(joblist.toString(), startx+atime/(int) ratio, starty-70);
//			}
//			else
//			{
//				g2d.drawLine(startx+atime/(int) ratio, starty-100, startx+atime/(int) ratio, starty-60);
////				g2d.drawString(joblist.toString(), startx+atime/(int) ratio, starty-90);
//			}
		}
	}
	
	private void checking(Slot p,Slot q)
	{
		if(FO.Comparison(p.getStart(), q.getStart())==C.MORE)
		{
			System.out.println("ERROR IN painting: "+p.toString()+q.toString());
		}
	}

	private void drawJobs(Graphics2D g2d,HashMap<Integer,Color> cmap) {
		//Iterator<String> mit = timetable.getStage1MachineSet().iterator();
		
		//������ʱ��Ƭ
				g2d.setColor(Color.gray);
				for(int i=0;i<m;i++)
				{
					VirtualCluster vc = vclist.getList().get(i);
					Slot p = vc.getEmptyHead_old().getNextSlot();
					while(p!=null)
					{
						String mid = p.getVmid();
						int startx = this.machineX.get(mid);
						int starty = this.machineY.get(mid);
						FuzzyNumber starttime = p.getStart();
						FuzzyNumber endtime = p.getEnd();
						if(p.getNextSlot()!=null) this.checking(p, p.getNextSlot());
						int h = (int)((double)heightunit*0.9);//����ͼ����߶�

						int nPoints = 6;			
						int[] xPoints = new int[nPoints];
						int[] yPoints = new int[nPoints];
						
						xPoints[0] = startx+starttime.getLowValue()/(int) ratio;
						xPoints[1] = startx+starttime.getMostValue()/(int) ratio;
						xPoints[2] = startx+starttime.getHighValue()/(int) ratio;
						xPoints[3] = startx+endtime.getHighValue()/(int) ratio;
						xPoints[4] = startx+endtime.getMostValue()/(int) ratio;
						xPoints[5] = startx+endtime.getLowValue()/(int) ratio;
						
						yPoints[0] = starty;
						yPoints[1] = starty-h/2;
						yPoints[2] = starty-h;
						yPoints[3] = starty-h;
						yPoints[4] = starty-h/2;
						yPoints[5] = starty;
						
						
						g2d.fillPolygon(xPoints, yPoints, nPoints);				
						p = p.getNextSlot();
					}
					p = vc.getEmptyHead_new().getNextSlot();
					while(p!=null)
					{
						String mid = p.getVmid();
						int startx = this.machineX.get(mid);
						int starty = this.machineY.get(mid);
						FuzzyNumber starttime = p.getStart();
						FuzzyNumber endtime = p.getEnd();
						if(p.getNextSlot()!=null) this.checking(p, p.getNextSlot());
						int h = (int)((double)heightunit*0.9);//����ͼ����߶�

						int nPoints = 6;			
						int[] xPoints = new int[nPoints];
						int[] yPoints = new int[nPoints];
						
						xPoints[0] = startx+starttime.getLowValue()/(int) ratio;
						xPoints[1] = startx+starttime.getMostValue()/(int) ratio;
						xPoints[2] = startx+starttime.getHighValue()/(int) ratio;
						xPoints[3] = startx+endtime.getHighValue()/(int) ratio;
						xPoints[4] = startx+endtime.getMostValue()/(int) ratio;
						xPoints[5] = startx+endtime.getLowValue()/(int) ratio;
						
						yPoints[0] = starty;
						yPoints[1] = starty-h/2;
						yPoints[2] = starty-h;
						yPoints[3] = starty-h;
						yPoints[4] = starty-h/2;
						yPoints[5] = starty;
						
						
						g2d.fillPolygon(xPoints, yPoints, nPoints);				
						p = p.getNextSlot();
					}
				}
				
		
		for(int i=0;i<n;i++)
		{	
			for(int j=0;j<m;j++)
			{
				FAssignment time = schedule.getJob(i).getAssignment(j);
				Color c = cmap.get(i);
				g2d.setColor(c);
//				times[j].print();
				String mid = time.getMid();
				FuzzyNumber starttime = time.getStart();
				FuzzyNumber endtime = time.getEnd();
				int startx = machineX.get(mid);
				int starty = machineY.get(mid);
				FuzzyNumber deadline = schedule.getJob(i).getDeadline();

				int h = (int)((double)heightunit*0.9);//����ͼ����߶�

				int nPoints = 6;			
				int[] xPoints = new int[nPoints];
				int[] yPoints = new int[nPoints];
				
				xPoints[0] = startx+starttime.getLowValue()/(int) ratio;
				xPoints[1] = startx+starttime.getMostValue()/(int) ratio;
				xPoints[2] = startx+starttime.getHighValue()/(int) ratio;
				xPoints[3] = startx+endtime.getHighValue()/(int) ratio;
				xPoints[4] = startx+endtime.getMostValue()/(int) ratio;
				xPoints[5] = startx+endtime.getLowValue()/(int) ratio;
				
				yPoints[0] = starty;
				yPoints[1] = starty-h/2;
				yPoints[2] = starty-h;
				yPoints[3] = starty-h;
				yPoints[4] = starty-h/2;
				yPoints[5] = starty;
				
				
				g2d.fillPolygon(xPoints, yPoints, nPoints);				
				
				g2d.setColor(Color.black);
				int length = endtime.getHighValue()-starttime.getLowValue();
				g2d.setFont(new Font("New Times Roman",Font.BOLD,20));
				g2d.drawString(Integer.toString(i), startx + starttime.getLowValue()
						/(int) ratio + (length/(int)ratio) / 2, starty - h/2);
				//������
//				g2d.drawLine(startx+starttime.getMostValue()/(int) ratio, starty-h/2, startx+starttime.getMostValue()/(int) ratio, starty);
//				g2d.drawLine(startx+endtime.getMostValue()/(int) ratio, starty-h/2, startx+endtime.getMostValue()/(int) ratio, starty-h);
				}
		}
		
		
		
	}

	public void draw(int eventNum,HashMap<Integer,Color> cmap,boolean issave) {
		if ( vclist == null)
			return;
//		this.genRanColor();

		height = this.estimateHeight();
		width = this.estimateWidth();
		//System.out.println("height=" + height + " width=" + width);
		
		image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		

		Graphics2D g2d = (Graphics2D) image.getGraphics();
		g2d.setColor(Color.white);
		g2d.fillRect(0, 0, width, height);
		g2d.setColor(Color.black);

		// ��ʼ������
		this.drawMachine(g2d);

		// ��ʼ��timetable
		drawJobs(g2d,cmap);
		
		this.drawArriveInfo(g2d,eventNum);
		showpanel.setPreferredSize(new Dimension(image.getWidth(), image
				.getHeight()));
		showpanel.updateUI();
		
		if(issave)
		{
			try {
				
				ImageIO.write(image, "png", new File(C.ImagePath+"\\"+String.valueOf(System.currentTimeMillis())+".png"));
				System.out.println(C.ImagePath+"\\"+String.valueOf(System.currentTimeMillis())+".png");
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
	}

	// public void setData(Job2Set jobs, TimeTable timetable) {
	// this.jobs = jobs;
	// this.timetable = timetable;
	// cmap = this.genRanColor();
	// }

	public VirtualClusterList getVclist() {
		return vclist;
	}

	public void setVclist(VirtualClusterList vclist) {
		this.vclist = vclist;
	}

	/**
	 * Create the frame.
	 */
	public ShowDESResult_Fuzzy( VirtualClusterList vclist,Schedule schedule,int m,int n,ArrayList<ArrayList<Integer>>arriveSeq,ArrayList<Integer>arriveTime) {
		this.vclist = vclist;
		this.schedule = schedule;
		this.arriveSeq = arriveSeq;
		this.arriveTime = arriveTime;
		machineX = new HashMap<String,Integer>();
		machineY = new HashMap<String,Integer>();
		this.m = m;
		this.n = n;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 2500, 2000);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 2300, 1500);
		contentPane.add(scrollPane);

		showpanel = new JPanel() {
			public void paint(Graphics g) {
				super.paint(g);
				if (image != null) {
					g.clearRect(0, 0, this.getWidth(), this.getHeight());
					g.drawImage(image, 0, 0, null);
					g.dispose();
				}
			}
		};
		showpanel.setBackground(Color.WHITE);
		scrollPane.setViewportView(showpanel);
		showpanel.setLayout(null);

		

		
	}

	public void setN(int n) {
		this.n = n;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		
	}
}
