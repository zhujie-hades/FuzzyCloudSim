package Experiments;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Random;

import Jobs.FJOB;
import Jobs.FJOBS;
import Jobs.JobRealInfo;
import Tools.AliDataProcess;
import element.FuzzyNumber;

public class BenmarkInstanceGenerator {

	long seed;	
	int m;
	int n;
	int ptLow;
	int ptHigh;
	double deviation;
	String location;
	int delayLow;
	int delayHigh;
	int lambda;
	double df;
	public BenmarkInstanceGenerator(String location, int m,int n,int plow,int phigh,int delayLow,int delayHigh,int lambda,double df,double deviation)
	{
		this.m = m;
		this.n = n;
		this.ptLow = plow;
		this.ptHigh = phigh;
		this.deviation = deviation;
		this.location = location;
		this.delayHigh = delayHigh;
		this.delayLow = delayLow;
		this.lambda = lambda;
		this.df = df;
	}
	
	public void OneInstanceGeneratingPossion()
	{
		String seedFileName = m+"_seed.txt";
		File file = new File(location+"\\"+seedFileName);
		ArrayList<Long> seedArray = new ArrayList<Long>();
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					new FileInputStream(file), "UTF-8"));
			String str = null;
			while((str=reader.readLine())!=null)
			{
				seedArray.add(Long.parseLong(str));				
			}
			reader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int size = seedArray.size();
		for(int i=0;i<size;i++)
		{
			long seed = seedArray.get(i);
			JobRealInfo monitor = new JobRealInfo(m);
			FJOBS jobs = this.generate_fuzzy_job(seed,deviation,monitor);
			ArrayList<Double> dfList = Distribution.getDFList(df, n);	
			ArrayList<Integer> arriveTimeList = Distribution.getArriveTime(lambda, n);			
			this.writeIntoTxt(jobs,i,dfList,arriveTimeList,monitor);
		}		
	}
	
	public void OneInstanceGeneratingUniform(int lambdalow,int lambdahigh)
	{
		String seedFileName = m+"_seed.txt";
		File file = new File(location+"\\"+seedFileName);
		ArrayList<Long> seedArray = new ArrayList<Long>();
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					new FileInputStream(file), "UTF-8"));
			String str = null;
			while((str=reader.readLine())!=null)
			{
				seedArray.add(Long.parseLong(str));				
			}
			reader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int size = seedArray.size();
		for(int i=0;i<size;i++)
		{
			long seed = seedArray.get(i);
			JobRealInfo monitor = new JobRealInfo(m);
			FJOBS jobs = this.generate_fuzzy_job(seed,deviation,monitor);
			ArrayList<Double> dfList = Distribution.getDFList(df, n);	
			ArrayList<Integer> arriveTimeList = Distribution.getArriveTimeUniform(lambdalow, lambdahigh, n);
			
			this.writeIntoTxt(jobs,i,dfList,arriveTimeList,monitor);
		}		
	}
	
	public void OneInstanceGeneratingAli(String fileprefix)
	{
		String seedFileName = m+"_seed.txt";
		File file = new File(location+"\\"+seedFileName);
		ArrayList<Long> seedArray = new ArrayList<Long>();
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					new FileInputStream(file), "UTF-8"));
			String str = null;
			while((str=reader.readLine())!=null)
			{
				seedArray.add(Long.parseLong(str));				
			}
			reader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int size = seedArray.size();
		for(int i=0;i<12;i++)
		{
			long seed = seedArray.get(i%10);
			JobRealInfo monitor = new JobRealInfo(m);
			AliDataProcess ap = new AliDataProcess();
			ap.getAliInfo(fileprefix, i,n*m);
			ArrayList<Integer> arriveTimeList = ap.getArriveTimeList(m);
			if(ap.getJobnumber()<n)
			{
				System.out.println("unsufficient tasks n="+ap.getJobnumber());
				n = ap.getJobnumber();
			}
			ArrayList<Double> dfList = Distribution.getDFList(df, n);	
			FJOBS jobs = this.generate_fuzzy_job_ali(seed,deviation,monitor,ap);
			this.writeIntoTxt(jobs,i,dfList,arriveTimeList,monitor);
		}		
	}
	
	public void writeIntoTxt(FJOBS jobs,int index,ArrayList<Double> dfList,ArrayList<Integer> arriveTimeList,JobRealInfo monitor)
	{
		String filename = m+"_"+index+"_["+this.ptLow+","+this.ptHigh+"]_["+this.delayLow+","+this.delayHigh+"]"+"_"+lambda+"_"+df+"_"+String.valueOf(deviation).substring(0, 3)+".txt";
		try {
			FileWriter fileWriter=new FileWriter(location+"\\"+filename);
			for(int i=0;i<n;i++)
			{
				FJOB job = jobs.getJob(i);
				String str = "";
				for(int j=0;j<m;j++)
				{
					str+=job.getOp()[j].toString();
				}
				str+=",";
				for(int j=0;j<m;j++)
				{
					str+=monitor.getJobRealOpLength(i, j)+",";
				}
				for(int j=0;j<m;j++)
				{
					str+=job.getLatency()[j].toString();
				}
				str+=",";
				for(int j=0;j<m;j++)
				{
					str+=monitor.getJobRealDelay(i, j)+",";
				}
				str+=dfList.get(i)+",";
				str+=arriveTimeList.get(i);				
				fileWriter.write(str);
				fileWriter.write("\n");
			}			
			fileWriter.flush();
			fileWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public FJOBS generate_fuzzy_job_ali(long newseed,double devation,JobRealInfo monitor,AliDataProcess ap)
	{
		this.seed = newseed;
		FJOBS jobs = new FJOBS(n,m);
		int e = ap.getSize();
		Random r= new Random();
		int count = 0;
//		ap.print();
		for(int i=0;i<e;i++)
		{
			AliItem item = ap.getAlilist().get(i);
			int jobnum = item.getTaskNum()/m;
			double avg = item.getAvgTime()*1000;
			for(int j=0;j<jobnum;j++)
			{
							
				FuzzyNumber[] op = new FuzzyNumber[m];
				for(int k=0;k<m;k++)
				{
					double gauss = r.nextGaussian();
					int real = (int) (gauss*devation*avg+avg);
//					System.out.print(gauss+"*"+devation+"*"+avg+"+"+avg+"="+real+"\t");
					while(real<=10) 
					{
						real = (int) (r.nextGaussian()*devation*avg+avg);
					}
					int low = (int) (real*(1-devation));
					int high = (int) (real*(1+devation));
//					System.out.print("start avg="+avg+","+gauss+","+low+","+high+","+real);
					int most = RealTimeGenerator.getTimeAli(low,high,real,deviation);
//					System.out.println("done");
					monitor.addJobRealOpLength(count, k, real);
					op[k] = new FuzzyNumber(low,high,most);
				}
				FuzzyNumber[] latency = new FuzzyNumber[m];
				for(int k=0;k<m;k++)
				{
					int low = unif(this.delayLow,(int)(this.delayHigh/(1+devation)));				
					int high = (int)(low*(1+2*devation));
					int most = unif(low+1,high-1);
					int real = RealTimeGenerator.getTime(low,high,most,devation);
					monitor.addJobRealDelay(count, k, real);
					latency[k] = new FuzzyNumber(low,high,most);
				}
				FJOB job = new FJOB(m,op,latency,-1,-1);
				jobs.addJob(job);
//				job.print(count);
				count++;
//				System.out.println(count);
			}
			
		}
		
		return jobs;
	}
	
	public FJOBS generate_fuzzy_job(long newseed,double devation,JobRealInfo monitor)
	{
		this.seed = newseed;
		FJOBS jobs = new FJOBS(n,m);
		for(int i=0;i<n;i++)
		{
			FuzzyNumber[] op = new FuzzyNumber[m];
			for(int j=0;j<m;j++)
			{				
				int value1 = unif(this.ptLow,(int)(this.ptHigh/(1+devation)));				
				int value3 = (int)(value1*(1+devation));
				int value2 = unif(value1+1,value3-1);
				int realvalue = RealTimeGenerator.getTime(value1,value3,value2,devation);
				monitor.addJobRealOpLength(i, j, realvalue);
				op[j] = new FuzzyNumber(value1,value3,value2);
			}
			FuzzyNumber[] latency = new FuzzyNumber[m];
			for(int j=0;j<m;j++)
			{
				int value1 = unif(this.delayLow,(int)(this.delayHigh/(1+devation)));				
				int value3 = (int)(value1*(1+2*devation));
				int value2 = unif(value1+1,value3-1);
				int realvalue = RealTimeGenerator.getTime(value1,value3,value2,devation);
				monitor.addJobRealDelay(i, j, realvalue);
				latency[j] = new FuzzyNumber(value1,value3,value2);
			}
			
			
			FJOB job = new FJOB(m,op,latency,-1,-1);
			jobs.addJob(job);
		}		
		return jobs;
	}
	private int unif(int low,int high)
	{
		long m = 2147483647;
		long a = 16807;
		long b = 127773;
		long c = 2836;
		double value_0_1;
		long k = seed/b;
		seed = a *(seed%b)-k*c;
		if(seed<0)
		{
			seed = seed + m;
		}
		value_0_1 = seed/(double)m;
		return (int)(low + Math.floor(value_0_1 * (high - low + 1)));
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int low = 1000;
		int high = 10000;
		int delaylow = 10;//10 70 250
		int delayhigh = 15;//15 80 280
//		int delaylow = 10;//10 70 250
//		int delayhigh = 15;//15 80 280
//		int delaylow = 70;//10 70 250
//		int delayhigh = 80;//15 80 280
		int m =9;		
		
		String location = "G:\\Dynamic_Instances_newFuzzy\\m="+m+" Possion";
		int n = 10000;			
		double df =0;
		int lambda = -1;
		double deviation = 0.1;
		int wid = 0;
		String prefix = "D:\\��������\\Dynamic_Instances_newFuzzy_Ali\\ali_instance2017";
		for(int k=0;k<3;k++)
		{
			deviation = 0.1+k*0.1;
			
				for(int i=0;i<4;i++)
				{
					df =1.5+i*0.5;	
					System.out.println("df="+df);
					
					   for(lambda=5;lambda<=50;lambda+=5)
					   {
							BenmarkInstanceGenerator gen = new BenmarkInstanceGenerator(location,m,n,low,high,delaylow,delayhigh,lambda,df,deviation);
							gen.OneInstanceGeneratingPossion();
					   }
//						gen.OneInstanceGeneratingAli(prefix);	
													
								
				}
			
		}
		
	}

}
