package Experiments;

import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.Random;

import Jobs.FJOB;
import Jobs.FJOBS;
import Jobs.JobRealInfo;
import Tools.TextOperation;
import element.FuzzyNumber;

public class InstanceGenerator {


	public static FJOBS getPiossonInstance(String id,int m,int lastTime,ArrayList<ArrayList<Integer>>arriveSets,ArrayList<Integer> arriveTimeList,JobRealInfo monitor,String inslocation)
	{

		ArrayList<Integer> arriveNumList = new ArrayList<Integer>();
		FJOBS jobs = TextOperation.readDynamicfromtxt(inslocation, id,m,lastTime,arriveNumList,monitor);
		int H = arriveNumList.size();

		int index = 0;		
	
		for(int i=0;i<H;i++)
		{		
			int num = arriveNumList.get(i);
			arriveTimeList.add(i*1000);
			ArrayList<Integer> list = new ArrayList<Integer>();
			for(int j=0;j<num;j++)
			{
				list.add(index);
				index++;
			}
			arriveSets.add(list);			
		}
		
		//jobs.print();
		return jobs;
}
	
	public static FJOBS getAliInstance(String id,int m,int lastTime,ArrayList<ArrayList<Integer>>arriveSets,ArrayList<Integer> arriveTimeList,JobRealInfo monitor,String inslocation)
	{

		ArrayList<Integer> arriveNumList = new ArrayList<Integer>();
		FJOBS jobs = TextOperation.readDynamicfromtxt(inslocation, id,m,lastTime,arriveNumList,monitor);
		int H = arriveNumList.size();

		int index = 0;		
	
		for(int i=0;i<H;i++)
		{		
			int num = arriveNumList.get(i);
			arriveTimeList.add(i*1000);
			ArrayList<Integer> list = new ArrayList<Integer>();
			for(int j=0;j<num;j++)
			{
				list.add(index);
				index++;
			}
			arriveSets.add(list);			
		}
		
		//jobs.print();
		return jobs;
}
	
	
	public static FJOBS getUniformInstance(String id,int m,int lastTime,ArrayList<ArrayList<Integer>>arriveSets,ArrayList<Integer> arriveTimeList,JobRealInfo monitor,String inslocation)
	{

		ArrayList<Integer> arriveNumList = new ArrayList<Integer>();
		FJOBS jobs = TextOperation.readDynamicfromtxt(inslocation, id,m,lastTime,arriveNumList,monitor);
		int H = arriveNumList.size();

		int index = 0;
		
	
		for(int i=0;i<H;i++)
		{		
			int num = arriveNumList.get(i);
			arriveTimeList.add(i*1000);
			ArrayList<Integer> list = new ArrayList<Integer>();
			for(int j=0;j<num;j++)
			{
				list.add(index);
				index++;
			}
			arriveSets.add(list);			
		}
		
		//jobs.print();
		return jobs;
}

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<ArrayList<Integer>> arriveSets = new ArrayList<ArrayList<Integer>>();
		ArrayList<Integer> arriveTimeList = new ArrayList<Integer>();
		int m = 3;
		JobRealInfo monitor = new JobRealInfo(m);
		FJOBS fjobs = InstanceGenerator.getAliInstance("3_0_[1000,10000]_[250,280]_-1_1.5_0.1", 3, 120000, arriveSets, arriveTimeList, monitor, "D:\\��������\\Dynamic_Instances_newFuzzy\\m=3 Ali");
//		fjobs.print(monitor);
		for(int i=0;i<arriveTimeList.size();i++)
			System.out.println(i+"\t"+arriveTimeList.get(i)+"\t"+arriveSets.get(i).size());
	}

}
