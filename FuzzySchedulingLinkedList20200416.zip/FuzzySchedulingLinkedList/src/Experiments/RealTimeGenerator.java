package Experiments;

import java.util.Random;

public class RealTimeGenerator {
	
	public static int getTime(int low,int high,int most, double e)
	{
		Random r = new Random();
		double gauss = r.nextGaussian();
		int result = (int) (gauss*e*most+most);
		while(!RealTimeGenerator.passChecking(low, high, most, result))
		{
			result =  (int) (r.nextGaussian()*e*most+most);
		}
		return result;
	}
	
	public static int getTimeAli(int low,int high,int real, double e)
	{
		Random r = new Random();
		double gauss = r.nextGaussian();
		int result = (int) (gauss*e*real+real);
		while(!RealTimeGenerator.passChecking(low, high, real, result))
		{
			result =  (int) (r.nextGaussian()*e*real+real);
		}
		return result;
	}
	
	
	public static boolean passChecking(double low,double high,double most,double real)
	{
		if(real<=low||real>=high) return false;
		else return true;
	}
	
	
//	public static boolean passChecking(double low,double high,double most,double real)
//	{
//		if(real==most) return true;
//		else if(real<=low||real>=high) return false;		 
//		double rate = 0;
//		if(real>low&&real<most)
//		{
//			rate = real/(most-low)+low/(low-most);
//		}
//		else
//		{
//			rate = real/(most-high)+high/(high-most);
//		}
//		
//		Random r = new Random();
//		double ran = r.nextDouble();
//		
//		if(ran<=rate) return true;
//		return false;
//	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count=0;
		double e=0.1;
		int most = 1000;
		int low = (int) (most*(1-e));
		int high = (int)(most*(1+e));
		
		for(int i=0;i<10;i++)
		{
			int item =  RealTimeGenerator.getTimeAli(low, high, most,e);
			count += item;
			System.out.print(item+"\t");			
		}
		System.out.println(count/10);
		count=0;
		e=0.2;
		 most = 1000;
		 low = (int) (most*(1-e));
		 high = (int)(most*(1+e));
		
		for(int i=0;i<10;i++)
		{
			int item =  RealTimeGenerator.getTimeAli(low, high, most,e);
			count += item;
			System.out.print(item+"\t");			
		}
		System.out.println(count/10);
		 count=0;
		 e=0.3;
		 most = 1000;
		 low = (int) (most*(1-e));
		 high = (int)(most*(1+e));
		
		for(int i=0;i<10;i++)
		{
			int item =  RealTimeGenerator.getTimeAli(low, high, most,e);
			count += item;
			System.out.print(item+"\t");			
		}
		System.out.println(count/10);
	}

}
