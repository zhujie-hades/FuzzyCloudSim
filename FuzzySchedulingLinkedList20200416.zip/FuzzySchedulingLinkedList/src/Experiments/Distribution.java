package Experiments;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Random;

public class Distribution {


//	public Piosson(int lambda, int n) {
//		this.lambda = lambda;
//		num = n;
//		output = new ArrayList<Integer>();
//		EL = Math.exp(-lambda);
//		System.out.println("exp(-lambda)=" + EL);
//		r = new Random();
//		outputOne = new ArrayList<Double>();
//	}
	
	public static ArrayList<Integer> getArriveNum(int lambda,int n)
	{
		ArrayList<Integer> output = new ArrayList<Integer>();
		double EL = Math.exp(-lambda);
		Random r  = new Random();
		Distribution.runArriveNum(n, EL, output,r);		
		return output;
	}
	
	
	
	public static ArrayList<Integer> getArriveTime(int lambda,int n)
	{
		ArrayList<Integer> arrNumList = new ArrayList<Integer>();
		ArrayList<Integer> arrTimeList = new ArrayList<Integer>();
		double EL = Math.exp(-lambda);
		Random r  = new Random();
		Distribution.runArriveNumMax(n, EL, arrNumList,r);
		int time = 0;
		for(int i=0;i<arrNumList.size();i++)
		{
			for(int j=0;j<arrNumList.get(i);j++)
			{
				arrTimeList.add(time*1000);
			}
			time++;
		}
		return arrTimeList;
	}
	
	public static ArrayList<Integer> getArriveTimeUniform(int low,int high,int n)
	{
		ArrayList<Integer> arrNumList = new ArrayList<Integer>();
		ArrayList<Integer> arrTimeList = new ArrayList<Integer>();
	
		Random r  = new Random();
		Distribution.runArriveNumUniform(n, low,high, arrNumList,r);
		int time = 0;
		for(int i=0;i<arrNumList.size();i++)
		{
			for(int j=0;j<arrNumList.get(i);j++)
			{
				arrTimeList.add(time*1000);
			}
			time++;
		}
		return arrTimeList;
	}
	
	public static ArrayList<Double> getDFList(double expDF,int n)
	{
		ArrayList<Integer> temp = new ArrayList<Integer>();
		ArrayList<Double> output = new ArrayList<Double>();
		int lambda = (int)(expDF*100);
		double EL = Math.exp(-lambda);
		Random r  = new Random();
		Distribution.runDFList(n, EL, temp,r);		
		for(int i=0;i<n;i++)
		{
			int num = temp.get(i);
			output.add((double)num/100);
		}
		//System.out.println(output.toString());
		return output;
	}
	public static double getBetween01(Random r) {
		double result = r.nextDouble();
		while (result == 0)
			result = r.nextDouble();
		return result;
	}
	public static void runArriveNum(int H,double EL,ArrayList<Integer>output,Random r) {

		double lastx = 1;
		double curx = 1;
		int k = 1;
		//int max = 0;
		int count = 0;
		while (true) {
			curx = lastx * Distribution.getBetween01(r);
			// System.out.println("["+curx+","+lastx+"] k="+k);

			if (EL <= lastx && EL > curx) {

//				if (k < num) {
					output.add(k);
					count++;
					if(count==H) break;
//					//if(k>max) max = k;
//				} else {
//					output.add(num);
//					//if(num>max) max = num;
//					
//				}
//				num -= k;
				
				k = 1;
				curx = 1;
				lastx = Distribution.getBetween01(r);

				continue;
			} else if (lastx < EL) {
				//output.add(0);
				k = 1;
				curx = 1;
				lastx = Distribution.getBetween01(r);
				
			}
			k++;
			lastx = curx;
		}
		
		//System.out.println(output.toString());
		/*int size = output.size();
		for(int i=0;i<size;i++)
		{
			outputOne.add( (double)output.get(i)/(double)max);
		}
		System.out.println("max="+max);
		System.out.println(outputOne.toString());*/
	}
	
	public static void runArriveNumMax(int max,double EL,ArrayList<Integer>output,Random r) {

		double lastx = 1;
		double curx = 1;
		int k = 1;
		//int max = 0;
		int count = 0;
		while (true) {
			curx = lastx * Distribution.getBetween01(r);
			// System.out.println("["+curx+","+lastx+"] k="+k);

			if (EL <= lastx && EL > curx) {

//				if (k < num) {
					output.add(k);
					count+=k;
					if(count>=max) break;
//					//if(k>max) max = k;
//				} else {
//					output.add(num);
//					//if(num>max) max = num;
//					
//				}
//				num -= k;
				
				k = 1;
				curx = 1;
				lastx = Distribution.getBetween01(r);

				continue;
			} else if (lastx < EL) {
				//output.add(0);
				k = 1;
				curx = 1;
				lastx = Distribution.getBetween01(r);
				
			}
			k++;
			lastx = curx;
		}
		
		//System.out.println(output.toString());
		/*int size = output.size();
		for(int i=0;i<size;i++)
		{
			outputOne.add( (double)output.get(i)/(double)max);
		}
		System.out.println("max="+max);
		System.out.println(outputOne.toString());*/
	}
	
	public static void runArriveNumUniform(int n,int low, int high,ArrayList<Integer>output,Random r) {

		int count = 0;
		while(true)
		{
			int k = r.nextInt(high-low+1)+low;
			output.add(k);
			count += k;
			if(count>=n) break;
			
		}
//		System.out.println(output.toString());
	}

	public static void runDFList(int num,double EL,ArrayList<Integer>output,Random r) {

		double lastx = 1;
		double curx = 1;
		int k = 1;
		//int max = 0;
		while (num > 0) {
			curx = lastx * Distribution.getBetween01(r);
			// System.out.println("["+curx+","+lastx+"] k="+k);

			if (EL <= lastx && EL > curx) {

				
					output.add(k);
					//if(k>max) max = k;
				num--;
				
				k = 1;
				curx = 1;
				lastx = Distribution.getBetween01(r);

				continue;
			} else if (lastx < EL) {
				//output.add(0);
				k = 1;
				curx = 1;
				lastx = Distribution.getBetween01(r);				
			}
			k++;
			lastx = curx;
		}
		
		//System.out.println(output.toString());
		/*int size = output.size();
		for(int i=0;i<size;i++)
		{
			outputOne.add( (double)output.get(i)/(double)max);
		}
		System.out.println("max="+max);
		System.out.println(outputOne.toString());*/
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<Double> output = Distribution.getDFList(1/1000, 100);
		System.out.println(output.toString());
//		int size = output.size();
//		ArrivingTimeGenerator at = new ArrivingTimeGenerator(1000,size);
//		at.run();
	}

	
}
