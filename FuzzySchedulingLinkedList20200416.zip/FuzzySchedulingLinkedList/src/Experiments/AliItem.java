package Experiments;

public class AliItem {
	
	int arriveTime;
	int taskNum;
	double avgTime;
	
	public void print()
	{
		System.out.println("at="+arriveTime+"\ttn="+taskNum+"\tavgTime="+avgTime);
	}
	
	public AliItem(int at,int tn,double avg)
	{
		this.arriveTime = at;
		this.taskNum = tn;
		this.avgTime = avg;
	}
	
	public int getArriveTime() {
		return arriveTime;
	}
	public int getTaskNum() {
		return taskNum;
	}
	public double getAvgTime() {
		return avgTime;
	}
}
