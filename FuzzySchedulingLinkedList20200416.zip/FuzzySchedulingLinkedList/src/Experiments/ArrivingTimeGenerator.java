package Experiments;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;

public class ArrivingTimeGenerator {


	public static ArrayList<Integer> getArrivingTime(int end, int pnum)
	{
		int T = end/pnum;
		ArrayList<Integer> output = new ArrayList<Integer>();
//		Random r = new Random();
//		ArrayList<Integer> pointlist = new ArrayList<Integer>();
//		for(int i=1;i<end;i++)
//		{
//			pointlist.add(i);
//		}		
//		output.add(0);
//		output.add(end);
//		for(int i=2;i<pnum;i++)
//		{		
//			int point = r.nextInt(pointlist.size());
//			output.add(pointlist.get(point));
//			pointlist.remove(point);
//		}
//		ArrivingTimeGenerator.orderOutput(output);
		for(int i=0;i<pnum;i++)
		{
			output.add(T*i);
		}
		return output;
	}
	
	public static void orderOutput(ArrayList<Integer> output)
	{
		int size = output.size();
		for(int i=0;i<size;i++)
		{
			for(int j=i+1;j<size;j++)
			{
				int first = output.get(i);
				int second = output.get(j);
				if(first>second)
				{
					output.set(i, second);
					output.set(j, first);
				}
			}
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
