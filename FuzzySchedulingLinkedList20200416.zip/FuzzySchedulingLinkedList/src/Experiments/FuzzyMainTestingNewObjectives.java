package Experiments;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;

import Jobs.FJOB;
import Jobs.FJOBS;
import Jobs.JobRealInfo;
import ResourceManagement.VirtualClusterList;
import SchedulePlan.NewObjectives;
import SchedulePlan.Schedule;
import Tools.TextOperation;
import Tools.ValidationCheckingTool;
import Tools.CO;
import des.DESFramework;
import element.C;
import element.FuzzyNumber;
import element.Parameters;

public class FuzzyMainTestingNewObjectives {
	ArrayList<Parameters> deslist;
	String inslocation;
	String resultlocation;
	
	
	public FuzzyMainTestingNewObjectives(String inslocation,String tolocation)
	{
		this.inslocation = inslocation;
		this.resultlocation = tolocation;
		deslist = new ArrayList<Parameters>();
		
	}
	
	private NewObjectives runAlgNewObj(int m,int algid, ArrayList<ArrayList<Integer>> arriveSets,ArrayList<Integer> arriveTimeList,FJOBS jobs,int onpremise,JobRealInfo realinfo,HashMap<Integer,Color> cmap)
	{
		int[] old = new int[m];
		for(int s=0;s<m;s++)
			old[s] = onpremise;
		int n=jobs.getN();
		Parameters setting = deslist.get(algid);
		Schedule schedule =  new Schedule(n, m,jobs,setting);
		DESFramework des = new DESFramework(arriveSets,arriveTimeList, schedule, m, n, old, setting , realinfo);
		VirtualClusterList vclist = des.run(cmap,false);	
//		if(!ValidationCheckingTool.JobCheckingConsiderDelay(vclist, jobs, monitor))//�ݲ�����delay�����
//		{
//			System.out.println("WRONGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG on job checking");
//			CommonOperation.printLine();
//		}
		if(!ValidationCheckingTool.JobChecking(vclist, jobs, realinfo))
		{
			System.out.println("WRONGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG on job checking");
			CO.printLine();
		}
		if(!ValidationCheckingTool.VMChecking(vclist))
		{
			System.out.println("WRONGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG on virtual cluster list");
			CO.printLine();
		}
		//���ü�����metric
//		Objective obj = new Objective();
//		obj.setRentedVMnumber(vclist.getNewMachineNum());
//		obj.setSatisfactionRate(vclist.satisfactionRate(jobs, 1));//price ����Ϊ1���ܴ���bug
//		obj.setTotalUsageTimeOnRented(vclist.getTotalUsageTimeOnRentedVMs());
		
		NewObjectives newobj = new NewObjectives(schedule,vclist);
		
//		newobj.print();
		return newobj;
	}
	
	private NewObjectives runAlg(int m,int algid, ArrayList<ArrayList<Integer>> arriveSets,ArrayList<Integer> arriveTimeList,FJOBS jobs,int onpremise,JobRealInfo monitor,HashMap<Integer,Color> cmap,boolean issave)
	{
		int[] old = new int[m];
		for(int s=0;s<m;s++)
			old[s] = onpremise;
		int n=jobs.getN();
		Parameters setting = deslist.get(algid);
		Schedule schedule =  new Schedule(n, m,jobs,setting);
		DESFramework des = new DESFramework(arriveSets,arriveTimeList, schedule, m, n, old, setting , monitor);
		VirtualClusterList vclist = des.run(cmap,issave);	
//		if(!ValidationCheckingTool.JobCheckingConsiderDelay(vclist, jobs, monitor))//�ݲ�����delay�����
//		{
//			System.out.println("WRONGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG on job checking");
//			CommonOperation.printLine();
//		}
		if(!ValidationCheckingTool.JobChecking(vclist, jobs, monitor))
		{
			System.out.println("WRONGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG on job checking");
			CO.printLine();
		}
		if(!ValidationCheckingTool.VMChecking(vclist))
		{
			System.out.println("WRONGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG on virtual cluster list");
			CO.printLine();
		}
		//���ü�����metric
		NewObjectives obj = new NewObjectives(schedule,vclist);
		
//		System.out.println("ALL="+vclist.getTotalMachineNum());
//		System.out.println("NEW="+vclist.getNewMachineNum());
	
		return obj;
	}
	
	public void oneSingleTestNewObj(String instanceid,int algIndex,int m,int lambda,double df,double theta,double wp,String distribution,boolean paint)
	{
			
			ArrayList<ArrayList<Integer>> arriveSets = new ArrayList<ArrayList<Integer>>();
			ArrayList<Integer> arriveTimeList = new ArrayList<Integer>();
			DecimalFormat format_4 =new   java.text.DecimalFormat("#.####"); 
			DecimalFormat format_2 =new   java.text.DecimalFormat("#.##"); 
//			DecimalFormat format_1 =new   java.text.DecimalFormat("#.#"); 
			int lastTime = C.LASTTIME;
			int onpremise = 0;
			if(lambda==-1) onpremise = OnPremiseSetting.getOi(25, m, df,theta);
			else onpremise = OnPremiseSetting.getOi(lambda, m, df,theta);
			double best_rnum = 20000;
			double best_rtime = -1;
			double best_ed = 20000;
			JobRealInfo monitor = new JobRealInfo(m);
			FJOBS jobs = null;
			if(distribution.equalsIgnoreCase("Uniform"))
			{
				jobs = InstanceGenerator.getUniformInstance(instanceid, m, lastTime, arriveSets, arriveTimeList, monitor, this.inslocation);
			}
			else
			{
				jobs = InstanceGenerator.getPiossonInstance(instanceid, m, lastTime, arriveSets, arriveTimeList, monitor, this.inslocation);
			}
			
			
				IntializeDES(wp);
				
					
					Parameters p = deslist.get(algIndex);
//					monitor.Clear();//�����һ�ε����㷨�ļ����м���
//					jobs.update(p.getJD(),p.isLooseDeadline());
					
					NewObjectives obj = null;
					if(paint)
					obj = runAlgNewObj(m,algIndex,arriveSets,arriveTimeList,jobs, onpremise,monitor,this.genRanColor(jobs.getN()));	
					else
					obj = runAlgNewObj(m,algIndex,arriveSets,arriveTimeList,jobs, onpremise,monitor,null);	

					obj.print();
//					String commonstr = instanceid+"\t"+"DES"+algIndex+"\t"+p.getTMStrategy()+"\t"+p.VNDflag()+"\t"+p.JSCflag()+"\t"+p.getJD()+"\t"+p.isLooseDeadline()+"\t"+arriveSets.size()+"\t"+lambda+"\t"+df+"\t"+m+"\t"+onpremise+"\t"+wp+"\t"+metric+"\t"+obj.getRentedVMnumber()+"\t"+obj.getTotalUsageTimeOnRented()+"\t"+format_4.format(obj.getSatisfactionRate())+"\t";
//					
//				
//			
//			System.out.println();
//			String title = 	"Instanceid\t"+"ALG\t"+"TMflag\t"+"VNDflag\t"+"JCSflag\t"+"JD\t"+"isLooseDeadline\t"+"eventNum\t"+"lambda\t"+"df\t"+"m\t"+"onpremise\t"+"wp\t"+"innerObj\t"+"metic_rNum\t"+"metic_rTime\t"+"SDegree\t";
//			System.out.println(title);
//			System.out.print(commonstr);			
	}
	
	
//	public NewObjectives testAdjustedFDES(String instanceid,int m,int lambda,double df,double wp,String distribution)
//	{
//		ArrayList<ArrayList<Integer>> arriveSets = new ArrayList<ArrayList<Integer>>();
//		ArrayList<Integer> arriveTimeList = new ArrayList<Integer>();
////		DecimalFormat format_4 =new   java.text.DecimalFormat("#.####"); 
////		DecimalFormat format_2 =new   java.text.DecimalFormat("#.##"); 
////		DecimalFormat format_1 =new   java.text.DecimalFormat("#.#"); 
//		int lastTime = ParametersRange.lastTime;
//		int onpremise = 0;
//		if(lambda==-1) onpremise = OnPremiseSetting.getOi(25, m, df);
//		else onpremise = OnPremiseSetting.getOi(lambda, m, df);
//		System.out.println("OLD="+onpremise*m);
//		JobProcessingMonitor monitor = new JobProcessingMonitor(m);
//		FJOBS jobs = null;
//		if(distribution.equalsIgnoreCase("Uniform"))
//		{
//			jobs = InstanceGenerator.getUniformInstance(instanceid, m, lastTime, arriveSets, arriveTimeList, monitor, this.inslocation);
//		}
//		else
//		{
//			jobs = InstanceGenerator.getPiossonInstance(instanceid, m, lastTime, arriveSets, arriveTimeList, monitor, this.inslocation);
//		}
//		int[] old = new int[m];
//		for(int s=0;s<m;s++)
//			old[s] = onpremise;
//		int n=jobs.getN();
//		
////		monitor.Clear();//�����һ�ε����㷨�ļ����м���		
//		jobs.update(-1,false);
//		AdjustedFDES afdes = new AdjustedFDES(arriveSets,arriveTimeList, jobs, m, n, old, monitor);
//		NewObjectives obj = afdes.run(null);
//		
//		
//		return obj;
//	}
	
	

	public void oneSingleTest(String instanceid,int algIndex,int metric,int m,int lambda,double df,double theta,double wp,String distribution,boolean paint)
	{
			ArrayList<NewObjectives> objlist = new ArrayList<NewObjectives>();
			ArrayList<String> result = new ArrayList<String>();
			ArrayList<ArrayList<Integer>> arriveSets = new ArrayList<ArrayList<Integer>>();
			ArrayList<Integer> arriveTimeList = new ArrayList<Integer>();
			DecimalFormat format_4 =new   java.text.DecimalFormat("#.####"); 
			DecimalFormat format_2 =new   java.text.DecimalFormat("#.##"); 
//			DecimalFormat format_1 =new   java.text.DecimalFormat("#.#"); 
			int lastTime = C.LASTTIME;
			int onpremise = 0;
			if(lambda==-1) onpremise = OnPremiseSetting.getOi(25, m, df,theta);
			else onpremise = OnPremiseSetting.getOi(lambda, m, df,theta);
			double bestSD = 0;
			int bestFCOST = -1;
			int bestFACOST = -1;
			JobRealInfo monitor = new JobRealInfo(m);
			FJOBS jobs = null;
			if(distribution.equalsIgnoreCase("Uniform"))
			{
				jobs = InstanceGenerator.getUniformInstance(instanceid, m, lastTime, arriveSets, arriveTimeList, monitor, this.inslocation);
			}
			else
			{
				jobs = InstanceGenerator.getPiossonInstance(instanceid, m, lastTime, arriveSets, arriveTimeList, monitor, this.inslocation);
			}
			
			
				IntializeDES(wp);
				
					
					Parameters p = deslist.get(algIndex);
//					monitor.Clear();//�����һ�ε����㷨�ļ����м���
//					jobs.update(p.getJD(),p.isLooseDeadline());
					
					NewObjectives obj = null;
					if(paint)
					obj = runAlg(m,algIndex,arriveSets,arriveTimeList,jobs, onpremise,monitor,this.genRanColor(jobs.getN()),false);	
					else
					obj = runAlg(m,algIndex,arriveSets,arriveTimeList,jobs, onpremise,monitor,null,false);	

					if(obj.getSatisfactionRate()>bestSD) bestSD = obj.getSatisfactionRate();
					if(bestFCOST==-1) bestFCOST = obj.getFCOST();
					if(obj.getFCOST()<bestFCOST) bestFCOST = obj.getFCOST();
					
//					if(bestFACOST==-1) bestFACOST = obj.getACOST();
//					if(obj.getACOST()<bestFACOST) bestFACOST = obj.getACOST();

					objlist.add(obj);
					String commonstr = instanceid+"\t"+"DES"+algIndex+"\t"+p.toString()+"\t"+p.isLooseDeadline()+"\t"+arriveSets.size()+"\t"+lambda+"\t"+df+"\t"+m+"\t"+onpremise+"\t"+wp+"\t"+metric+"\t"+obj.getFCOST()+"\t"+format_4.format(obj.getSatisfactionRate())+"\t";
				
			
			System.out.println();
			String title = 	"Instanceid\t"+"ALG\t"+"TMflag\t"+"VNDflag\t"+"JCSflag\t"+"JD\t"+"isLooseDeadline\t"+"eventNum\t"+"lambda\t"+"df\t"+"m\t"+"onpremise\t"+"wp\t"+"innerObj\t"+"metic_rNum\t"+"metic_rTime\t"+"SDegree\t";
			System.out.println(title);
			System.out.print(commonstr);			
	}
	
	//5_0_[1000,10000]_[10,15]_15_3.0_0.3
	public void onlyOneTest(String instanceid,int algid,double wp,double theta)
	{
		ArrayList<NewObjectives> objlist = new ArrayList<NewObjectives>();
		ArrayList<String> result = new ArrayList<String>();
		ArrayList<ArrayList<Integer>> arriveSets = new ArrayList<ArrayList<Integer>>();
		ArrayList<Integer> arriveTimeList = new ArrayList<Integer>();
		DecimalFormat format_4 =new   java.text.DecimalFormat("#.####"); 
		DecimalFormat format_2 =new   java.text.DecimalFormat("#.##"); 
//		DecimalFormat format_1 =new   java.text.DecimalFormat("#.#"); 
		String[] temp = instanceid.split("_");
		double df = Double.parseDouble(temp[5]);
		int lambda = Integer.parseInt(temp[4]);
		int m = Integer.parseInt(temp[0]);

		int lastTime = C.LASTTIME;
		int onpremise = OnPremiseSetting.getOi(25, m, df,theta);
		String distribution = "Possion";
		if(instanceid.equalsIgnoreCase("-1")) distribution = "Uniform";
		
		double bestSD = 0;
		int bestFCOST = -1;
		int bestFACOST = -1;
		
		JobRealInfo monitor = new JobRealInfo(m);
		FJOBS jobs = null;
		if(distribution.equalsIgnoreCase("Uniform"))
		{
			jobs = InstanceGenerator.getUniformInstance(instanceid, m, lastTime, arriveSets, arriveTimeList, monitor, this.inslocation);
		}
		else
		{
			jobs = InstanceGenerator.getPiossonInstance(instanceid, m, lastTime, arriveSets, arriveTimeList, monitor, this.inslocation);
		}
		
//		for(int innermetric=1;innermetric<=3;innermetric++)
//		{
			
			IntializeDES(wp);
			
								
				Parameters p = deslist.get(algid);
				
				System.out.println(instanceid+"  "+p.getInnerMetric()+" algindex="+algid);
				
				
//				monitor.Clear();//�����һ�ε����㷨�ļ����м���
//				jobs.update(p.getJD(),p.isLooseDeadline());
				NewObjectives obj = runAlg(m,algid,arriveSets,arriveTimeList,jobs, onpremise,monitor,null,false);	
				
				if(obj.getSatisfactionRate()>bestSD) bestSD = obj.getSatisfactionRate();
				if(bestFCOST==-1) bestFCOST = obj.getFCOST();
				if(obj.getFCOST()<bestFCOST) bestFCOST = obj.getFCOST();
				
//				if(bestFACOST==-1) bestFACOST = obj.getACOST();
//				if(obj.getACOST()<bestFACOST) bestFACOST = obj.getACOST();
				
				objlist.add(obj);
				
				String commonstr = instanceid+"\t"+"DES"+(algid)+"\t"+p.toString()+"\t"+arriveSets.size()+"\t"+lambda+"\t"+df+"\t"+m+"\t"+onpremise+"\t"+wp+"\t"+p.getInnerMetricString()+"\t"+obj.getFCOST()+"\t"+format_4.format(obj.getSatisfactionRate())+"\t";
				System.out.println(commonstr);
				
		
	}
	
	
	
//	public void oneTestAllAlgs(int id,int m,int lambda,double df,int delaylow,int delayhigh,double wp,double devation,double theta,String distribution)
//	{
//		  
//			ArrayList<NewObjectives> objlist = new ArrayList<NewObjectives>();
//			ArrayList<String> result = new ArrayList<String>();
//			ArrayList<ArrayList<Integer>> arriveSets = new ArrayList<ArrayList<Integer>>();
//			ArrayList<Integer> arriveTimeList = new ArrayList<Integer>();
//			DecimalFormat format_4 =new   java.text.DecimalFormat("#.####"); 
//			DecimalFormat format_2 =new   java.text.DecimalFormat("#.##"); 
//			int lastTime = C.LASTTIME;
//			int onpremise = 0;
//			if(lambda==-1) onpremise = OnPremiseSetting.getOi(25, m, df,theta);
//			else onpremise = OnPremiseSetting.getOi(lambda, m, df,theta);
//			String instanceid = "";			
//			double bestSD = 0;
//			int bestFCOST = -1;
//			int bestFACOST = -1;			
//			JobRealInfo monitor = new JobRealInfo(m);
//			FJOBS jobs = null;
//			if(distribution.equalsIgnoreCase("Uniform"))
//			{
//				instanceid = m+"_"+id+"_[1000,10000]_["+delaylow+","+delayhigh+"]_"+lambda+"_"+df+"_"+devation;
//				jobs = InstanceGenerator.getUniformInstance(instanceid, m, lastTime, arriveSets, arriveTimeList, monitor, this.inslocation);
//			}
//			else if(distribution.equalsIgnoreCase("Possion"))
//			{
//				instanceid = m+"_"+id+"_[1000,10000]_["+delaylow+","+delayhigh+"]_"+lambda+"_"+df+"_"+devation;
//				jobs = InstanceGenerator.getPiossonInstance(instanceid, m, lastTime, arriveSets, arriveTimeList, monitor, this.inslocation);
//			}
//			else 
//			{
//				instanceid = m+"_"+id+"_[1000,10000]_["+delaylow+","+delayhigh+"]_"+lambda+"_"+df+"_"+devation;
//				jobs = InstanceGenerator.getAliInstance(instanceid, m, lastTime, arriveSets, arriveTimeList, monitor, this.inslocation);
//			}
//			
////			for(int innermetric=1;innermetric<=3;innermetric++)
////			{
//				
//				IntializeDES(wp);
////			IntializeDESTestingComponent(wp);//TO CHANGE
//			
//				for(int i=0;i<deslist.size();i++)
//				{					
//					Parameters p = deslist.get(i);
//					System.out.print(instanceid+"  "+p.getInnerMetric()+" algindex="+i+"  totalalg="+deslist.size());
//					
//					
////					monitor.Clear();//�����һ�ε����㷨�ļ����м���
////					jobs.update(p.getJD(),p.isLooseDeadline());
//					double starttime = System.currentTimeMillis();
//					NewObjectives obj = runAlg(m,i,arriveSets,arriveTimeList,jobs, onpremise,monitor,this.genRanColor(jobs.getN()),true);	
//
////					NewObjectives obj = runAlg(m,i,arriveSets,arriveTimeList,jobs, onpremise,monitor,null,false);	
//					double runningtime = System.currentTimeMillis() - starttime;
//					
//					if(runningtime>1000*60)
//					System.out.println(" runningtime="+runningtime/(60*1000)+"min");
//					else System.out.println(" runningtime="+runningtime/(1000)+"s");
//					
//					if(obj.getSatisfactionRate()>bestSD) bestSD = obj.getSatisfactionRate();
//					if(bestFCOST==-1) bestFCOST = obj.getFCOST();
//					if(obj.getFCOST()<bestFCOST) bestFCOST = obj.getFCOST();
//					
////					if(bestFACOST==-1) bestFACOST = obj.getACOST();
////					if(obj.getACOST()<bestFACOST) bestFACOST = obj.getACOST();
//					
//					objlist.add(obj);					
//					
//					
//					String commonstr = instanceid+"\t"+"DES"+(i)+"\t"+p.toString()+"\t"+arriveSets.size()+"\t"+lambda+"\t"+df+"\t"+m+"\t"+onpremise+"\t"+wp+"\t"+p.getInnerMetricString()+"\t"+obj.getFCOST()+"\t"+format_4.format(obj.getSatisfactionRate())+"\t";
//					commonstr = instanceid+"\t"+"DES"+i+"\t"+p.toString()+"\t"+instancepstr+"\t"+obj.getFCOST()+"\t"+obj.getCostR()+"\t"+obj.getMakespan()+"\t"+obj.getNewnum()+"\t"+format_4.format(obj.getSatisfactionRate());
//
//					result.add(commonstr);
//				}
////			}
//			System.out.println();
//			String title = 	"Instanceid\t"+"ALG\t"+"TMflag\t"+"VNDflag\t"+"JCSflag\t"+"JD\t"+"isLooseDeadline\t"+"eventNum\t"+"lambda\t"+"df\t"+"m\t"+"onpremise\t"+"wp\t"+"innerObj\t"+"metic_rNum\t"+"metic_rTime\t"+"rpd1\t"+"rpd2\t";
//			System.out.println(title);
//		
//			int size = objlist.size();
//			for(int i=0;i<size;i++)
//			{
//				NewObjectives obj = objlist.get(i);
//				String commonstr = result.get(i);
//				double metric_cost = (double)(obj.getFCOST()-bestFCOST)*100/bestFCOST;
////				double metric_acost = (double)(obj.getACOST()-bestFACOST)*100/bestFACOST;
//				
////				double metric_ed = (obj.getEuclideanDistance()-best_ed)*100/best_ed;
//				commonstr+=format_2.format(metric_cost);//+"\t"+format_2.format(metric_ed);
//				System.out.println(commonstr);
//				result.set(i, commonstr);
//			}
//
//			String filename = m+"_"+id+"_["+delaylow+","+delayhigh+"]";
//			TextOperation.writeResultIntoText(resultlocation,filename, result);		
//	}

	public void oneTestAllAlgsCompare(int id,int m,int lambda,double df,int delaylow,int delayhigh,double wp,double devation, double theta,String distribution)
	{
		  
			ArrayList<NewObjectives> objlist = new ArrayList<NewObjectives>();
			ArrayList<String> result = new ArrayList<String>();
			ArrayList<ArrayList<Integer>> arriveSets = new ArrayList<ArrayList<Integer>>();
			ArrayList<Integer> arriveTimeList = new ArrayList<Integer>();
			DecimalFormat format_4 =new   java.text.DecimalFormat("#.####"); 
			DecimalFormat format_2 =new   java.text.DecimalFormat("#.##"); 
//			DecimalFormat format_1 =new   java.text.DecimalFormat("#.#"); 
			int lastTime = C.LASTTIME;
			int onpremise = 0;
			if(distribution.equalsIgnoreCase("Uniform")) onpremise = OnPremiseSetting.getOi(25, m, df,theta);
			else if(distribution.equalsIgnoreCase("Possion")) onpremise = OnPremiseSetting.getOi(lambda, m, df,theta);
			else onpremise = OnPremiseSetting.getOi(150, m, df,theta);
//			System.out.println("onpremise="+onpremise);
			String instanceid = "";
			
			double bestSD = 0;
			int bestFCOST = -1;
//			int bestFACOST = -1;
			String instancepstr=m+"\t"+lambda+"\t"+df+"\t"+devation+"\t"+"["+delaylow+","+delayhigh+"]\t"+theta;
			JobRealInfo monitor = new JobRealInfo(m);
			FJOBS jobs = null;
			if(distribution.equalsIgnoreCase("Uniform"))
			{
				instanceid = m+"_"+id+"_[1000,10000]_["+delaylow+","+delayhigh+"]_"+lambda+"_"+df+"_"+devation;
				jobs = InstanceGenerator.getUniformInstance(instanceid, m, lastTime, arriveSets, arriveTimeList, monitor, this.inslocation);
			}
			else if(distribution.equalsIgnoreCase("Possion"))
			{
				instanceid = m+"_"+id+"_[1000,10000]_["+delaylow+","+delayhigh+"]_"+lambda+"_"+df+"_"+devation;
				jobs = InstanceGenerator.getPiossonInstance(instanceid, m, lastTime, arriveSets, arriveTimeList, monitor, this.inslocation);
			}
			else
			{
				instanceid = m+"_"+id+"_[1000,10000]_["+delaylow+","+delayhigh+"]_"+lambda+"_"+df+"_"+devation;
				jobs = InstanceGenerator.getAliInstance(instanceid, m, lastTime, arriveSets, arriveTimeList, monitor, this.inslocation);
				
			}
			
//			for(int innermetric=1;innermetric<=3;innermetric++)
//			{
				IntializeDES(wp);
//			IntializeDESTestingComponent(wp);//TO CHANGE
			
				for(int i=0;i<deslist.size();i++)
				{					
					
					Parameters p = deslist.get(i);
//					if(p.LSMethod()!=C.LS_GREEDY_One) continue;
					
					/* DES17	PEST	VND		JCS2	JD3	LooseDeadline
					 * DES23	PEST	VND		JCS2	JD2	TightDeadline
					 * DES58	FEST	VND		JCS2	JD2	TightDeadline
					 * DES64	FEST	noLS	JCS1	JD2	LooseDeadline
					 * DES71	FEST	noLS	JCS2	JD2	TightDeadline
					 * */
//					if(!(i==17||i==23)) continue;
//					if(!(i==71)) continue;
//					if(!(i==64)) continue;
//					if(!(i==17)) continue;
					System.out.println(instanceid+"  "+p.getInnerMetric()+" algindex="+i+"  totalalg="+deslist.size()+" "+p.toString()+" theta="+theta);					
//					monitor.Clear();//�����һ�ε����㷨�ļ����м���
//					jobs.update(p.getJD(),p.isLooseDeadline());
					double starttime = System.currentTimeMillis();

//					NewObjectives obj = runAlg(m,i,arriveSets,arriveTimeList,jobs, onpremise,monitor,this.genRanColor(jobs.getN()),false);	
					NewObjectives obj = runAlg(m,i,arriveSets,arriveTimeList,jobs, onpremise,monitor,null,false);	

					double runningtime = System.currentTimeMillis() - starttime;
					if(runningtime>1000*60)
					System.out.println(" runningtime="+runningtime/(60*1000)+"min");
					else System.out.println(" runningtime="+runningtime/(1000)+"s");
					
					
					
					
					if(obj.getSatisfactionRate()>bestSD) bestSD = obj.getSatisfactionRate();
					if(bestFCOST==-1) bestFCOST = obj.getFCOST();
					if(obj.getFCOST()<bestFCOST) bestFCOST = obj.getFCOST();
					
//					if(bestFACOST==-1) bestFACOST = obj.getACOST();
//					if(obj.getACOST()<bestFACOST) bestFACOST = obj.getACOST();
					
					objlist.add(obj);					
					
					
					String commonstr = null;
//					if(i==17||i==23||i==58)
						commonstr = instanceid+"\t"+"DES"+i+"\t"+p.toString()+"\t"+instancepstr+"\t"+obj.getFCOST()+"\t"+obj.getCostR()+"\t"+obj.getMakespan()+"\t"+obj.getNewnum()+"\t"+format_4.format(obj.getSatisfactionRate());
//					else if(i==64)
//						commonstr = instanceid+"\t"+"HEFT"+"\t"+obj.getFCOST()+"\t"+obj.getCostR()+"\t"+format_4.format(obj.getSatisfactionRate())+"\t"+format_4.format(obj.getNormalObjective(0.5, -1));
//					else if(i==71)
//						commonstr = instanceid+"\t"+"FDES"+"\t"+obj.getFCOST()+"\t"+obj.getCostR()+"\t"+format_4.format(obj.getSatisfactionRate())+"\t"+format_4.format(obj.getNormalObjective(0.5, -1));
					System.out.println(commonstr);
					result.add(commonstr);
				}
//				NewObjectives tempobj = this.testAdjustedFDES(instanceid, m, lambda, df, wp, distribution);
//				String tempcommonstr = instanceid+"\t"+"AFDES"+"\t"+tempobj.getFCOST()+"\t"+tempobj.getACOST()+"\t"+format_4.format(tempobj.getSatisfactionRate())+"\t";
//				result.add(tempcommonstr);
//				objlist.add(tempobj);
//				if(tempobj.getFCOST()<bestFCOST) bestFCOST = tempobj.getFCOST();				
//				if(tempobj.getACOST()<bestFACOST) bestFACOST = tempobj.getACOST();
//			}
			System.out.println();
			String title = 	"Instanceid\t\t\t\t"+"ALG\tTP\tLS\tJCS\tJD\tTD\t\tm\tlambda\tdf\tdev\tdelay\ttheta\t"+"tCOST\toCOST\tmspan\tnewvm\t"+"SD\t"+"crpd\tw1_95\tw3_95\tw5_95\tw7_95\tw9_95\tw1\tw3\tw5\tw7\tw9";
			System.out.println(title);
		
			int size = objlist.size();
			for(int i=0;i<size;i++)
			{
				NewObjectives obj = objlist.get(i);
				String commonstr = result.get(i);
				double metric_cost = (double)(obj.getFCOST()-bestFCOST)*100/bestFCOST;
//				double metric_acost = (double)(obj.getACOST()-bestFACOST)*100/bestFACOST;
				
//				double metric_ed = (obj.getEuclideanDistance()-best_ed)*100/best_ed;
				commonstr+="\t"+format_2.format(metric_cost);//+"\t"+format_2.format(metric_ed);
//				double weightobj_01_95 = ((double)bestFCOST/obj.getFCOST())*0.1+0.9*(obj.getSatisfactionRate()-0.95)/0.05;
//				double weightobj_03_95 = ((double)bestFCOST/obj.getFCOST())*0.3+0.7*(obj.getSatisfactionRate()-0.95)/0.05;
//				double weightobj_05_95 = ((double)bestFCOST/obj.getFCOST())*0.5+0.5*(obj.getSatisfactionRate()-0.95)/0.05;
//				double weightobj_07_95 = ((double)bestFCOST/obj.getFCOST())*0.7+0.3*(obj.getSatisfactionRate()-0.95)/0.05;
//				double weightobj_09_95 = ((double)bestFCOST/obj.getFCOST())*0.9+0.1*(obj.getSatisfactionRate()-0.95)/0.05;
//				double weightobj_01 = ((double)bestFCOST/obj.getFCOST())*0.1+0.9*obj.getSatisfactionRate();
//				double weightobj_03 = ((double)bestFCOST/obj.getFCOST())*0.3+0.7*obj.getSatisfactionRate();
//				double weightobj_05 = ((double)bestFCOST/obj.getFCOST())*0.5+0.5*obj.getSatisfactionRate();
//				double weightobj_07 = ((double)bestFCOST/obj.getFCOST())*0.7+0.3*obj.getSatisfactionRate();
//				double weightobj_09 = ((double)bestFCOST/obj.getFCOST())*0.9+0.1*obj.getSatisfactionRate();
				double weightobj_00_95 = ((double)bestFCOST/obj.getFCOST())*0.0+1*(obj.getSatisfactionRate()-0.95)/0.05;
				double weightobj_02_95 = ((double)bestFCOST/obj.getFCOST())*0.2+0.8*(obj.getSatisfactionRate()-0.95)/0.05;
				double weightobj_04_95 = ((double)bestFCOST/obj.getFCOST())*0.4+0.6*(obj.getSatisfactionRate()-0.95)/0.05;
				double weightobj_06_95 = ((double)bestFCOST/obj.getFCOST())*0.6+0.4*(obj.getSatisfactionRate()-0.95)/0.05;
				double weightobj_08_95 = ((double)bestFCOST/obj.getFCOST())*0.8+0.2*(obj.getSatisfactionRate()-0.95)/0.05;
				double weightobj_10_95 = ((double)bestFCOST/obj.getFCOST())*1.0+0.0*(obj.getSatisfactionRate()-0.95)/0.05;

				double weightobj_00 = ((double)bestFCOST/obj.getFCOST())*0.0+1.0*obj.getSatisfactionRate();
				double weightobj_02 = ((double)bestFCOST/obj.getFCOST())*0.2+0.8*obj.getSatisfactionRate();
				double weightobj_04 = ((double)bestFCOST/obj.getFCOST())*0.4+0.6*obj.getSatisfactionRate();
				double weightobj_06 = ((double)bestFCOST/obj.getFCOST())*0.6+0.4*obj.getSatisfactionRate();
				double weightobj_08 = ((double)bestFCOST/obj.getFCOST())*0.8+0.2*obj.getSatisfactionRate();
				double weightobj_10 = ((double)bestFCOST/obj.getFCOST())*1.0+0.0*obj.getSatisfactionRate();

//				System.out.println("(double)("+bestFCOST+"/"+obj.getFCOST()+")*0.1+(1-0.1)*("+obj.getSatisfactionRate()+"-0.95)/0.05");
				commonstr+="\t"+format_4.format(weightobj_00_95);
				commonstr+="\t"+format_4.format(weightobj_02_95);
				commonstr+="\t"+format_4.format(weightobj_04_95);
				commonstr+="\t"+format_4.format(weightobj_06_95);
				commonstr+="\t"+format_4.format(weightobj_08_95);
				commonstr+="\t"+format_4.format(weightobj_10_95);

				commonstr+="\t"+format_4.format(weightobj_00);
				commonstr+="\t"+format_4.format(weightobj_02);
				commonstr+="\t"+format_4.format(weightobj_04);
				commonstr+="\t"+format_4.format(weightobj_06);
				commonstr+="\t"+format_4.format(weightobj_08);
				commonstr+="\t"+format_4.format(weightobj_10);

				System.out.println(commonstr);
				result.set(i, commonstr);
			}

			String filename = m+"_"+id+"_["+delaylow+","+delayhigh+"]";
			TextOperation.writeResultIntoText(resultlocation,filename, result);		
	}
	
	public void batchRunCompare(int m,double wp,String distribution,int delaylow,int delayhigh)
	{

		int id = -1;
		File document = new File(this.resultlocation);
		File[] array = document.listFiles();
		for(int i=0;i<array.length;i++)
		{
			String filename = array[i].getName();
			if(!filename.contains("["+delaylow+","+delayhigh+"]")) continue;
			String[] filearray = filename.split("_");
			id = Integer.parseInt(filearray[1]);
			String lastExp = TextOperation.readLastLinefromText(array[i].getPath());
			String lastinstance = lastExp.split("\t")[0];
			String[] instanceArray = lastinstance.split("_");
			int startLambda = Integer.parseInt(instanceArray[4]);
			double startDf = Double.parseDouble(instanceArray[5]);
			double startDev = Double.parseDouble(instanceArray[6]);
//			double starttheta = Double.parseDouble(instanceArray[7])
			startDev+=0.1;
			if(startDev>=0.4) {
				startDf+=0.5;
				startDev = 0.1;
			}
			if(startDf>3&&startLambda>0)
			{
				startDf = 1.5;
				startLambda += 5;
			}
			

			if(distribution.equalsIgnoreCase("Possion"))
			{
				
				for(int lambda=startLambda;lambda<=50;lambda+=5)
				{	
					for(double df=startDf;df<=3;df+=0.5)
						
						{
						
						for(double deviation = startDev;deviation<0.4;deviation+=0.1)
						{
							String dev = String.valueOf(deviation).substring(0,3);
							deviation = Double.parseDouble(dev);
							for(double theta = 0.5;theta<2;theta+=0.5)
							{
								
								this.oneTestAllAlgsCompare(id, m,lambda, df, delaylow, delayhigh,wp,deviation,theta,distribution);
							}
//							System.out.println(id+"\t"+lambda+"\t"+df+"\t"+dev);
						}
						startDev = 0.1;
						
//						deviation = 0.2;
//						this.oneTestAllAlgs(id, m,lambda, df, delaylow, delayhigh,wp,deviation,distribution);
//						deviation = 0.3;
//						this.oneTestAllAlgs(id, m,lambda, df, delaylow, delayhigh,wp,deviation,distribution);
						}
					startDf = 1.5;
				}	
			}
			else if(distribution.equalsIgnoreCase("Uniform"))
			{
				for(double df=startDf;df<=3;df+=0.5)
					
					{
					
					for(double deviation = startDev;deviation<0.4;deviation+=0.1)
					{
						String dev = String.valueOf(deviation).substring(0,3);
						deviation = Double.parseDouble(dev);
						for(double theta = 0.5;theta<2;theta+=0.5)
						{
							
							this.oneTestAllAlgsCompare(id, m,-1, df, delaylow, delayhigh,wp,deviation,theta,distribution);
						}
					}
					startDev = 0.1;
					}
			}
			else
			{

				for(double df=startDf;df<=3;df+=0.5)
					
				{
				
				for(double deviation = startDev;deviation<0.4;deviation+=0.1)
				{
					String dev = String.valueOf(deviation).substring(0,3);
					deviation = Double.parseDouble(dev);
					for(double theta = 0.5;theta<2;theta+=0.5)
					{
						
						this.oneTestAllAlgsCompare(id, m,-1, df, delaylow, delayhigh,wp,deviation,theta,distribution);
					}
				}
				startDev = 0.1;
				}
			}
			
		}
		id++;
		if(distribution.equalsIgnoreCase("Uniform"))
			for(;id<100;id++)
			{
				batchRunCompare(id, m, delaylow, delayhigh, wp, distribution);				
			}
			else if(distribution.equalsIgnoreCase("Possion"))
			{
				for(;id<10;id++)
				{
					batchRunCompare(id, m, delaylow, delayhigh, wp, distribution);				
				}
			}
			else 
			{
				for(;id<12;id++)
				{
					batchRunCompare(id, m, delaylow, delayhigh, wp, distribution);				
				}
			}
		
	}
	
	public void batchRunCompareCalibration(int m,double wp,String distribution)
	{
		int delaylow = 70;
		int delayhigh = 80;
		int id = -1;
		File document = new File(this.resultlocation);
		File[] array = document.listFiles();
		for(int i=0;i<array.length;i++)
		{
			String filename = array[i].getName();
			if(!filename.contains("["+delaylow+","+delayhigh+"]")) continue;
			String[] filearray = filename.split("_");
			id = Integer.parseInt(filearray[1]);
			String lastExp = TextOperation.readLastLinefromText(array[i].getPath());
			String lastinstance = lastExp.split("\t")[0];
			String[] instanceArray = lastinstance.split("_");
			int startLambda = Integer.parseInt(instanceArray[4]);
			double startDf = Double.parseDouble(instanceArray[5]);
			double startDev = Double.parseDouble(instanceArray[6]);
//			double starttheta = Double.parseDouble(instanceArray[7])
			startDev+=0.1;
			if(startDev>=0.4) {
				startDf+=0.5;
				startDev = 0.1;
			}
			if(startDf>3&&startLambda>0)
			{
				startDf = 1.5;
				startLambda += 10;
			}
			

			if(distribution.equalsIgnoreCase("Possion"))
			{
				
				for(int lambda=startLambda;lambda<=50;lambda+=10)
				{	
					for(double df=startDf;df<=3;df+=0.5)
						
						{
						
						for(double deviation = startDev;deviation<0.4;deviation+=0.1)
						{
							String dev = String.valueOf(deviation).substring(0,3);
							deviation = Double.parseDouble(dev);
							for(double theta = 0.5;theta<2;theta+=0.5)
							{
								
								this.oneTestAllAlgsCompare(id, m,lambda, df, delaylow, delayhigh,wp,deviation,theta,distribution);
							}
//							System.out.println(id+"\t"+lambda+"\t"+df+"\t"+dev);
						}
						startDev = 0.1;
						
//						deviation = 0.2;
//						this.oneTestAllAlgs(id, m,lambda, df, delaylow, delayhigh,wp,deviation,distribution);
//						deviation = 0.3;
//						this.oneTestAllAlgs(id, m,lambda, df, delaylow, delayhigh,wp,deviation,distribution);
						}
					startDf = 1.5;
				}	
			}
			else if(distribution.equalsIgnoreCase("Uniform"))
			{
				for(double df=startDf;df<=3;df+=0.5)
					
					{
					
					for(double deviation = startDev;deviation<0.4;deviation+=0.1)
					{
						String dev = String.valueOf(deviation).substring(0,3);
						deviation = Double.parseDouble(dev);
						for(double theta = 0.5;theta<2;theta+=0.5)
						{
							
							this.oneTestAllAlgsCompare(id, m,-1, df, delaylow, delayhigh,wp,deviation,theta,distribution);
						}
					}
					startDev = 0.1;
					}
			}
			else
			{

				for(double df=startDf;df<=3;df+=0.5)
					
				{
				
				for(double deviation = startDev;deviation<0.4;deviation+=0.1)
				{
					String dev = String.valueOf(deviation).substring(0,3);
					deviation = Double.parseDouble(dev);
					for(double theta = 0.5;theta<2;theta+=0.5)
					{
						
						this.oneTestAllAlgsCompare(id, m,-1, df, delaylow, delayhigh,wp,deviation,theta,distribution);
					}
				}
				startDev = 0.1;
				}
			}
			
		}
		id++;
		if(distribution.equalsIgnoreCase("Uniform"))
			for(;id<2;id++)
			{
				batchRunCompare(id, m, delaylow, delayhigh, wp, distribution);				
			}
			else if(distribution.equalsIgnoreCase("Possion"))
			{
				for(;id<5;id++)
				{
					batchRunCompare(id, m, delaylow, delayhigh, wp, distribution);				
				}
			}
			else 
			{
				for(;id<5;id++)
				{
					batchRunCompare(id, m, delaylow, delayhigh, wp, distribution);				
				}
			}
		
	}
	
	
	
	
	public void batchRun(int m,double wp,String distribution,int delaylow,int delayhigh)
	{
		int id = -1;
		File document = new File(this.resultlocation);
		File[] array = document.listFiles();
		for(int i=0;i<array.length;i++)
		{
			String filename = array[i].getName();
			if(!filename.contains("["+delaylow+","+delayhigh+"]")) continue;
			String[] filearray = filename.split("_");
			id = Integer.parseInt(filearray[1]);
			String lastExp = TextOperation.readLastLinefromText(array[i].getPath());
			String lastinstance = lastExp.split("\t")[0];
			String[] instanceArray = lastinstance.split("_");
			int startLambda = Integer.parseInt(instanceArray[4]);
			double startDf = Double.parseDouble(instanceArray[5]);
			double startDev = Double.parseDouble(instanceArray[6]);
			startDev+=0.1;
			if(startDev>=0.4) {
				startDf+=0.5;
				startDev = 0.1;
			}
			if(startDf>3&&startLambda>0)
			{
				startDf = 1.5;
				startLambda += 5;
			}
			
			
			if(distribution.equalsIgnoreCase("Possion"))
			{
				
				for(int lambda=startLambda;lambda<=50;lambda+=5)
					
					for(double df=startDf;df<=3;df+=0.5)
						
						{
						
						for(double deviation = startDev;deviation<0.4;deviation+=0.1)
						{
							String dev = String.valueOf(deviation).substring(0,3);
							deviation = Double.parseDouble(dev);
							for(double theta = 0.5;theta<2;theta+=0.5)
							{
							
							this.oneTestAllAlgsCompare(id, m,lambda, df, delaylow, delayhigh,wp,deviation,theta,distribution);
							}
//							System.out.println(id+"\t"+lambda+"\t"+df+"\t"+dev);
						}
						
//						deviation = 0.2;
//						this.oneTestAllAlgs(id, m,lambda, df, delaylow, delayhigh,wp,deviation,distribution);
//						deviation = 0.3;
//						this.oneTestAllAlgs(id, m,lambda, df, delaylow, delayhigh,wp,deviation,distribution);

						}
						
					
			}
			else
			{
				for(double df=startDf;df<=3;df+=0.5)
					
					{
					
					for(double deviation = startDev;deviation<0.4;deviation+=0.1)
					{
						String dev = String.valueOf(deviation).substring(0,3);
						deviation = Double.parseDouble(dev);
//						System.out.println(id+"\t"+df+"\t"+dev);
						for(double theta = 0.5;theta<2;theta+=0.5)
						{
						
						this.oneTestAllAlgsCompare(id, m,-1, df, delaylow, delayhigh,wp,deviation,theta,distribution);
						}
					}
					
					}
			}
			
		}
		id++;
		if(distribution.equalsIgnoreCase("Uniform"))
			for(;id<100;id++)
			{
				batchRun(id, m, delaylow, delayhigh, wp, distribution);				
			}
			else
			{
				for(;id<10;id++)
				{
					batchRun(id, m, delaylow, delayhigh, wp, distribution);				
				}
		}
		
	}
	
	
	public void batchRun(int id,int m, int delaylow,int delayhigh,double wp,String distribution)
	{
		
			if(distribution.equalsIgnoreCase("Possion"))
			{
				for(int lambda=5;lambda<=50;lambda+=5)
					
					for(double theta = 0.5;theta<2;theta+=0.5)
					{
						for(double df=1.5;df<=3;df+=0.5)
							
						{
						double deviation = 0.1;
						this.oneTestAllAlgsCompare(id, m,lambda, df, delaylow, delayhigh,wp,deviation,theta,distribution);
						deviation = 0.2;
						this.oneTestAllAlgsCompare(id, m,lambda, df, delaylow, delayhigh,wp,deviation,theta,distribution);
						deviation = 0.3;
						this.oneTestAllAlgsCompare(id, m,lambda, df, delaylow, delayhigh,wp,deviation,theta,distribution);

						}
						
					}
					
							
			}
			else
			{
				for(double theta = 0.5;theta<2;theta+=0.5)
				{
					for(double df=1.5;df<=3;df+=0.5)
						
					{
					double deviation = 0.1;
					this.oneTestAllAlgsCompare(id, m,-1, df, delaylow, delayhigh,wp,deviation,theta,distribution);
					deviation = 0.2;
					this.oneTestAllAlgsCompare(id, m,-1, df, delaylow, delayhigh,wp,deviation,theta,distribution);
					deviation = 0.3;
					this.oneTestAllAlgsCompare(id, m,-1, df, delaylow, delayhigh,wp,deviation,theta,distribution);

					}
					
				}
				
				
			}
					
//		mt.oneTestAllAlgs(id, lambda, df, delaylow, delayhigh,wp,1);
	}
	
	public void batchRunCompare(int id,int m, int delaylow,int delayhigh,double wp,String distribution)
	{
		
			if(distribution.equalsIgnoreCase("Possion"))
			{
				for(int lambda=5;lambda<=50;lambda+=5)
					for(double theta = 0.5;theta<2;theta+=0.5)
					{
						for(double df=1.5;df<=3;df+=0.5)
							
						{
						double deviation = 0.1;
						this.oneTestAllAlgsCompare(id, m,lambda, df, delaylow, delayhigh,wp,deviation,theta,distribution);
						deviation = 0.2;
						this.oneTestAllAlgsCompare(id, m,lambda, df, delaylow, delayhigh,wp,deviation,theta,distribution);
						deviation = 0.3;
						this.oneTestAllAlgsCompare(id, m,lambda, df, delaylow, delayhigh,wp,deviation,theta,distribution);

						}
						
					}
					
					
							
			}
			else if(distribution.equalsIgnoreCase("Uniform"))
			{
				for(double theta = 0.5;theta<2;theta+=0.5)
				{
					for(double df=1.5;df<=3;df+=0.5)
						
					{
					double deviation = 0.1;
					this.oneTestAllAlgsCompare(id, m,-1, df, delaylow, delayhigh,wp,deviation,theta,distribution);
					deviation = 0.2;
					this.oneTestAllAlgsCompare(id, m,-1, df, delaylow, delayhigh,wp,deviation,theta,distribution);
					deviation = 0.3;
					this.oneTestAllAlgsCompare(id, m,-1, df, delaylow, delayhigh,wp,deviation,theta,distribution);

					}
					
				}
			}
			else 
			{
				for(double theta = 0.5;theta<2;theta+=0.5)
				{
					for(double df=1.5;df<=3;df+=0.5)
						
					{
					double deviation = 0.1;
					this.oneTestAllAlgsCompare(id, m,-1, df, delaylow, delayhigh,wp,deviation,theta,distribution);
					deviation = 0.2;
					this.oneTestAllAlgsCompare(id, m,-1, df, delaylow, delayhigh,wp,deviation,theta,distribution);
					deviation = 0.3;
					this.oneTestAllAlgsCompare(id, m,-1, df, delaylow, delayhigh,wp,deviation,theta,distribution);

					}
					
				}
			}
					
//		mt.oneTestAllAlgs(id, lambda, df, delaylow, delayhigh,wp,1);
	}
	
	
	public void IntializeDES(double wp)//���û��LS�Ļ���metric����Ϊ-1����Ϊһ����evaluate����Ŀ��
	{	
		deslist.clear();
		int TMStrategy = 0;//0-3
		int ls = 0;
		boolean jscflag = true; 
		boolean looseDeadline = true;
		double JD=0;
		

		for(int i=0;i<3;i++)
		{
			TMStrategy = i; //TP1-PT3
			for(int j=0;j<1;j++) //j=0Ϊû��LS�����
			{
				ls = j;
				for(int k=0;k<2;k++)
				{
					if(k==1) jscflag = false;
					else jscflag = true;
//					for(JD=0;JD>=-2;JD--)
//					{
						for(int l=0;l<2;l++)
						{
							if(l==0) looseDeadline = true;
							else looseDeadline = false;
//							if(vndflag==false)
//							{
								Parameters p = new Parameters();
								p.setTMStrategy(TMStrategy);
								p.setLS(ls);
								p.setJCSflag(jscflag);		
								p.setWP(wp);
								p.setInnerMetric(-1);//��������ĸ����У���Ϊ������
								p.setJD(JD);
								p.setLooseDeadline(looseDeadline);
								deslist.add(p);
//							}
//							else
//							{
//								for(int metric=2;metric<=3;metric++)
//								{
//									Parameters p = new Parameters();
//									p.setTMStrategy(TMStrategy);
//									p.setVNDflag(vndflag);
//									p.setJCSflag(jscflag);		
//									p.setWP(wp);//����ʽ�㷨����ȫ�����µ���
//									p.setInnerMetric(metric);
//									p.setJD(JD);
//									p.setLooseDeadline(looseDeadline);
//									deslist.add(p);
//								}
//							}
						}
//					}
					
				}
			}
		}
	}
	
	
	

	
	private HashMap<Integer,Color> genRanColor(int n) {
		HashMap<Integer,Color> cmap = new HashMap<Integer,Color>();
		Random r = new Random();
			for(int i=cmap.size();i<n;i++)
			{
				cmap.put(i,new Color(r.nextInt(255), r.nextInt(255), r.nextInt(255)));
			}
		
		return cmap;
	}
	
	
	public void Compare()
	{
		
	}
	
	
	public static void main(String[] args) {
		int m=3;
		String distribution = "Ali";
//		String inslocation = "E:\\fuzzyScheduling\\Fuzzy Instances\\m="+m+" "+distribution;
//		String resultlocation = "E:\\fuzzyScheduling\\Experiment Results\\m="+m+" "+distribution;
		String inslocation = "D:\\��������\\Dynamic_Instances_newFuzzy\\m="+m+" "+distribution;
		
		String resultlocation = "D:\\��������\\Experiment Results\\Fuzzy\\Experiment Results LinkedList\\2020-04-09\\m="+m+" "+distribution+"\\";
		System.out.println(resultlocation);
		int delaylow = 250;
		int delayhigh = 280;
		double wp = 0.5;
		boolean paint = false;
		

			FuzzyMainTestingNewObjectives mt = new FuzzyMainTestingNewObjectives(inslocation,resultlocation);
			
//			mt.batchRunCompare(m, wp, distribution, delaylow, delayhigh);
			mt.batchRunCompareCalibration(m, wp, distribution);
	}

}
