package Experiments;

public class OnPremiseSetting {



public static int getOi(int lambda,int m,double df,double theta)
{
//	int onpremise = 0;
//	if(df==0.5)
//	{if(m==3) onpremise = 6;
//	else if(m==5) onpremise = 5;
//	else if(m==10) onpremise = 4;
//	else onpremise = 3;}
//	if(df==1)
//	{if(m==3) onpremise = 5;
//	else if(m==5) onpremise = 4;
//	else if(m==10) onpremise = 3;
//	else onpremise = 2;}
//	if(df==1.5)
//	{if(m==3) onpremise = 4;
//	else if(m==5) onpremise = 3;
//	else if(m==10) onpremise = 2;
//	else onpremise = 1;}
//	if(df==2)
//	{if(m==3) onpremise = 3;
//	else if(m==5) onpremise = 2;
//	else if(m==10) onpremise = 1;
//	else onpremise = 0;}
//	onpremise+=lambda/5;
	int onpremise = (int)(lambda*m*theta/df);
	return onpremise;
}
}
