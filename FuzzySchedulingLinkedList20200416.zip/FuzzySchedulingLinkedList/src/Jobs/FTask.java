package Jobs;

import element.FuzzyNumber;

public class FTask {
	
	FuzzyNumber length;//���ܱ�
	FuzzyNumber earliest;//���Ա䣬ÿ����֮ǰ��Ҫ����
	FuzzyNumber latest;//���ܱ�
	FuzzyNumber priority1; 
	FuzzyNumber priority2;
	int jobid;//���ܱ�
	int stage;//���ܱ�
	int taskstate;
//	FuzzyNumber delay;//���ܱ�
	
//	public FuzzyNumber getDelay() {
//		return delay;
//	}

	public int getTaskstate() {
		return taskstate;
	}

	public void setTaskstate(int taskstate) {
		this.taskstate = taskstate;
	}

	public FuzzyNumber getPriority1() {
		return priority1;
	}
	public FuzzyNumber getPriority2() {
		return priority2;
	}
	public void setPriority1(FuzzyNumber priority1) {
		this.priority1 = priority1;
	}
	public void setPriority2(FuzzyNumber priority2) {
		this.priority2 = priority2;
	}
	
	public FuzzyNumber getLength() {
		return length;
	}
	
	public FuzzyNumber getEarliest() {
		return earliest;
	}
	
	public FuzzyNumber getLatest() {
		return latest;
	}
	
	public void print()
	{
//		System.out.println("Task jobid="+jobid+" length="+length+", earliest="+earliest+", latest="+latest);
		System.out.println("Task jobid="+jobid+",length="+length.toString()+"\n earliest=" +
							                              earliest.toString()+"\n latest="+
							                              latest.toString()+"\n priority1="+
							                              priority1.toString());
		System.out.println("priority2="+priority2.toString());
	}
	
	public String toString()
	{
//		System.out.println("Task jobid="+jobid+" length="+length+", earliest="+earliest+", latest="+latest);
		return "Task jobid="+jobid+",stageid="+stage+",length="+length.toString()+" earliest=" +
							                              earliest.toString()+" latest="+
							                              latest.toString();
	}
	
//	public FTask(FuzzyNumber length, int jobid, int stage,FuzzyNumber latest){
//		this.length = length;
//		this.jobid = jobid;
//		this.stage = stage;
//		this.latest = latest;
//	}
	
//	public void setEarliest(int realEarliest)
//	{
//		this.earliest = new FuzzyNumber(realEarliest,realEarliest,realEarliest);
//	}
	
	public void setEarliest(FuzzyNumber earliest) {
		this.earliest = earliest;
	}
	
//	public void setLatest(int reallatest) {
//		this.latest = new FuzzyNumber(reallatest,reallatest,reallatest);
//	}
//
	public void setLatest(FuzzyNumber latest) {
		this.latest = latest;
	}
//	public int setRealValue(){
//		realValue=latest-earliest;
//		return realValue;
//	}

	public FTask(FuzzyNumber length,FuzzyNumber delay, FuzzyNumber earliest,FuzzyNumber latest,int jobid,int stage)
	{
		this.length = length;
		this.latest = latest;
		this.jobid = jobid;
		this.stage = stage;
		this.earliest = earliest;
//		this.delay = delay;
	}

	public int getJobid() {
		return jobid;
	}

	public int getStage() {
		return stage;
	}
//	public int getRealValue() {
//		return super.getRealValue();
//	}

}
