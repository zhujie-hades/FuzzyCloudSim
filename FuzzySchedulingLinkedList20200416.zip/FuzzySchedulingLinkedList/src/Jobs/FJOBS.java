package Jobs;

import java.util.ArrayList;

public class FJOBS {
	int n;
	int m;
	ArrayList<FJOB> jobArray;

	
	public int getN() {
		return n;
	}
//	public void setN(int n) {
//		this.n = n;
//	}
	public int getM() {
		return m;
	}
	public void setM(int m) {
		this.m = m;
	}
	public FJOBS(int n,int m)
	{
		this.n = n;
		this.m = m;
		this.jobArray = new ArrayList<FJOB>();
//		this.m = m;
//		this.mLength = new int[m];
	}
//	public ArrayList<JOB> getJobArray() {
//		return jobArray;
//	}
	public FJOB getJob(int id)
	{
		return jobArray.get(id);
	}
	public void addJob(FJOB j) {
		jobArray.add(j);
		n++;
//		for(int i=0;i<m;i++)
//		{
//			mLength[m]+= j.getOp()[m];
//		}
	}
//	public int[] getmLength() {
//		return mLength;
//	}
	public void print()
	{
		for(int i=0;i<n;i++)
		{
			FJOB job = jobArray.get(i);
			job.print(i);
		}
	}
	public void print(JobRealInfo monitor)
	{
		for(int i=0;i<n;i++)
		{
			FJOB job = jobArray.get(i);
			job.print(monitor,i);
		}
	}

}
