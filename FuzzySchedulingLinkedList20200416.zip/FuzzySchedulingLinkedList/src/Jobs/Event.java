package Jobs;

import java.util.ArrayList;
import java.util.HashMap;

import SchedulePlan.FJobAssignment;
import SchedulePlan.Schedule;

public class Event {

	int arriveTime;
	int jobnum;
	HashMap<Integer,FJobAssignment> jobset;
	int m;
	ArrayList<Integer> joblist;
	
	public void addJob(FJobAssignment job,int jobid)
	{
		
		if(!jobset.containsKey(jobid))
		{
			jobset.put(jobid, job);		
			joblist.add(jobid);
			jobnum++;
		}
	}
	
	public void print()
	{
		System.out.println("arriveTime="+arriveTime+" jobnum="+jobnum+" joblist="+joblist.toString());
	}
	
	public Event(int arriveTime,int jobnum, int m, ArrayList<Integer> joblist, Schedule schedule)
	{
		jobset = new HashMap<Integer,FJobAssignment>();
		this.arriveTime = arriveTime;
		this.jobnum = jobnum;
		for(int i=0;i<jobnum;i++)
		{
			int jobid = joblist.get(i);
			jobset.put(jobid, schedule.getJob(jobid));
		}
		this.m = m;
		this.joblist = joblist;
	}
	public ArrayList<Integer> getJoblist() {
		return joblist;
	}
	public int getM() {
		return m;
	}
	public FJobAssignment getJob(int jobid) {return jobset.get(jobid);}
	public int getArriveTime() {
		return arriveTime;
	}
	public int getJobnum() {
		return jobnum;
	}
	public HashMap<Integer, FJobAssignment> getJobset() {
		return jobset;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
