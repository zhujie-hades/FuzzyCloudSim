package Jobs;

import Tools.FO;
import element.FuzzyNumber;

public class FJOB {
	public double getDf() {
		return df;
	}

	int m;
	double df;
    FuzzyNumber[] op;
    FuzzyNumber[] latency; 
	
	int arriveTime=-1;

	public FuzzyNumber[] getLatency() {
		return latency;
	}

	public int getArriveTime() {
		return arriveTime;
	}

	
	

	public FJOB(int m,FuzzyNumber[] op,FuzzyNumber[] latency,int arriveTime,double df)
	{
		this.arriveTime = arriveTime;
		this.m = m;
		this.op = op;
		this.df = df;
		this.latency = latency;
	}	
	
	
	
	
	
	
	
	
	public void print(int index)
	{
		System.out.print("JOBID="+index+" ");
		for(int i=0;i<m;i++)
		{
			System.out.print("op["+i+"]="+op[i].toString());
		}
		for(int i=0;i<m;i++)
		{
			System.out.print("delay["+i+"]="+latency[i].toString());
		}
		System.out.println();
		System.out.println("df="+df+ " arrTime="+this.arriveTime);

	}
	
	
	
	public void print(JobRealInfo monitor,int jobid)
	{
		for(int i=0;i<m;i++)
		{
			System.out.print("op["+i+"]="+op[i].toString());
			monitor.printRealOP(jobid, i);
		}
		
		for(int i=0;i<m;i++)
		{
			System.out.print(" latency["+i+"]="+latency[i].toString());
			
			monitor.printRealDelay(jobid, i);
		}
		System.out.print(","+df+","+this.arriveTime);
		System.out.println();
		System.out.println("df="+df+ " arrTime="+this.arriveTime);
	}

	public int getM() {
		return m;
	}

	public FuzzyNumber[] getOp() {
		return op;
	}


}
