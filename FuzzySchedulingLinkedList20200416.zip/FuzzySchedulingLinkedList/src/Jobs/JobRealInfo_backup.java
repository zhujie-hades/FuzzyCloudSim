package Jobs;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

import Experiments.ParametersRange;
import ResourceManagement.Slot;
import ResourceManagement.VirtualClusterList;
import ResourceManagement.VirtualMachine;
import SchedulePlan.FAssignment;
import SchedulePlan.Schedule;
import Tools.CO;
import Tools.FO;
import element.FuzzyNumber;

public class JobRealInfo_backup {
	
	int m;
	HashMap<Integer,int[]> realOP;
	HashMap<Integer,int[]> realDelay;
	/******
	 * task������һЩ״̬��
	 * 1. �Ѿ����ţ���ʼʱ��fuzzy
	 * 2. ��ʼʱ��ȷ�������ʱ��fuzzy
	 * 3. ��ʼʱ�������ʱ�䶼��ȷ����ֻ��task�Ѿ�����ˣ�����ȷ���������ʱ��
	 */
	
	HashMap<Integer,Integer> StartProcessingEndFuzzyStage; //key=jobsid,value=��ʼʱ���Ѷ����ǽ���ʱ��fuzzy���Ǹ�stage������ʱ��һ��job���ֻ��һ������������
	HashMap<Integer,Integer> DoneStage; //key=jobsid,value=����ʱ���Ѿ�ȷ�����Ǹ�stage��value+1����һ�����Կ�ʼ��stage��ע����Կ�ʼ��������ʼʱ���ȷ������ʼʱ���Ƿ��ȷ����Ҫ����ͬ��������ǰһ��task�Ľ���ʱ��
	

	
	public JobRealInfo_backup(int m)
	{
		realOP = new HashMap<Integer,int[]>();
		StartProcessingEndFuzzyStage = new HashMap<Integer,Integer>();
		DoneStage = new HashMap<Integer,Integer>();
		realDelay = new HashMap<Integer,int[]>();
		this.m = m;
	}
	
	public void printRealOP(int jobid,int stageid)
	{
		System.out.println(this.getJobRealOpLength(jobid, stageid));
	}
	
	public void printRealDelay(int jobid,int stageid)
	{
		System.out.println(this.getJobRealDelay(jobid, stageid));
	}
	
	public void addJobRealDelay(int jobid,int stageid,int realvalue)
	{
		if(!this.realDelay.containsKey(jobid))
		{
			int[] delaylist = new int[m];
			this.realDelay.put(jobid, delaylist);
		}
		realDelay.get(jobid)[stageid] = realvalue; 
	}
	
	public int getJobRealDelay(int jobid,int stageid)
	{
		return this.realDelay.get(jobid)[stageid];
	}
	
	public void Clear()
	{
		StartProcessingEndFuzzyStage = new HashMap<Integer,Integer>();
		DoneStage = new HashMap<Integer,Integer>();
	}
	
	public void print(int jobid,int stage)
	{
		System.out.print("=>"+realOP.get(jobid)[stage]);
	}
	
	public int getJobRealOpLength(int jobid,int stageid)
	{
		if(realOP.containsKey(jobid)) return realOP.get(jobid)[stageid];
		return -1;
	}
	
	public void addJobRealOpLength(int jobid,int stageid,int oplength)
	{
		if(realOP.containsKey(jobid)) realOP.get(jobid)[stageid] = oplength;
		else
		{
			int[] op = new int[m];
			op[stageid] = oplength;
			realOP.put(jobid, op);
		}
	}
	
	public void stateUpdatingBeforeScheduling(VirtualClusterList vclist,Schedule schedule,int curTime)
	{
		//�ȼ��ȷ���˿�ʼʱ���stage�Ƿ������
		Iterator<Integer> it = StartProcessingEndFuzzyStage.keySet().iterator();
		HashSet<Integer> doneJobs = new HashSet<Integer>();//��¼�Ѿ�ȫ����ɵ�jobid
		while(it.hasNext())
		{
			int jobid = it.next();
			int stageid = StartProcessingEndFuzzyStage.get(jobid);
			//����Ƿ������
		
			boolean isDone = false;
				FAssignment fas = schedule.getJob(jobid).getAssignment(stageid);
				Slot slot = vclist.getSlotsOfJob(jobid)[stageid];
				int comLength = fas.completeLength(curTime);
				int realLength = realOP.get(jobid)[stageid];
				if(comLength>=realLength)//�Ѿ������ʵ�ʲ���ʱ��
				{
					
					isDone = true;
					doneJobs.add(jobid);					
					int start = fas.getStart().getLowValue();//����ֵ�϶�һ����
					fas.setEndTime(start+realLength);
					
				}
			
			if(isDone) //��job����һ��stage����ȷ����ʼʱ����
			{
				if(stageid<m-1)
				DoneStage.put(jobid, stageid); //������һ��stage
				else DoneStage.remove(jobid);//�Ѿ������һ��stage�ˣ�job�Ѿ����
			}				
		}
		
		
		
		//ɾ���Ѿ���ɵ�ǰtask��job
		it = doneJobs.iterator();
		while(it.hasNext())
		{
			StartProcessingEndFuzzyStage.remove(it.next());
		}
		
		
		//�����û���µ�stage����ȷ����ʼʱ��
			it = DoneStage.keySet().iterator();
			while(it.hasNext())
			{
				int jobid = it.next();
				int stageid = DoneStage.get(jobid)+1;
//				FAssignment[] faslist = vclist.getStartTimesOfJob(jobid);//�Ѿ��Ż�
				FAssignment fas = schedule.getJob(jobid).getAssignment(stageid);
				Slot slot = vclist.getList().get(stageid).findArrangement(jobid);
				
				//TODO ����������ÿ�������һ��stage������
				if(!FO.isFuzzyNumber(fas.getStart())&&fas.isArtificial()) {
					fas.setIsStart(true);
				}
				//Start-----���artificial job
				while(fas.isDone())
				{
					stageid++;
					fas = schedule.getJob(jobid).getAssignment(stageid);
					DoneStage.put(jobid, stageid-1);
				}
				//End-------���artificial job
				
				Slot preSlotOnSameVM = slot.getPreSlot();
				FAssignment prefasOnSameVM = null;
				if(preSlotOnSameVM!=null)
					prefasOnSameVM = schedule.getJob(preSlotOnSameVM.getJobid()).getAssignment(stageid);
				FAssignment prefas = null;
				if(stageid>0) {
					prefas = schedule.getJob(jobid).getAssignment(stageid-1);//���task�϶��Ѿ�������	
					if(!prefas.isDone())
					{
						System.out.println("pre task is not done");
					}
				}
				
				
				
				if(prefas==null&&prefasOnSameVM==null)//job�ĵ�һ��stage���һ����ϵĵ�һ��task
				{
					int earliest = fas.getStart().getLowValue();

					if(curTime<earliest) continue;
					StartProcessingEndFuzzyStage.put(jobid, stageid);
					fas.setStartTime(earliest);//���óɵ�ǰʱ�䣬ԭ�����ó�earliest
					if(!fas.isStart())
					{
						System.out.println("Start Error 1");
					}
				}
				else if(prefas!=null&&prefasOnSameVM==null) //��job�ĵ�һ��stage�������ǻ����ϵ�һ��task
				{
					int realdelay = this.realDelay.get(jobid)[stageid-1];
					
					if(ParametersRange.problemMode==0)
					{
						if(CO.inSameCloud(prefas, fas)) 
						
						realdelay = 0;
						
					}
					else if(ParametersRange.problemMode==1) 
					{
						realdelay = 0;
						
					}
					
					int earliest = fas.getStart().getLowValue();
					if(curTime<earliest) continue;
					StartProcessingEndFuzzyStage.put(jobid, stageid);
					int endofPre = prefas.getEnd().getLowValue()+realdelay;//�����˵Ļ�����ֵһ����ȡ�ĸ�����		
					fas.setStartTime(endofPre);	
					
					if(!fas.isStart())
					{
						System.out.println("Start Error 2");
					}
				}
				else if(prefas==null&&prefasOnSameVM!=null) //job�ĵ�һ��stage�����ǻ�����ǰ��������
				{	
					
						if(prefasOnSameVM.isDone())
						{
							
							int preend = prefasOnSameVM.getEnd().getLowValue();
							int possiblestart = CO.max(fas.getStart().getLowValue(), preend);
							
							
							if(curTime<possiblestart) continue;
							fas.setStartTime(possiblestart);
							StartProcessingEndFuzzyStage.put(jobid, stageid);
							if(!fas.isStart())
							{
								System.out.println("Start Error 3");
							}
						}	
						else continue;
						
				}
				else //prefasOnVM is not null, prefas is not null  ��job�ĵ�һ��stage���Ǹ�̨�����ϵĵ�һ��task
				{
					if(prefasOnSameVM.isDone())
					{
						int realdelay = this.realDelay.get(jobid)[stageid-1];
						if(ParametersRange.problemMode==0)
						{
							if(CO.inSameCloud(prefas, fas)) 
							
							realdelay = 0;
							
						}
						else if(ParametersRange.problemMode==1) 
						{
							realdelay = 0;
							
						}
						FuzzyNumber possiblestart = FO.Max(prefasOnSameVM.getEnd(), FO.Addition(prefas.getEnd(), realdelay));
						
						//TODO ������ܳ�������
						
						
						if(FO.isFuzzyNumber(possiblestart)) continue;
						int pstart = possiblestart.getLowValue();
						if(curTime<pstart) continue;
						fas.setStartTime(pstart);
						

						
						if(fas.isStart())
						{
							StartProcessingEndFuzzyStage.put(jobid, stageid);
						}
						else
						{
							prefasOnSameVM.print();
							prefas.print();
							fas.print();
							System.out.println("ERRORRRRRRRRRRRRRRRRRRRRRRRR xx2");
						}
					}
				}
				VirtualMachine vm = vclist.FindVM(fas.getMid());
				schedule.SaveAssignment(fas);
//				vm.updateAssignment(fas);
			}
		
	}
	public void stateUpdatingAfterScheduling(Event event)
	{
		for(int i=0;i<event.getJobnum();i++)
		{			
			int jobid = event.getJoblist().get(i);
			this.DoneStage.put(jobid, -1);
		}

	}
	
	public void stateUpdatingAfterDone(VirtualClusterList vclist,Schedule schedule)
	{
		
		Iterator<Integer> it = this.StartProcessingEndFuzzyStage.keySet().iterator();
		while(it.hasNext())
		{
			int jobid = it.next();
			int stageid = this.StartProcessingEndFuzzyStage.get(jobid);
			int realLength = realOP.get(jobid)[stageid];
//			FAssignment[] faslist = vclist.getStartTimesOfJob(jobid);
			FAssignment fas = schedule.getJob(jobid).getAssignment(stageid);
			fas.setEndTime(fas.getStart().getLowValue()+realLength);
			if(stageid<m-1)
				DoneStage.put(jobid, stageid);	
			else DoneStage.remove(jobid);//�������ѭ��
		}
		int count = 0;
		boolean print = false;
		while(DoneStage.size()>0) 
		{
			if(print) System.out.println("A new Loopppppppppppppppppppppppppppppppppppppppppppppppp");
			count++;
			if(count>100)
			{
				System.out.println("Dead Loop");
				System.out.println(DoneStage.toString());
				print = true;
			}
			if(count>101) 
			{
				try {
					Thread.sleep(3600000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			it = DoneStage.keySet().iterator();
			HashSet<Integer> donejobs = new HashSet<Integer>();
			while(it.hasNext())
			{
				int jobid = it.next();
				int stageid = DoneStage.get(jobid)+1;
				FAssignment fas = schedule.getJob(jobid).getAssignment(stageid);
				Slot slot = vclist.getSlotsOfJob(jobid)[stageid];
				Slot preslot = slot.getPreSlot();
				FAssignment prefasOnSameVM = null;
				if(preslot!=null) prefasOnSameVM = schedule.getJob(preslot.getJobid()).getAssignment(stageid);
				FAssignment prefas = null;
				if(stageid>0) prefas = schedule.getJob(jobid).getAssignment(stageid-1);//���task�϶��Ѿ�������
				
				if(prefas==null&&prefasOnSameVM==null)
				{
					int earliest = fas.getStart().getLowValue();
					fas.setStartTime(earliest);
					if(print)
					{
						System.out.println("case 1");
						fas.print();
					}
				}
				else if(prefas!=null&&prefasOnSameVM==null) //����delay
				{
					int endofPre = prefas.getEnd().getLowValue();//�����˵Ļ�����ֵһ����ȡ�ĸ�����		
					int realdelay = this.realDelay.get(jobid)[stageid-1]; 
					
					if(ParametersRange.problemMode==0)
					{
						if(CO.inSameCloud(prefas, fas)) 
						
						realdelay = 0;
						
					}
					else if(ParametersRange.problemMode==1) 
					{
						realdelay = 0;
						
					}
					
					fas.setStartTime(endofPre+realdelay);	
					if(print)
					{
						System.out.println("case 2");
						prefas.print();
						fas.print();
					}
				}
				else if(prefas==null&&prefasOnSameVM!=null)
				{		
					
					if(prefasOnSameVM.isDone())
					{
						int preend = prefasOnSameVM.getEnd().getLowValue();
						if(preend<fas.getStart().getLowValue())
						{
							fas.setStartTime(fas.getStart().getLowValue());
						}
						else 
						{
							fas.setStartTime(preend);
							
						}
						if(print)
						{
							System.out.println("case 3");
							prefasOnSameVM.print();
							fas.print();
						}
					}
					
				}
				else  //����delay
				{
					
					if(prefasOnSameVM.isDone())
					{
						int realdelay = this.realDelay.get(jobid)[stageid-1]; 
						
						if(ParametersRange.problemMode==0)
						{
							if(CO.inSameCloud(prefas, fas)) 
							
							realdelay = 0;
							
						}
						else if(ParametersRange.problemMode==1) 
						{
							realdelay = 0;
							
						}
						
						fas.setStartTime(FO.Max(prefasOnSameVM.getEnd(), FO.Addition(prefas.getEnd(), realdelay)));	

						if(print)
						{
							System.out.println("case 4");
							if(!fas.isStart()) System.out.println("%%%%%%%%%%%");
							prefas.print();
							prefasOnSameVM.print();
							fas.print();
						}
					}
					
				}
				
				if(fas.isStart())
				{
					int realLength = realOP.get(jobid)[stageid];
					fas.setEndTime(fas.getStart().getLowValue()+realLength);
					DoneStage.put(jobid, stageid);
				}
				if(stageid==m-1&&fas.isDone())
				donejobs.add(jobid);
				
			}
			Iterator<Integer> dit = donejobs.iterator();
			while(dit.hasNext())
			{
				DoneStage.remove(dit.next());
			}
		}
	}
	
}
