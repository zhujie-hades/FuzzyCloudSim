package Jobs;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

import Experiments.ParametersRange;
import ResourceManagement.Slot;
import ResourceManagement.VirtualClusterList;
import ResourceManagement.VirtualMachine;
import SchedulePlan.FAssignment;
import SchedulePlan.Schedule;
import Tools.CO;
import Tools.FO;
import element.FuzzyNumber;

public class JobRealInfo {
	
	int m;
	HashMap<Integer,int[]> realOP;
	HashMap<Integer,int[]> realDelay;
	/******
	 * task������һЩ״̬��
	 * 1. �Ѿ����ţ���ʼʱ��fuzzy
	 * 2. ��ʼʱ��ȷ�������ʱ��fuzzy
	 * 3. ��ʼʱ�������ʱ�䶼��ȷ����ֻ��task�Ѿ�����ˣ�����ȷ���������ʱ��
	 */
	
	
	public JobRealInfo(int m)
	{
		realOP = new HashMap<Integer,int[]>();
	
		realDelay = new HashMap<Integer,int[]>();
		this.m = m;
	}
	
	public void printRealOP(int jobid,int stageid)
	{
		System.out.println(this.getJobRealOpLength(jobid, stageid));
	}
	
	public void printRealDelay(int jobid,int stageid)
	{
		System.out.println(this.getJobRealDelay(jobid, stageid));
	}
	
	public void addJobRealDelay(int jobid,int stageid,int realvalue)
	{
		if(!this.realDelay.containsKey(jobid))
		{
			int[] delaylist = new int[m];
			this.realDelay.put(jobid, delaylist);
		}
		realDelay.get(jobid)[stageid] = realvalue; 
	}
	
	public int getJobRealDelay(int jobid,int stageid)
	{
		return this.realDelay.get(jobid)[stageid];
	}
	
	
	
	public void print(int jobid,int stage)
	{
		System.out.print("=>"+realOP.get(jobid)[stage]);
	}
	
	public int getJobRealOpLength(int jobid,int stageid)
	{
		if(realOP.containsKey(jobid)) return realOP.get(jobid)[stageid];
		return -1;
	}
	
	public void addJobRealOpLength(int jobid,int stageid,int oplength)
	{
		if(realOP.containsKey(jobid)) realOP.get(jobid)[stageid] = oplength;
		else
		{
			int[] op = new int[m];
			op[stageid] = oplength;
			realOP.put(jobid, op);
		}
	}
	
	
	
}
