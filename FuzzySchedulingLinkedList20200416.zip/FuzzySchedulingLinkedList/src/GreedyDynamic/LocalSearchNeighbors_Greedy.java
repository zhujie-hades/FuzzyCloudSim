package GreedyDynamic;

import java.util.ArrayList;
import java.util.HashMap;

public class LocalSearchNeighbors_Greedy {

	HashMap<Integer,ArrayList<int[]>> OneInsertionNeighbors;
	HashMap<Integer,ArrayList<int[]>> SwitchNeighbors;
	
	HashMap<Integer,Integer> OneInsertionSize;
	HashMap<Integer,Integer> SwitchSize;
	
	public LocalSearchNeighbors_Greedy()
	{
		OneInsertionNeighbors = new HashMap<Integer,ArrayList<int[]>>();
		SwitchNeighbors = new HashMap<Integer,ArrayList<int[]>>();	
		OneInsertionSize = new HashMap<Integer,Integer>();
		SwitchSize = new HashMap<Integer,Integer>();	
	}
	private void genOneInsertionNeighbors(int size)
	{
		
		ArrayList<int[]> neighbors = new ArrayList<int[]>();
		int num = 0;
		for(int pick=0;pick<size;pick++)
		{
			
			for(int loc = 0;loc<pick;loc++)
			{		
				int[] item = new int[size];
				for(int i=0;i<loc;i++)
					item[i] = i;
				item[loc] = pick;
				for(int i=loc+1;i<=pick;i++)
					item[i] = i-1;
				for(int i=pick+1;i<size;i++)
					item[i] = i;
				neighbors.add(item);
				num++;
			}
			for(int loc = pick+2;loc<size+1;loc++)
			{
				int[] item = new int[size];
				for(int i=0;i<pick;i++)
					item[i] = i;
				for(int i=pick;i<loc-1;i++)
					item[i] = i+1;
				item[loc-1] = pick;
				for(int i=loc;i<size;i++)
					item[i] = i;
				neighbors.add(item);
				num++;
			}			
		}
		this.OneInsertionNeighbors.put(size, neighbors);
		this.OneInsertionSize.put(size, num);
	}
	private void genSwitchNeighbors(int size)
	{
		ArrayList<int[]> neighbors = new ArrayList<int[]>();
		int num = 0;
		for(int i=0;i<size;i++)
		{
			for(int j=i+1;j<size;j++)
			{
				int[] item = new int[size];
				for(int k=0;k<i;k++)
					item[k] = k;
				item[i] = j;
				for(int k=i+1;k<j;k++)
					item[k] = k;
				item[j] = i;
				for(int k=j+1;k<size;k++)
					item[k] = k;
				neighbors.add(item);
				num++;
			}
		}	
		this.SwitchNeighbors.put(size, neighbors);
		this.SwitchSize.put(size, num);
	}
	public ArrayList<int[]> getOneInsertionNeighbors(int size) {
		if(!OneInsertionNeighbors.containsKey(size)) 
			this.genOneInsertionNeighbors(size);
		return OneInsertionNeighbors.get(size);
	}

	public ArrayList<int[]> getSwitchNeighbors(int size) {
		if(!SwitchNeighbors.containsKey(size))
			this.genSwitchNeighbors(size);
		return SwitchNeighbors.get(size);
	}

	public int getOneInsertionSize(int size) {
		return OneInsertionSize.get(size);
	}

	public int getSwitchSize(int size) {
		return SwitchSize.get(size);
	}

	private void printArr(int[] item)
	{
		for(int i=0;i<item.length;i++)
			System.out.print(item[i]+" ");
		System.out.println();
	}
	public void printOneInsertionNeighbors(int size)
	{
		ArrayList<int[]> neighbor = this.OneInsertionNeighbors.get(size);
		int num = this.OneInsertionSize.get(size);
		for(int i=0;i<num;i++)
			this.printArr(neighbor.get(i));
	}
	public void printSwitchNeighbors(int size)
	{
		ArrayList<int[]> neighbor = this.SwitchNeighbors.get(size);
		int num = this.SwitchSize.get(size);
		for(int i=0;i<num;i++)
			this.printArr(neighbor.get(i));
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalSearchNeighbors_Greedy lsn = new LocalSearchNeighbors_Greedy();
//		lsn.getOneInsertionNeighbors(5);
//		lsn.printOneInsertionNeighbors(5);
		lsn.getSwitchNeighbors(5);
		lsn.printSwitchNeighbors(5);
	}

}
