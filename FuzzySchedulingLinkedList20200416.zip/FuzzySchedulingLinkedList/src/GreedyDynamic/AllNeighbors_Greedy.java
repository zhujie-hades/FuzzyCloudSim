package GreedyDynamic;

import java.util.ArrayList;

public class AllNeighbors_Greedy {

	ArrayList<int[]> neighbors2;
	ArrayList<int[]> neighbors3;
	ArrayList<int[]> neighbors4;
	ArrayList<int[]> neighbors5;
	ArrayList<int[]> neighbors6;
	ArrayList<int[]> neighbors7;
	ArrayList<int[]> neighbors8;
	int size2 = 2;
	int size3 = 6;
	int size4 = 24;
	int size5 = 120;
	int size6 = 720;
	int size7 = 5040;
	int size8 = 40320;
	public AllNeighbors_Greedy()
	{
		neighbors2 = new ArrayList<int[]>();
		neighbors3 = new ArrayList<int[]>();
		neighbors4 = new ArrayList<int[]>();
		neighbors5 = new ArrayList<int[]>();
		neighbors5 = new ArrayList<int[]>();
		neighbors6 = new ArrayList<int[]>();
		neighbors7 = new ArrayList<int[]>();
		neighbors8 = new ArrayList<int[]>();
		
		gen2();
		gen(3);
		gen(4);
		gen(5);
		gen(6);
		gen(7);
		gen(8);
	}
	public int getSize(int size)
	{
		if(size==2) return size2;
		else if(size==3) return size3;
		else if(size==4) return size4;
		else if(size==5) return size5;
		else if(size==6) return size6;
		else if(size==7) return size7;
		return size8;
	}
	public ArrayList<int[]> getNeighbors(int size)
	{
		if(size==2) return neighbors2;
		else if(size==3) return neighbors3;
		else if(size==4) return neighbors4;
		else if(size==5) return neighbors5;
		else if(size==6) return neighbors6;
		else if(size==7) return neighbors7;
		else if(size==8) return neighbors8;
		return null;
	}
	public void gen2()
	{
		int[] a = {0,1};
		int[] b = {1,0};
		neighbors2.add(a);
		neighbors2.add(b);
	}
	public void gen(int index)
	{
		int size = index;
		int newitem = index-1;
		int lastsize = -1;
		ArrayList<int[]> lastneighbors = null;
		ArrayList<int[]> curneighbors = null;
		if(size==3)
		{
			lastneighbors = neighbors2;
			curneighbors = neighbors3;
			lastsize = size2;
		}
		else if(size==4)
		{
			lastneighbors = neighbors3;
			curneighbors = neighbors4;
			lastsize = size3;
		}
		else if(size==5)
		{
			lastneighbors = neighbors4;
			curneighbors = neighbors5;
			lastsize = size4;
		}
		else if(size==6)
		{
			lastneighbors = neighbors5;
			curneighbors = neighbors6;
			lastsize = size5;
		}
		else if(size==7)
		{
			lastneighbors = neighbors6;
			curneighbors = neighbors7;
			lastsize = size6;
		}
		else if(size==8)
		{
			lastneighbors = neighbors7;
			curneighbors = neighbors8;
			lastsize = size7;
		}
		for(int i=0;i<lastsize;i++)
		{
			int[] last = lastneighbors.get(i);
			for(int j=0;j<size;j++)
			{
				int[] item = new int[size];
				for(int k=0;k<j;k++)
					item[k] = last[k];
				item[j] = newitem;
				for(int k=j+1;k<size;k++)
				item[k] = last[k-1];
				curneighbors.add(item);
			}
		}
	}
	public void gen3()
	{
		int size = 3;
		int newitem = 2;
		for(int i=0;i<size2;i++)
		{
			int[] last = neighbors2.get(i);
			for(int j=0;j<size;j++)
			{
				int[] item = new int[size];
				for(int k=0;k<j;k++)
					item[k] = last[k];
				item[j] = newitem;
				for(int k=j+1;k<size;k++)
				item[k] = last[k-1];
				neighbors3.add(item);
			}
		}
	}
	public void printAll(int index)
	{
		int size = -1;
		ArrayList<int[]> neighbors = null;
		if(index==3)
		{
			size = size3;
			neighbors = neighbors3;
		}
		else if(index==4)
		{
			size = size4;
			neighbors = neighbors4;
		}
		else if(index==5)
		{
			size = size5;
			neighbors = neighbors5;
		}
		else if(index==6)
		{
			size = size5;
			neighbors = neighbors6;
		}
		else if(index==5)
		{
			size = size7;
			neighbors = neighbors7;
		}
		for(int i=0;i<size;i++)
		{
			int[] item = neighbors.get(i);
			this.printArr(item);
		}
	}
	private void printArr(int[] item)
	{
		for(int i=0;i<item.length;i++)
			System.out.print(item[i]+" ");
		System.out.println();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AllNeighbors_Greedy an = new AllNeighbors_Greedy();
		an.printAll(3);
	}

}
