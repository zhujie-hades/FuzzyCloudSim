package resultProcess;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import Jobs.FJOB;

public class ResultProcess {

	
	public static void MergeResult(String location, String prefix)
	{
		File file = new File(location);
		File resultfile = new File(location+"\\"+prefix+".txt");
		File[] files = file.listFiles();
		for (int i = 0; i < files.length; i++) {
		    File fs = files[i];
		    if (!fs.isDirectory()&&fs.getName().startsWith(prefix)) 
		    {
				BufferedWriter write = null;
				BufferedReader read = null;
				try {
				read = new BufferedReader(new InputStreamReader(new FileInputStream(fs)));
				write = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(resultfile, true)));
				String data = null;
				while((data = read.readLine())!=null)
				{
//					if(data.startsWith("DES5")||data.startsWith("DES6")||data.startsWith("DES7")||data.startsWith("DES8")) 
//					{
						write.append(data);
						write.write(""+"\r\n");
//					}
				}	
					
					read.close();
					write.close();
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    } 
		}
	}
	
	public static void tempProcess3(String location,String ff,String tf)
	{
		File fromFile = new File(location+"\\"+ff+".txt");
		BufferedReader read = null;
		try {
		read = new BufferedReader(new InputStreamReader(new FileInputStream(fromFile)));
		String data1 = null;	
		int count1 = 0;
		int count2 = 0;
		int count3 = 0;
		int count4 = 0;
		while((data1 = read.readLine())!=null)
		{
			String[] arr = data1.split("\t");
			
		}	
			
			read.close();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} 
	public static void tempProcess2(String location,String ff,String tf,String ALG)
	{
		File fromFile = new File(location+"\\"+ff+".txt");
		File toFile = new File(location+"\\"+tf+".txt");
		BufferedWriter write = null;
		BufferedReader read = null;
		try {
		read = new BufferedReader(new InputStreamReader(new FileInputStream(fromFile)));
		write = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(toFile, true)));
		String data = null;
		
		while((data = read.readLine())!=null)
		{
			if(data.startsWith(ALG)) 
			{write.append(data);
			write.write(""+"\r\n");}
			
		}	
			
			read.close();
			write.close();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void tempProcess5(String location,String ff,int m)
	{
		File fromFile = new File(location+"\\"+ff+".txt");
		//File toFile = new File(location+"\\"+tf+".txt");
		//BufferedWriter write = null;
		BufferedReader read = null;
		try {
		read = new BufferedReader(new InputStreamReader(new FileInputStream(fromFile)));
		//write = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(toFile, true)));
		String data1 = null;
		int[] count =new int[5];
		while((data1 = read.readLine())!=null)
		{
			String[] list = new String[m];
			list[0] = data1;
			for(int i=1;i<m;i++) list[i] = read.readLine();
			
			String data = "";
			double min = 10000;
			boolean flag = false;
			for(int i=0;i<m-1;i++)
			{
				double d1 = Double.parseDouble(list[i].split("\t")[13]);
				double d2 = Double.parseDouble(list[i+1].split("\t")[13]);
				if(d1!=d2) flag = true;
			}
			if(!flag) continue;
			for(int i=0;i<m;i++)
			{
				double d = Double.parseDouble(list[i].split("\t")[13]);
				if(d<min){min=d;data=list[i];}
			}
			count[Integer.parseInt(data.split("\t")[5])-1]++;
			
		}	
		for(int i=0;i<m;i++)
		{
			System.out.print(count[i]+"\t");
		}
			read.close();
			//write.close();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void getherCompare(String location,String ff,String tf)
	{
		File fromFile = new File(location+"\\"+ff+".txt");
		File toFile = new File(location+"\\"+tf+".txt");
		BufferedWriter write = null;
		BufferedReader read = null;
		try {
		read = new BufferedReader(new InputStreamReader(new FileInputStream(fromFile)));
		write = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(toFile, true)));
		String data = null;
		
		while((data = read.readLine())!=null)
		{
			String[] darray = data.split("\t");
			if(darray[0].equalsIgnoreCase("DES38")||darray[0].equalsIgnoreCase("DES11")||darray[0].equalsIgnoreCase("DES12")||darray[0].equalsIgnoreCase("DES15")||darray[0].equalsIgnoreCase("DES16")) 
			{
				if(Double.parseDouble(darray[26])<120)
				{
					write.append(data);
					write.write(""+"\r\n");
				}
				
			}
			
		}	
			
			read.close();
			write.close();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void tempProcess(String location,String ff,String tf)
	{
		File fromFile = new File(location+"\\"+ff+".txt");
		File toFile = new File(location+"\\"+tf+".txt");
		BufferedWriter write = null;
		BufferedReader read = null;
		try {
		read = new BufferedReader(new InputStreamReader(new FileInputStream(fromFile)));
		write = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(toFile, true)));
		String data = null;
		
		while((data = read.readLine())!=null)
		{
			String[] darray = data.split("\t");
			System.out.println(data+" "+darray.length);
			if(darray.length>12) 
			{write.append(data);
			write.write(""+"\r\n");}
			else
			{
				String newdata = "";
				for(int i=0;i<6;i++)
				{
					newdata+=darray[i]+"\t";
				}
				newdata+="10"+"\t1200\t";
				for(int i=6;i<11;i++)
					newdata+=darray[i]+"\t";
				newdata+=darray[11];
				write.append(newdata);
				write.write(""+"\r\n");
			}
		}	
			
			read.close();
			write.close();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void processIntoOne(String location, String prefix)
	{
		File file = new File(location);
		File resultfile = new File(location+"\\"+prefix+".txt");
		File[] files = file.listFiles();
		for (int i = 0; i < files.length; i++) {
		    File fs = files[i];
		    if (!fs.isDirectory()&&fs.getName().startsWith(prefix)&&fs.getName().endsWith("ALL.txt")) 
		    {
				BufferedWriter write = null;
				BufferedReader read = null;
				try {
				read = new BufferedReader(new InputStreamReader(new FileInputStream(fs)));
				write = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(resultfile, true)));
				String data = null;
				while((data = read.readLine())!=null)
				{
					if(data.startsWith("DES5")||data.startsWith("DES6")||data.startsWith("DES7")||data.startsWith("DES8")) 
					{write.append(data);
					write.write(""+"\r\n");}
				}	
					
					read.close();
					write.close();
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    } 
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		ResultProcess.processIntoOne("D:\\��������\\Experiment Results", "Tmax_3");
		//ResultProcess.tempProcess("D:\\��������\\Experiment Results", "Tmax_3", "Tmax_3_temp");
		//ResultProcess.tempProcess2("D:\\��������\\Experiment Results", "Tmax_10_1488716978167", "Tmax_10_DES5", "DES5");
//		ResultProcess.tempProcess5("D:\\��������\\Experiment Results", "Tmax_10_DES5",5);
//		int m = 10;
//		String prefix = "Compare_"+m;
//		ResultProcess.MergeResult("D:\\��������\\Experiment Results\\Fuzzy\\noVND", prefix);
		int m=10;
		ResultProcess.getherCompare("D:\\��������\\Experiment Results\\Fuzzy\\noVND", "Compare_"+m, "Compare");
	}

}
