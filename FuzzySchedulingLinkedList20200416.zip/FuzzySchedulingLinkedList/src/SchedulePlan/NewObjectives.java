package SchedulePlan;

import java.util.ArrayList;
import java.util.HashSet;

import Jobs.FJOBS;
import ResourceManagement.VirtualClusterList;
import element.C;

public class NewObjectives {

	int totalRealUsageDuraionOnRented;
	int totalRealUsageLengthOnRented;
	int costR;
	double nomarlObject;
	int makespan;
	int newnum;
	public int getCostR() {
		return costR;
	}

	public int getCostO() {
		return costO;
	}
	
	public double getNormalObjective(double w,double lowerbound)
	{
		double nomarlObject = 0;
		if(lowerbound==-1) lowerbound = this.costR;
		nomarlObject = w*((double)lowerbound/this.FCOST)+(1-w)*this.satisfactionRate;
		return nomarlObject;
	}

	int costO;
//	int[] acostR;
//	int[] acostO;
	double satisfactionRate;
//	int[] UtilizationRateNum;//UtilizationRateNum[i]��ʹ������i/10��(i+1)/10֮�����������
//	int[] UtilizationUsageTime;//UtilizationUsageTime[i]��ʹ������i/10��(i+1)/10֮������ϵļӹ�ʱ��
//	int[] accumulatedUtilizationRateNum;//accumulatedUtilizationRateNum[i]��ʹ���ʴ��ڵ���i/10�Ļ�������	
//	int[] accumulatedUtilizationUsageTime;//accumulatedUtilizationUsageTime[i]��ʹ����С�ڵ���i/10�Ļ����ϵļӹ�ʱ��
//	double aUtilization;
//	public double getaUtilization() {
//		return aUtilization;
//	}

	int FCOST;
	public int getFCOST() {
		return FCOST;
	}

//	public int getACOST() {
//		return ACOST;
//	}
//
//	int ACOST;
	
//	VirtualClusterList vclist;
//	FJOBS jobs;
	
	public NewObjectives(Schedule schedule,VirtualClusterList vclist)
	{

		this.satisfactionRate = schedule.satisfactionRate();
		int t = schedule.getMakespan().getHighValue();
		totalRealUsageDuraionOnRented = vclist.gettotalRealUsageDuraionOnRented();
		totalRealUsageLengthOnRented = vclist.gettotalUsageTimeOnRented();

		makespan = t/C.Charge_Time_Unit;
		System.out.println("makespan = "+makespan);
		newnum = vclist.getNewMachineNum();
		System.out.println("newnumber = "+newnum);
		System.out.println("totalRealUsageDuraionOnRented = "+totalRealUsageDuraionOnRented/C.Charge_Time_Unit);
		System.out.println("totalRealUsageLengthOnRented = "+totalRealUsageLengthOnRented/C.Charge_Time_Unit);
//		vclist.computeUtilizationInfor(UtilizationRateNum,UtilizationUsageTime,t);
		
		costR = vclist.getOldMachineNumOfStage(0)*vclist.getM()*C.Price_R*(t/C.Charge_Time_Unit);
//		costO = (totalRealUsageDuraionOnRented/C.Charge_Time_Unit)*C.Price_On;
		costO = (totalRealUsageLengthOnRented/C.Charge_Time_Unit)*C.Price_On;
		

		
		this.FCOST = this.getCost();

		
	}
	
	
	
	public int getMakespan() {
		return makespan;
	}

	public int getNewnum() {
		return newnum;
	}

	public void setFCOST(int fCOST) {
		FCOST = fCOST;
	}

//	public void setACOST(int aCOST) {
//		ACOST = aCOST;
//	}

	public int getCost(){ return this.costO+this.costR;}

	
	public String getString(int[] a)
	{
		String result = "";
		for(int i=0;i<10;i++)
		{
			result+=a[i]+",";
		}
		return result;
	}
	
	public String getString()
	{
		String result = "SD="+this.satisfactionRate+" totalCost="+this.getCost();
		return result;
	}
	
	
	

	public void print()
	{
		System.out.println(this.getString());
		System.out.println("CostR="+this.costR);
		System.out.println("CostO="+this.costO);
		System.out.println("totalUsageTimeOnRented="+totalRealUsageDuraionOnRented);
//		System.out.println(this.getString(this.accumulatedUtilizationRateNum));
//		System.out.println(this.getString(this.accumulatedUtilizationUsageTime));
//		System.out.println("acosto="+this.getString(this.acostO));
//		System.out.println("acostr="+this.getString(this.acostR));

	}
	
	public double getSatisfactionRate() {
		return satisfactionRate;
	}



	
}
