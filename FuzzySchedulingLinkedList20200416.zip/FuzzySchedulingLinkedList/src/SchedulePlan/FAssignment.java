package SchedulePlan;

import Tools.FO;
import element.FuzzyNumber;

public class FAssignment {

	String mid;
//	int start;
	FuzzyNumber start;
	int jobid;
	int stage;
//	int end;
	FuzzyNumber op;
	public FuzzyNumber getOp() {
		return op;
	}

	FuzzyNumber end;
	boolean isDone = false;
	boolean isStart = false;
	
	
	
	public boolean isArtificial()
	{
		if(FO.Comparison(FO.Subtraction(end, start), 0)<=0) return true;
		return false;
	}
	
	public String toString()
	{
		String str = "jobid:"+jobid+" vmid="+mid+" start:"+start.toString()+" end:"+end.toString()+"op:"+op.toString()+" "+isStart+" "+isDone;
		
		return str;
	}
	
	public int completeLength(int currentTime)
	{
		int result = 0;
		if(isStart)
		{
			int startTime = start.getLowValue();
			result = currentTime-startTime;
		}
		
		return result;
	}
	
	public void setStartTime(int starttime)
	{
//		if(isStart==true) System.out.println("ERRORRRRR: Duplicately setting a real starttime 1");
//		if(isDone==true) System.out.println("ERRORRRRR: Restart a done assignment  1");

		this.setIsStart(true);	
		FuzzyNumber newstart = new FuzzyNumber(starttime);
		start = newstart;
		this.end = FO.Addition(newstart, op);
	}
	
	public void setStartTime(FuzzyNumber newstart)
	{
//		if(isStart==true) System.out.println("ERRORRRRR: Duplicately setting a real starttime 2");
//		if(isDone==true) System.out.println("ERRORRRRR: Restart a done assignment  2");
		
		start = newstart.Clone();	
		this.end = FO.Addition(newstart, op);		
		if(!FO.isFuzzyNumber(start)) this.setIsStart(true);;
	}
	
	public void setEndTime(int endtime)
	{
		isDone = true;
		end = new FuzzyNumber(endtime);
		
	}
	
	
	
	public boolean isDone() {
		return isDone;
	}
//	public void setDone(boolean isDone) {
//		this.isDone = isDone;
//	}
	public boolean isStart() {
		return isStart;
	}
	public void setIsStart(boolean isStart) {
		this.isStart = isStart;
	}

	
	
	public void setMid(String mid) {
		this.mid = mid;
	}
	
		public FAssignment(String mid,FuzzyNumber start,int jobid, int stage,FuzzyNumber end,FuzzyNumber op)
	{
		this.mid = mid;
		this.start = start.Clone();
		this.jobid = jobid;
		this.stage = stage;
		this.end = end.Clone();
		this.op = op;
		if(!FO.isFuzzyNumber(start)) this.isStart = true; else this.isStart = false;
		if(!FO.isFuzzyNumber(end)) this.isDone = true; else this.isDone = false;
//		this.isDone = isDone;
//		this.isStart = isStart;
	}
//	public Assignment()
//	{
//		
//	}
		
	public FuzzyNumber getEnd() {
			return end;
		}
	public String getMid() {
		return mid;
	}
	public int getJobid() {
		return jobid;
	}
	public int getStage() {
		return stage;
	}
	public FuzzyNumber getStart() {
		return start;
	}
	public FAssignment Clone(){
		FAssignment as = new FAssignment(this.mid,this.start,this.jobid,this.stage, this.end,this.op);
		return as;
	}
	
	public void print(){
		System.out.println("Assignment mid="+mid+" start="+start.toString()+", end="+end.toString()+", op="+op.toString()+" jobid="+jobid+" "+" "+isStart+" "+isDone);
	}
}
