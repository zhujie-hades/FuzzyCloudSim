package SchedulePlan;

import java.util.ArrayList;
import java.util.HashMap;

import Jobs.FJOB;
import Jobs.FJOBS;
import ResourceManagement.Slot;
import Tools.FO;
import element.C;
import element.FuzzyNumber;
import element.Parameters;

public class Schedule {
	
	int n;
	int m;
	HashMap<Integer,FJobAssignment> jobaslist;
	
	
	
	public void SaveAssignment(FAssignment as)
	{
		int jobid = as.getJobid();
		FJobAssignment job_as = jobaslist.get(jobid);
		job_as.saveAssignment(as);
	}
	
	public Schedule(int n,int m,FJOBS jobs,Parameters setting)
	{
		this.n = n;
		this.m = m;
		jobaslist = new HashMap<Integer,FJobAssignment>();
		for(int i=0;i<n;i++)
		{
			FJOB job = jobs.getJob(i);
			FJobAssignment fjas = new FJobAssignment(i,job,job.getDf(),setting.getJD(),setting.isLooseDeadline());
			jobaslist.put(i, fjas);
		}
	}
	
	public void rollbackAssignments(ArrayList<Slot> slotlist)
	{
		int size = slotlist.size();
		for(int i=0;i<size;i++)
		{
			Slot slot = slotlist.get(i);
			int jobid = slot.getJobid();
			int stage = Integer.parseInt(slot.getVmid().split("_")[0]);
			
			jobaslist.get(jobid).cancelAssignment(stage);
			
		}
	}
	
	public int getM() {
		return m;
	}

	public FJobAssignment getJob(int jobid)
	{
		return jobaslist.get(jobid);
	}
	
	public FuzzyNumber getMakespan()
	{
		FuzzyNumber result = C.TimeZero;
		for(int i=0;i<n;i++)
		{
			FuzzyNumber jend = this.jobaslist.get(i).completeTime();
			if(FO.Comparison(result, jend)==C.LESS) result = jend;
		}
		return result;
	}
	
//	public int getTotalUsageTimeOnRentedVMs()
//	{
//		int result = 0;
//		for(int i=0;i<n;i++)
//			result += this.jobaslist.get(i).getTotalUsageTimeOnRentedVMs();
//		return result;
//	}
	
	public double satisfactionRate()
	{
		double result = 0;
		for(int i=0;i<n;i++)
		{
			FJobAssignment job_as = this.getJob(i);
			result+=job_as.getSatisfactionDegree();
		}
		return result/n;
	}

	public int getN() {
		return n;
	}
	

}
