package SchedulePlan;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import Jobs.Event;
import Jobs.FTask;
import ResourceManagement.ChargingOnOnDemand;
import Tools.CO;
import Tools.FO;
import element.C;
import element.FuzzyNumber;

public class biObject {//�ֲ�����ʱ�������۽�ĺû�
	
	
	//makespanԽСԽ��
	double costR;
	double costO;	
//	double satisfactionRate;
	
	public biObject()
	{
		costR = 0;
		costO = 0;
//		satisfactionRate = 1;
	}
	
	
	
	public double getCost()
	{
//		return costR+costO;
//		if(costO==0)
//		return costR;
//		else 
			return costO+costR;
	}
	
	public void compute(HashMap<Integer,ArrayList<FAssignment>> result,Event event, int totalOldVMNum, HashMap<String,ChargingOnOnDemand> charingInfo)
	{
		//��makespan����costOnR
		int makespan = 0;//�ɻ�����������makespan
		int newvmnum = 0;
		int m = event.getM();
		HashMap<String,ChargingOnOnDemand> tempinfo = new HashMap<String,ChargingOnOnDemand>();
		int size = event.getJobnum();
		if(size==0) return;
		for(int i=0;i<size;i++)
		{
			int jobid = event.getJoblist().get(i);
			ArrayList<FAssignment> aslist = result.get(jobid);
			int assize = aslist.size();
//			if(aslist.size()<m)
//			{
//				for(int k=0;k<aslist.size();k++)
//					aslist.get(k).print();
//			}
			
			FAssignment lastas = aslist.get(assize-1);
			
			if(makespan<lastas.getEnd().getHighValue()) makespan = lastas.getEnd().getHighValue();
			
			for(int j=0;j<assize;j++)
			{
				FAssignment as = aslist.get(j);
				if(CO.isNewVM(as.getMid())) 
				{
					if(tempinfo.containsKey(as.getMid()))//���ε����Ѿ��Ʒѹ��Ļ���
					{
						ChargingOnOnDemand charge = tempinfo.get(as.getMid());
						if(FO.Comparison(as.getEnd(), charge.getEnd())==C.MORE)
						{
							charge.setEnd(as.getEnd());
						}
					}
					else if(charingInfo.containsKey(as.getMid()))//���ε��Ȼ�δ�Ʒѹ��Ļ���
					{
						ChargingOnOnDemand charge = charingInfo.get(as.getMid());
						FuzzyNumber start = charge.getEnd();//�Ѿ�����һ�����ڼƷѹ��Ľ���ʱ��Ϊ���μƷѿ�ʼ
						FuzzyNumber end = as.getEnd();//���end����start
						if(FO.Comparison(start, end)==C.LESS)
						{
							ChargingOnOnDemand newcharge = new ChargingOnOnDemand(as.getMid(),start,end);
							tempinfo.put(as.getMid(), newcharge);
						}
						else
						{
							//�п��ܵģ����뵽֮ǰ���ŵ�ĳ��as֮ǰ,���ټƷ�
						}
					}
					else //ȫ�����޻���
					{
						ChargingOnOnDemand newcharge = new ChargingOnOnDemand(as.getMid(),as.getStart(),as.getEnd());
						tempinfo.put(as.getMid(), newcharge);
					}
				}				
			}
		}
		costR = (double)(makespan-event.getArriveTime())/C.Charge_Time_Unit*totalOldVMNum*C.Price_R;
		Iterator<String> it = tempinfo.keySet().iterator(); 
		while(it.hasNext())
		{
			String mid = it.next();
			ChargingOnOnDemand newcharge = tempinfo.get(mid);
			costO += (double)(newcharge.getEnd().getHighValue()-newcharge.getStart().getLowValue())/C.Charge_Time_Unit*C.Price_On;
		}
		
	}

	

}
