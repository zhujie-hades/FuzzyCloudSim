package SchedulePlan;

import ResourceManagement.Slot;
import element.FuzzyNumber;

public class FPlan {
	public FuzzyNumber getPlanstart() {
		return planstart;
	}

	public void setPlanstart(FuzzyNumber planstart) {
		this.planstart = planstart;
	}

	FuzzyNumber planstart;
	FuzzyNumber planend;
	Slot planslot;
	
	public String toString()
	{
		String str = "";
		str = "Plan from "+ planstart.toString()+" to "+planend.toString()+" on "+planslot.toString();
		return str;
	}
	
	public FPlan(FuzzyNumber planstart,FuzzyNumber planend,Slot planslot)
	{
		this.planslot = planslot;
		this.planstart = planstart;
		this.planend = planend;
	}

	public FuzzyNumber getPlanend() {
		return planend;
	}

	public void setPlanend(FuzzyNumber planend) {
		this.planend = planend;
	}

	public Slot getPlanslot() {
		return planslot;
	}

	public void setPlanslot(Slot planslot) {
		this.planslot = planslot;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
