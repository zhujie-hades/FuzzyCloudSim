package SchedulePlan;

import Jobs.FJOB;
import Jobs.FTask;
import Jobs.JobRealInfo;
import Tools.CO;
import Tools.FO;
import element.C;
import element.FuzzyNumber;
import element.TaskState;

public class FJobAssignment {
	
	int m;
//	int[] op;
    FTask[] tasklist;
   
	FuzzyNumber tlength;
	
	FAssignment[] aslist;
	
	int arriveTime;
	
	int jobid;
	
	FuzzyNumber deadline;
	
	FuzzyNumber fakeddeadline;
	
	double df;
	
	public int getArriveTime() {
		return arriveTime;
	}
	public int getJobid() {
		return jobid;
	}

	public FuzzyNumber getDeadline() {
		return deadline;
	}

	


	public FuzzyNumber completeTime()
	{
		return aslist[m-1].getEnd();
	}
	
	public int getTotalUsageTimeOnOldVMs()
	{
		int result = 0;
		for(int i=0;i<m;i++)
		{
			if(!CO.isNewVM(aslist[i].getMid())) 
			{
				result += aslist[i].getEnd().getHighValue()-aslist[i].getStart().getLowValue();//�����ϴ�ʱ��asΪreal
			}
		}
		return result;
	}

	public void saveAssignment(FAssignment as)
	{
//		System.out.println(" stageid="+as.getStage());
		aslist[as.getStage()] = as;
		if(tasklist[as.getStage()].getTaskstate()==TaskState.READY2PLAN)
			tasklist[as.getStage()].setTaskstate(TaskState.PLANNED);
	}

	public double getSatisfactionDegree()
	{
		double rate = 0;
		FAssignment p = aslist[m-1];
		double end = p.getEnd().getHighValue();
		
		if(end<=deadline.getMostValue()) rate = 1;
		else if(end>=deadline.getHighValue()) rate = 0;
		else
		{
			rate = (deadline.getHighValue()-end)/(deadline.getHighValue()-deadline.getMostValue());
		}
		return rate;
	}
	
	public void cancelAssignment(int stage)
	{
		tasklist[stage].setTaskstate(TaskState.READY2PLAN);
		aslist[stage] = null;
		for(int i=stage+1;i<m;i++)//���������task��as������
		{
//			if(tasklist[i].getTaskstate()!=TaskState.UNREADY) System.out.println("Error: Taskstate error");
			aslist[i] = null;
			tasklist[i].setTaskstate(TaskState.UNREADY);
		}
	}

	public FJobAssignment(int jobid,int m,FuzzyNumber[] op,FuzzyNumber[] delay,int arriveTime,double df,double fdf,boolean loose)
	{
		this.jobid = jobid;
		this.arriveTime = arriveTime;
		this.m = m;
		tasklist = new FTask[m];
		aslist = new FAssignment[m];
		for(int i=0;i<m;i++) aslist[i] = null;
		tlength=new FuzzyNumber(0,0,0);		
		
		for(int i=0;i<m;i++) 
		{
			tasklist[i] = new FTask(op[i], delay[i],FO.Addition(tlength, new FuzzyNumber(arriveTime)), null,jobid,i);
			tlength=FO.Addition(tlength, FO.Addition(op[i], delay[i]));			
			if(i==0)
			{
				tasklist[i].setPriority1(null);				
//				tasklist[i].setPriority(tasklist[i].getEarliest());//��������ܿ�ʼʱ��Ϊ���ȼ�
				tasklist[i].setTaskstate(TaskState.READY2PLAN);//��һ��������ready״̬
			}
			else
			{
				tasklist[i].setPriority1(null);
				tasklist[i].setTaskstate(TaskState.UNREADY);
			}
		}
		deadline = FO.Addition(FO.Multipy(tlength, df), this.arriveTime);
		fakeddeadline = null;
		this.df = df;
		if(fdf==C.JD1) //deadline����
		{
			fakeddeadline = deadline.Clone();
		}
		else if(fdf==C.JD3)
		{
			fakeddeadline = new FuzzyNumber(deadline.getHighValue());
		}
		else if(fdf==C.JD2) //
		{
			fakeddeadline = new FuzzyNumber(deadline.getMostValue());
		}
		if(loose)
		for(int i=m-1;i>=0;i--)
		{
			if(i==m-1)
			{
				
				tasklist[i].setLatest(FO.Subtraction(fakeddeadline, FO.Addition(op[i], delay[i])));
				tasklist[i].setPriority2(tasklist[i].getLatest());
//				System.out.println(fakeddeadline.toString()+"-("+op[i].toString()+"+"+delay[i].toString()+")");
			}
			else 
			{
				tasklist[i].setLatest(FO.Subtraction(tasklist[i+1].getLatest(), FO.Addition(op[i], delay[i])));
				tasklist[i].setPriority2(tasklist[i].getLatest());
			}
		}
		else
		{
			FuzzyNumber sum = new FuzzyNumber(0);
			for(int i=m-1;i>=0;i--)
			{				
					tasklist[i].setLatest(FO.Subtraction(fakeddeadline, FO.Addition(FO.Addition(op[i], delay[i]), sum)));
					tasklist[i].setPriority2(tasklist[i].getLatest());
					sum = FO.Addition(sum, FO.Multipy(FO.Addition(op[i], delay[i]), df));				
			}			
		}
		
		
	}	
	
	public FJobAssignment(int index,FJOB job,double df,double fdf,boolean loose)
	{
		this.jobid = index;
		this.arriveTime = job.getArriveTime();
		int earlieststart = arriveTime+C.EVENTINTERVAL;
		this.m = job.getM();
		tasklist = new FTask[m];
		aslist = new FAssignment[m];
		for(int i=0;i<m;i++) aslist[i] = null;
		tlength=new FuzzyNumber(0,0,0);		
		
		for(int i=0;i<m;i++) 
		{
			tasklist[i] = new FTask(job.getOp()[i], null, FO.Addition(tlength, new FuzzyNumber(earlieststart)), null,jobid,i);
			tlength=FO.Addition(tlength, job.getOp()[i]);			
			if(i==0)
			{
				tasklist[i].setPriority1(tasklist[i].getEarliest());//��������ܿ�ʼʱ��Ϊ���ȼ�
				tasklist[i].setTaskstate(TaskState.READY2PLAN);//��һ��������ready״̬
			}
			else
			{
				tasklist[i].setPriority1(null);
				tasklist[i].setTaskstate(TaskState.UNREADY);
			}
		}
		deadline = FO.Addition(FO.Multipy(tlength, df), earlieststart);
		fakeddeadline = null;
		this.df = df;
		if(fdf==C.JD1) //deadline����
		{
			fakeddeadline = deadline.Clone();
		}
		else if(fdf==C.JD3)
		{
			fakeddeadline = new FuzzyNumber(deadline.getHighValue());
		}
		else if(fdf==C.JD2) //
		{
			fakeddeadline = new FuzzyNumber(deadline.getMostValue());
		}
		if(loose)
		for(int i=m-1;i>=0;i--)
		{
			if(i==m-1)
			{
				
				tasklist[i].setLatest(FO.Subtraction(fakeddeadline, job.getOp()[i])) ;
				tasklist[i].setPriority2(tasklist[i].getLatest());
//				System.out.println(fakeddeadline.toString()+"-("+job.getOp()[i].toString()+"+"+job.getLatency()[i].toString()+")");
			}
			else {
				tasklist[i].setLatest(FO.Subtraction(tasklist[i+1].getLatest(), job.getOp()[i]));
				tasklist[i].setPriority2(tasklist[i].getLatest());
			}
		}
		else
		{
			FuzzyNumber sum = new FuzzyNumber(0);
			for(int i=m-1;i>=0;i--)
			{				
				    FuzzyNumber latest = FO.Subtraction(fakeddeadline, FO.Addition(job.getOp()[i], sum));
				    
					tasklist[i].setLatest(FO.Max(latest,tasklist[i].getEarliest()));//��������»����latest<earlist�����
					tasklist[i].setPriority2(tasklist[i].getLatest());
					sum = FO.Addition(sum, FO.Multipy(job.getOp()[i], df));		
			}			
		}
//		if(jobid==264)
//		{
//			System.out.println("task arrive at "+arriveTime+" jobdeadline="+fakeddeadline.toString());
//			for(int i=0;i<m;i++)
//			{
//				System.out.println("stage "+i+":"+tasklist[i].toString());
//			}
//		}
	
	}	
	
	
	

	
	
//	private double getDF()//���������������
//	{
//		double realArea = this.tlength.getLowValue()+(tlength.getMostValue()-tlength.getLowValue())*0.25+(tlength.getHighValue()+tlength.getMostValue()-2*tlength.getLowValue())*0.25;
//		double totalArea = this.fakedeadline.getLowValue()-this.arriveTime+(fakedeadline.getMostValue()-fakedeadline.getLowValue())*0.25+(fakedeadline.getHighValue()+fakedeadline.getMostValue()-2*fakedeadline.getLowValue())*0.25;
//		return totalArea/realArea;
//	}
	

	
	public void print()
	{
		System.out.println("JOBID="+jobid+" ");
		for(int i=0;i<m;i++)
		{
			System.out.println("op["+i+"]="+tasklist[i].getLength().toString()+" state="+tasklist[i].getTaskstate());
		}
//		for(int i=0;i<m;i++)
//		{
//			System.out.println("delay["+i+"]="+tasklist[i].getDelay().toString());
//		}
		for(int i=0;i<m;i++)
		{
			System.out.println("earliest["+i+"]="+tasklist[i].getEarliest().toString());
		}
		for(int i=0;i<m;i++)
		{
			System.out.println("latest["+i+"]="+tasklist[i].getLatest().toString());
		}
		
		for(int i=0;i<m;i++)
		{
			System.out.println("priority1["+i+"]="+tasklist[i].getPriority1().toString());
			System.out.println("priority2["+i+"]="+tasklist[i].getPriority2().toString());
		}
		
		System.out.println();
		System.out.println("deadline="+deadline.toString()+"  df="+df+ " arrTime="+this.arriveTime);
		System.out.println("fakedeadline="+fakeddeadline.toString());
		

	}
	
	
	
	public void print(JobRealInfo monitor)
	{
		for(int i=0;i<m;i++)
		{
			System.out.print("op["+i+"]="+tasklist[i].getLength().toString());
			monitor.printRealOP(jobid, i);
		}
		
//		for(int i=0;i<m;i++)
//		{
//			System.out.print(" latency["+i+"]="+tasklist[i].getDelay().toString());
//			
//			monitor.printRealDelay(jobid, i);
//		}
		System.out.print(","+df+","+this.arriveTime);
		System.out.println();
		if(deadline!=null)
		System.out.println("deadline="+deadline.toString()+"  df="+df+ " arrTime="+this.arriveTime);
	}
	
	

	public int getM() {
		return m;
	}

	public FTask getTask(int stage) {
		return tasklist[stage];
	}

	public FAssignment getAssignment(int stage)
	{
		return aslist[stage];
	}

//	public FuzzyNumber[] getEarliestStart() {
//		return earliestStart;
//	}
//	
	
	public static void main(String[] args)
	{
		FuzzyNumber[] op = new FuzzyNumber[3];
		op[0] = new FuzzyNumber(4839,5806,5759);
		op[1] = new FuzzyNumber(4054,4864,4666);
		op[2] = new FuzzyNumber(4251,5101,4739);
		FuzzyNumber[] delay = new FuzzyNumber[3];
		delay[0] = new FuzzyNumber(235,282,260);
		delay[1] = new FuzzyNumber(236,283,265);
		delay[2] = new FuzzyNumber(235,282,242);
		FJobAssignment fjas = new FJobAssignment(0,3, op,delay,0,2,C.JD1,false);
		fjas.print();
	}
	
	
}
