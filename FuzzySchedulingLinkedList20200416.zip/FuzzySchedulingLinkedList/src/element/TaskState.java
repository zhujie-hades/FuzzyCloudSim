package element;

public class TaskState {//������Heap����fuzzy scheduleʹ��
	public static final int UNREADY = -1;
	public static final int READY2PLAN = 0;
	public static final int PLANNED = 1;
//	public static final int RUNNING = 2;
//	public static final int DONE = 3;
}
