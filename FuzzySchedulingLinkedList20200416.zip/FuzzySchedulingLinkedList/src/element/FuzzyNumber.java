package element;

import java.util.Random;
import java.util.Scanner;

public class FuzzyNumber {
	int lowValue;
	int highValue;
	int mostValue;
//	int realValue;
	public int getLowValue() {
		return lowValue;
	}
	public void setLowValue(int lowValue) {
		this.lowValue = lowValue;
	}
	public int getHighValue() {
		return highValue;
	}
	public void setHighValue(int highValue) {
	
		this.highValue = highValue;
		
	}
	public int getMostValue() {
		return mostValue;
	}
	public void setMaxValueIni() {
		 Random r = new Random();
		int p =r.nextInt(100) ;
 	   @SuppressWarnings("resource")
	Scanner scanner=new Scanner(System.in);
 	   System.out.println("��������ʣ�");
 	   int cp=scanner.nextInt();
		   if(p<=cp) this.mostValue=(lowValue+highValue)/2;
		   else {
			   int maxValue=r.nextInt(100);
			   if(maxValue>=this.lowValue&&maxValue<=this.highValue)
				   this.mostValue=maxValue;
		   }
	}
	public void setMostValue(int maxValue) {
		this.mostValue = maxValue;
	}

//	public int getRealValue() {
//		return realValue;
//	}
//	public void setRealValue(int realValue) {
//		this.realValue = realValue;
//	}

	public FuzzyNumber(int lowValue,int highValue,int mostValue){
		this.lowValue=lowValue;
		this.highValue=highValue;
		this.mostValue=mostValue;		
	}
	
	public FuzzyNumber(int value)
	{
		this.lowValue = value;
		this.highValue = value;
		this.mostValue = value;
	}
	
	public FuzzyNumber Clone()
	{
		FuzzyNumber clone = new FuzzyNumber(this.lowValue,this.highValue,this.mostValue);
		return clone;
	}
	
	
	
	
	public String toString()
	{
		
		String str = "<"+this.lowValue+","+this.mostValue+","+this.highValue+">";
		return str;
	}
	
	public void print()
	{
		System.out.print("<"+this.lowValue+","+this.mostValue+","+this.highValue+">");
	}

}
