package element;
import java.io.IOException;

import javax.imageio.ImageIO;

public class C {
	public static final FuzzyNumber Infinity =new FuzzyNumber(20000000,20000000,20000000);
	public static final FuzzyNumber TimeZero =new FuzzyNumber(0,0,0);
	public static final FuzzyNumber BelowZero =new FuzzyNumber(-1,-1,-1);
	public static final int LESS = -1;
	public static final int MORE = 1;
	public static final int EQUARE = 0;
	
	public static final double JD1 = 0;
	public static final double JD2 = -2;
	public static final double JD3 = -1;
	
	public static final boolean JCS1 = true;
	public static final boolean JCS2 = false;
	
	public static final int METRIC_COST = 2;
	public static final int METRIC_ACOST = 3;
	
//	public static final int PEST = 0;
//	public static final int FEST = 1;
	public static final int TP1 = 0;//PEST+Task deadline
	public static final int TP2 = 1;//FEST+Task deadline
	public static final int TP3 = 2;//urgency
	
	public static final int Price_R = 1;
	public static final int Price_On = 4;
	
	public static final double SD_MIN = 0.95;
	
	public static int LASTTIME = 120000;
	
	public static int EVENTINTERVAL = 1000;
	public static int Charge_Time_Unit = 1000;
	
	public static final int LS_NONE = 0;//��һ��
	public static final int LS_GREEDY_One = 2;//̰��
	public static final int LS_GREEDY_Switch = 3;//̰��
	public static final int LS_GREEDY_SwitchALL = 4;//̰��
	public static final int LS_VND = 1;//������
	public static final int LS_SA = 5;//ģ���˻�
	
	public static final String ImagePath = "D:\\��������\\Experiment Results\\Fuzzy\\Experiment Results LinkedList\\testImage";

	public static final int InDirectSwitchNeighbor = 2;	
	public static final int DirectSwitchNeighbor = 1;
	public static final int SwitchNeighbor = 0;
	public static final int OneInsertionNeighbor = 3;	
//	public static int LSTmax = 1000;	
//	public static int nonLSTmax = 200;

}
