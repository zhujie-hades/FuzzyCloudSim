package element;

import Jobs.FJOB;
import Tools.FO;

public class Area {
//	FuzzyNumber deline;
//	FuzzyNumber tle;
//	double kd;
//	double kt;
//	public FuzzyNumber getDeline() {
//		return deline;
//	}
//	public FuzzyNumber getTle() {
//		return tle;
//	}

	public static double FunctionDeline(FuzzyNumber deadline,int x){
		double kd=1.0/(deadline.getMostValue()-deadline.getHighValue());
		double y=kd*(x-deadline.getMostValue())+deadline.getHighValue();
		return y;
	}
	public static double FunctionTlength1(FuzzyNumber endtime,int x){
		double k=1.0/(endtime.getMostValue()-endtime.getLowValue());
		double y=k*(x-endtime.getMostValue())+endtime.getLowValue();
		return y;
	}
	public static double FunctionTlength2(FuzzyNumber endtime,int x){
		double kt=1.0/(endtime.getMostValue()-endtime.getHighValue());
		double y=kt*(x-endtime.getMostValue())+endtime.getHighValue();
		return y;
	}
	public static double Calculate(double high,int min,int max){
		double a=high*(max-min)/2.0;
		return a;
	}
//	public double Function(int x1,int y1,int x2,int y2,int x){
//		double y=(y2-y1)/(x2-x1)*(x-x1)+y1;
//		return y;
//	}
//	public double Point()
	
	public static double getArea(FuzzyNumber deadline,FuzzyNumber endtime){
		double area = 0;
		//���Ϊ0�����ཻ
		if(deadline.getHighValue()<endtime.getLowValue()) return 0;
		//��б�ʷ���
		else{
			double kd=1.0/(deadline.getMostValue()-deadline.getHighValue());
			double kt=1.0/(endtime.getMostValue()-endtime.getHighValue());
			if(kd==kt) area=Area.getArea1(endtime,deadline);
			if(kd<kt)  area=Area.getArea2(endtime,deadline,kd,kt);//kd<kt�飨ע��kd��ktΪ������
			if(kd>kt)  area=Area.getArea3(endtime,deadline,kd,kt);//kd>kt�飨ע��kd��ktΪ������
			return area;
		}
	}
	//б�������
	 public	static double getArea1(FuzzyNumber endtime,FuzzyNumber deadline){
		 double area,high=0;
		 //ȫ����
		 if(endtime.getMostValue()<=deadline.getMostValue())
			area=1.0*(endtime.getHighValue()-endtime.getLowValue())/2.0;
		 //�ཻ
		 else {
			 for(int i=deadline.getMostValue();i<deadline.getHighValue();i++){
				 for(int j=endtime.getLowValue();j<endtime.getMostValue();j++){
					 double yd=FunctionDeline(deadline, i);
					 double yt=FunctionTlength1(endtime, j);
					 if(yd==yt) high=yd;	
				 	}
				}
			 area=Calculate(high, endtime.getLowValue(), deadline.getHighValue());
			}
		 return area; 
	 }
	 //kd<kt�飨ע��kd��ktΪ������
	 public static double getArea2(FuzzyNumber endtime,FuzzyNumber deadline, double kd,double kt){
		 double area,high=0;
		 //ȫ����
		 if(endtime.getHighValue()<=deadline.getHighValue())
		 	 area=Calculate(1.0, endtime.getLowValue(), endtime.getHighValue());
		 else{
			 //���ҽ���
			 if(endtime.getMostValue()<=deadline.getMostValue()){
				 for(int i=deadline.getMostValue();i<deadline.getHighValue();i++){
					 for(int j=endtime.getMostValue();j<endtime.getHighValue();j++){
						 double yd=FunctionDeline(deadline, i);
						 double yt=FunctionTlength2(endtime, j);
						 if(yd==yt) high=yd;	
					 		}
				 		}
				 area=Calculate(1.0, endtime.getLowValue(), endtime.getHighValue())-Calculate(high, deadline.getHighValue(), endtime.getHighValue());
			 }
			//���󽻲�
			 else{
				 for(int i=deadline.getMostValue();i<deadline.getHighValue();i++){
					 for(int j=endtime.getLowValue();j<endtime.getMostValue();j++){
						double yd=FunctionDeline(deadline, i);
						double yt=FunctionTlength1(endtime, j);
						if(yd==yt) high=yd;	
				            }
					     }
				 area=Calculate(high, endtime.getLowValue(), deadline.getHighValue());
				  }
		 }
			 return area;
	 }
	 //kd>kt�飨ע��kd��ktΪ������
	 public	static double getArea3(FuzzyNumber endtime,FuzzyNumber deadline, double kd,double kt){
		 double area,high1=0,high2=0;
		//ȫ����
		 if(endtime.getMostValue()<=deadline.getMostValue())
		 	 area=Calculate(1.0, endtime.getLowValue(), endtime.getHighValue());
		 else{
			 //���󽻲�+���ҽ���
			 if(endtime.getHighValue()<=deadline.getHighValue()){
				 for(int i=deadline.getMostValue();i<deadline.getHighValue();i++){
					 for(int j=endtime.getLowValue();j<endtime.getMostValue();j++){
						 double yd1=FunctionDeline(deadline, i);
						 double yt1=FunctionTlength1(endtime, j);
						 if(yd1==yt1) high1=yd1;
					 }
				 }
				 for(int m=deadline.getMostValue();m<deadline.getHighValue();m++){
					 for(int n=endtime.getMostValue();n<endtime.getHighValue();n++){
						 double yd2=FunctionDeline(deadline, m);
						 double yt2=FunctionTlength2(endtime, n);
						 if(yd2==yt2) high2=yd2;	
					 }
				 }
				area=Calculate(high1, endtime.getLowValue(), deadline.getHighValue())-Calculate(high2, endtime.getHighValue(), deadline.getHighValue());
			 }
			 //�����󽻲�
			 else{
				 for(int i=deadline.getMostValue();i<deadline.getHighValue();i++){
					 for(int j=endtime.getLowValue();j<endtime.getMostValue();j++){
						double yd=Area.FunctionDeline(deadline, i);
						double yt=Area.FunctionTlength1(endtime, j);
						if(yd==yt) high1=yd;	
				            }
					     }
				 area=Calculate(high1, endtime.getLowValue(), deadline.getHighValue());
			 }
		 }
		 return area;
	 }
	
}