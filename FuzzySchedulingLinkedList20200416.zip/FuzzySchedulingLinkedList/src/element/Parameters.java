package element;


public class Parameters {

	

	
	double wp;
	boolean JCSflag;//true = JSC1, false = JSC2
	int LS;//true = hasVND, false = noVND;
	boolean looseDeadline;//true=loose;false=tight;
	int TMStrategy;//TP1=PEST;TP2=FEST;TP3=deadline-(FEST+LENGTH)
	boolean twoTree;
	double JD = 0; //=0 <low,most,high> JD1; =-1 <high,high,high> JD3; =-2 <most,most,most> JD2
	
	public String toString()
	{
		return this.getTMStrategyString()+"\t"+this.LocalSearchString()+"\t"+this.JCSflagString()+"\t"+this.getJDString()+"\t"+this.isLooseDeadlineString();
	}
	
	public String LocalSearchString() {
		if(LS==C.LS_NONE) return "LS_NONE";
		else if(LS==C.LS_GREEDY_One) return "LS_GLS1";
		else if(LS==C.LS_GREEDY_Switch) return "LS_GLSS";
		else if(LS==C.LS_GREEDY_SwitchALL) return "LS_GLSSALL";
		else if(LS==C.LS_VND) return "LS_VND";
		else if(LS==C.LS_SA) return "LS_SA";
		return "";
	}

	public int getTMStrategy() {
		return TMStrategy;
	}
	
	public String getTMStrategyString() {
//		if(TMStrategy==0) return "PEST";
//		else if(TMStrategy==1) return "FEST";
		if(TMStrategy==0) return "TP1";
		else if(TMStrategy==1) return "TP2";
		else if(TMStrategy==2) return "TP3";
		return "";
	}

	public void setTMStrategy(int tMStrategy) {
		TMStrategy = tMStrategy;
	}

	public boolean isLooseDeadline() {
		return looseDeadline;
	}
	
	public String isLooseDeadlineString() {
		if(looseDeadline) return "LooseDeadline";
		return "TightDeadline";
	}

	public void setLooseDeadline(boolean looseDeadline) {
		this.looseDeadline = looseDeadline;
	}
	int metric;//=1 NONE;=2 COST;=3 E ACOST
	public int getInnerMetric() {
		return metric;
	}
	
	public String getInnerMetricString() {
//		if(metric==1) return "VMnum";
//		else 
			if(metric==2) return "COST";
		else if(metric==3) return "ACOST";
		return "ELSE";
	}

	public void setInnerMetric(int metric) {
		this.metric = metric;
	}
	
	



//	public Parameters Clone()
//	{
//		Parameters p = new Parameters();
//		p.setTmax(Tmax);
//		p.setW(w);
//		p.setJSCflag(JSCflag);
//		p.setVNDflag(VNDflag);
//		p.setT(t);
//		p.setTimeunit(timeunit);
//		p.setEventObject(eventObject);
//		p.setTwoTree(twoTree);
//		p.setFdf(fdf);
//		return p;
//	}
	
	public double getJD() {
		return JD;
	}
	
	public String getJDString() {//=0 <low,most,high> JD1; =-1 <high,high,high> JD3; =-2 <most,most,most> JD2
		if(JD==0) return "JD1";
		else if(JD==-1) return "JD3";
		else if(JD==-2) return "JD2";
		
		return "ELSE";
	}


	public void setJD(double jD) {
		JD = jD;
	}

	public boolean isTwoTree() {
		return twoTree;
	}
	public void setTwoTree(boolean twoTree) {
		this.twoTree = twoTree;
	}
	

//	public int getTmax() {
//		return Tmax;
//	}
	
//	public void setTmax(int tmax) {
//		Tmax = tmax;
//	}
	public double getWP() {
		return wp;
	}
	public void setWP(double wp) {
		this.wp = wp;
	}
	public boolean JSCflag() {
		return JCSflag;
	}
	
	public String JCSflagString() {
		if(JCSflag) return "JCS1";
		return "JCS2";
	}
	public void setJCSflag(boolean JCSflag) {
		this.JCSflag = JCSflag;
	}
	public int LSMethod() {
		return LS;
	}

	public void setLS(int lS) {
		LS = lS;
	}
	

	

	
}
