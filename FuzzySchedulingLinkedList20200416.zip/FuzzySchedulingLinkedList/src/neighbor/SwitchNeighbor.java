package neighbor;

import java.util.ArrayList;

public class SwitchNeighbor {//����������λ��
	
	int i;
	int j;
	int n;//���г���
	int totalnum;
	
	public SwitchNeighbor(int length)
	{
		this.n = length;
		i = 0;
		j = i+1;
		totalnum = n*(n-1)/2;
	}
	
	
	public int getTotalnum() {
		return totalnum;
	}


	public void initial()
	{
		i = 0; j = i+1;
	}
	
	public int[] getNeighbor()
	{
		int[] neighbor = new int[n];
		if(i==n-1) return null;
		for(int k=0;k<i;k++)
		{
			neighbor[k]=k;
		}
		neighbor[i]=j;
		
		for(int k=i+1;k<j;k++) neighbor[k]=k;
		neighbor[j]=i;
		for(int k=j+1;k<n;k++) neighbor[k]=k;
		j++;
		if(j==n) {i++;j=i+1;}
		return neighbor;
	}
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwitchNeighbor sn = new SwitchNeighbor(5);
		for(int i=0;i<sn.getTotalnum();i++)
		{
			System.out.println(sn.getNeighbor().toString());
		}
		System.out.println(sn.getNeighbor().toString()+"***********");
	}

}
