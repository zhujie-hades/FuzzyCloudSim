package neighbor;

import java.util.ArrayList;
import java.util.HashMap;

import element.C;

public class LocalSearchNeighbors {

	InDirectSwitchNeighbor idn; //k=2
	DirectSwitchNeighbor dn; //k=1
	SwitchNeighbor sn; //k=0
	
	public LocalSearchNeighbors(int n)
	{
		idn = new InDirectSwitchNeighbor(n);
		dn = new DirectSwitchNeighbor(n);
		sn = new SwitchNeighbor(n);
	}
	
	public void initial()
	{
		idn.initial();
		dn.initial();
		sn.initial();
	}
	
	public int getNumber(int k)
	{
		if(k==C.DirectSwitchNeighbor) return dn.getTotalnum();
		if(k==C.SwitchNeighbor) return sn.getTotalnum();
		return idn.getTotalnum();
	}
	
	public int[] getNeighbor(int k)
	{
		if(k==C.DirectSwitchNeighbor) return dn.getNeighbor();
		if(k==C.SwitchNeighbor) return sn.getNeighbor();
		return idn.getNeighbor();
	}

	public static void main(String[] args) {
		LocalSearchNeighbors lsn = new LocalSearchNeighbors(5);
		int number = lsn.getNumber(C.InDirectSwitchNeighbor);
		for(int i=0;i<number;i++)
		{
			System.out.println(lsn.getNeighbor(C.InDirectSwitchNeighbor));
		}
		
	}

}
