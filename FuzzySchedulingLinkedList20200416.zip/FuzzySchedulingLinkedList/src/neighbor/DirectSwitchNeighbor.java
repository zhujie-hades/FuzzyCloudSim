package neighbor;

import java.util.ArrayList;

public class DirectSwitchNeighbor {//��������λ��
	
	int i;
	int n;//���г���
	int totalnum;
	
	public DirectSwitchNeighbor(int length)
	{
		this.n = length;
		i = 0;		
		totalnum = n-1;
	}
	
	
	public int getTotalnum() {
		return totalnum;
	}


	public void initial()
	{
		
		i = 0;
	}
	
	public int[] getNeighbor()
	{
		int[] neighbor = new int[n];
		if(i==n-1) return null;
		for(int k=0;k<i;k++)
		{
			neighbor[k] = k;
			
		}
		neighbor[i] = i+1;
		neighbor[i+1] = i;
		for(int k=i+2;k<n;k++) neighbor[k]=k;		
		i++;
		return neighbor;
	}
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DirectSwitchNeighbor sn = new DirectSwitchNeighbor(15);
		for(int i=0;i<sn.getTotalnum();i++)
		{
			int[] neighbor = sn.getNeighbor();
			for(int j=0;j<neighbor.length;j++)
				System.out.print(neighbor[j]+" ");
			System.out.println();
		}
		System.out.println(sn.getNeighbor().toString()+"***********");
	}

}
