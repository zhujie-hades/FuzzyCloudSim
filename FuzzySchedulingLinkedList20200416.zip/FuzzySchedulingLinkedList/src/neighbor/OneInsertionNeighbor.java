package neighbor;

public class OneInsertionNeighbor {
	
	int pick;
	int location;
	int n;//���г���
	
	public OneInsertionNeighbor(int length)
	{
		this.n = length;
	}
	
	public void initilization(){pick = 0;}
}
