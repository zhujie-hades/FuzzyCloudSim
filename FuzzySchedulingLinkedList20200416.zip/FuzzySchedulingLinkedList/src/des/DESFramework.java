package des;

import java.awt.Color;
import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.HashMap;

import Experiments.InstanceGenerator;
import Experiments.OnPremiseSetting;
import Jobs.Event;
import Jobs.FJOBS;
import Jobs.JobRealInfo;
import ResourceManagement.AvailabilityUpdator;
import ResourceManagement.VirtualClusterList;
import ResourceManagement.VirtualMachine;
import SchedulePlan.Schedule;
import SchedulePlan.ScheduleMonitor;
import Tools.CO;
import Tools.ValidationCheckingTool;
import element.C;
import element.Parameters;
import neighbor.LocalSearchNeighbors;
import visual.ShowDESResult_Fuzzy;

public class DESFramework {
	
	Parameters setting;
	ArrayList<ArrayList<Integer>> jobArriveOrder;
	ArrayList<Integer> jobArriveTime;
	int pointNum;
	Schedule schedule;
	int[] oldm;
	int m;
	int n;
	JobRealInfo realinfo;
	ScheduleMonitor schedulemontior;
	public DESFramework(ArrayList<ArrayList<Integer>> jobArriveOrder,ArrayList<Integer> jobArriveTime,Schedule schedule,int m,int n, int[] old,Parameters setting,JobRealInfo realinfo)
	{
		this.jobArriveOrder = jobArriveOrder;
		this.jobArriveTime = jobArriveTime;
		this.schedule = schedule;
		pointNum = jobArriveTime.size();
		this.oldm = old;
		this.m = m;
		this.n = n;
		this.setting = setting;
		this.realinfo = realinfo;
		schedulemontior = new ScheduleMonitor(n,m,realinfo);
	}
	
	private Event getEvent(int index)
	{
		ArrayList<Integer> joblist = (ArrayList<Integer>)jobArriveOrder.get(index).clone();
		Event event = new Event(this.jobArriveTime.get(index),joblist.size(),m,joblist,schedule);
		return event;
	}
	
	public VirtualClusterList run(HashMap<Integer,Color> cmap,boolean issave)
	{
		VirtualClusterList vclist = new VirtualClusterList(m,oldm,setting);
		LocalSearchNeighbors lsn = null;
		
		Event event = this.getEvent(0);
		lsn = new LocalSearchNeighbors(event.getJobnum());
		SMS sms = new SMS(setting, event, vclist,schedule);			
		sms.run(lsn,0);
		
//		vclist.updateEmptySlotHead(event.getArriveTime());
		
		int count = event.getJobnum();
		
			ShowDESResult_Fuzzy frame1 = null;
			if(cmap!=null)
			{
			try {
				frame1 = new ShowDESResult_Fuzzy(vclist,schedule,m,count,jobArriveOrder,jobArriveTime);				
				frame1.draw(1,cmap,false);			
				frame1.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
		int i = 1;
		while(true)
		{
		
			if(i<pointNum)
			event = this.getEvent(i);
			else event  = new Event(i*C.EVENTINTERVAL,0,m,new ArrayList<Integer>(),schedule);
			if(i%100==0)
			System.out.println("-------------------------------------------------------------------------------"+event.getArriveTime());
			
			count+=event.getJobnum();
			
			if(frame1!=null)
			frame1.setN(count);
			
			if(i>=pointNum)
			{
				//�����ͼû�н���������
				if(schedulemontior.isDone(vclist)) break;
			}
			schedulemontior.updateAtTime(event.getArriveTime(), schedule, vclist);	
			
//			vclist.updateEmptySlotHead(event.getArriveTime());


//			AvailabilityUpdator.update(vclist, schedule, m, event.getArriveTime());
			
			if(setting.JSCflag()==C.JCS2)
			{
				int oldnum = event.getJobnum();
				JSC2 jsc2 = new JSC2(setting,event,vclist);	
				
//				System.out.println("-1checkinggggggggggggggggggggg");
//				vclist.CheckingLinkedList();
				jsc2.collect(schedule);
//				System.out.println("Collect "+(event.getJobnum()-oldnum)+" &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");

//				System.out.println("0checkinggggggggggggggggggggg");
//				vclist.CheckingLinkedList();
//				vclist.updateEmptySlotHead(event.getArriveTime());
				
//				vclist.print();
			}
//			vclist.Order();
			sms = new SMS(setting, event, vclist,schedule);	
			
//		    System.out.print("("+i+"-");
//		    long start = System.currentTimeMillis();
			lsn = new LocalSearchNeighbors(event.getJobnum());
			sms.run(lsn,event.getArriveTime());
//			long end = System.currentTimeMillis();
//			System.out.print((end-start)+")");
			
			
			
//			if(cmap!=null)
//			{
////				long duration = System.currentTimeMillis();
////				if(duration<1000)
////				{
//					try {
//						Thread.sleep(100);
//					} catch (InterruptedException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
////				}
//			}
			
//			vclist = sms.getVclist();	
			
			if(cmap!=null)
			{
//				vclist.print();
				frame1.setVclist(vclist);			
				frame1.draw(i+1,cmap,false);
			}
			
			
//			schedulemontior.MonitorAfterScheduling(event,schedule);//
			i++;
		}			
				
//		System.out.print("Done1");	
		ValidationCheckingTool.VMChecking(vclist);
		ValidationCheckingTool.JobChecking(vclist, schedule, realinfo);
//		vclist.print();
		
//		this.schedulemontior.updateFrom(pointNum*C.EVENTINTERVAL,schedule, vclist);
		if(cmap!=null)
		{
			frame1.setVclist(vclist);
			frame1.draw(this.pointNum,cmap,issave);
			if(issave==true) frame1.dispose();
		}
//		System.out.print("Done2 time="+(System.currentTimeMillis()-start)/1000+"second  ");	
//		vclist.TrimTrees(0);
//		vclist.print();
//		ValidationCheckingTool.JobChecking(vclist, jobs, monitor);
//		ValidationCheckingTool.VMChecking(vclist);
		System.out.println("LAST Checkingggggggggggggggggggggggggggg");
		ValidationCheckingTool.VMChecking(vclist);
		ValidationCheckingTool.JobChecking(vclist, schedule, realinfo);
		return vclist;
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		int anumlambda = 5;
//		double dflambda = 1.5;
//		int m = 3;
//		int onpremise = OnPremiseSetting.getOi(anumlambda, m, dflambda);
//		ArrayList<ArrayList<Integer>> arriveSets = new ArrayList<ArrayList<Integer>>();
//		ArrayList<Integer> arriveTimeList = new ArrayList<Integer>();
//		JobProcessingMonitor monitor = new JobProcessingMonitor(m);
//		int i = 3;
//		String instanceid = m+"_"+i+"_10_100";
//		String location = "D:\\��������\\Dynamic_Instances_Fuzzy";
//		int lastpoint = 6000;
//		int T = 10;
//		int Tmax = 3;
//		int timeunit = 100;//ms
//		int H = lastpoint/T;
//		double dev = 0.2;
//		FJOBS jobs = InstanceGenerator.getPiossonInstance(location,instanceid,dev,m,H, anumlambda, dflambda, lastpoint, arriveSets, arriveTimeList,monitor);
//		int[] old = new int[m];
//		for(int s=0;s<m;s++)
//			old[s] = onpremise;
//		int n=jobs.getN();
//		Parameters setting1 = new Parameters();
//		setting1.setJSCflag(false);
//		setting1.setT(T);
//		setting1.setTmax(Tmax);
//		setting1.setTMflag(false);
//		setting1.setVNDflag(true);
//		setting1.setW(anumlambda/2);
//		setting1.setTimeunit(timeunit);
//		
////		Parameters setting2 = new Parameters();
////		setting2.setJSCflag(false);
////		setting2.setT(T);
////		setting2.setTmax(Tmax);
////		setting2.setTMflag(false);
////		setting2.setVNDflag(false);
////		setting2.setW(anumlambda/2);
////		setting2.setTimeunit(timeunit);
//		
//		
//		DESFramework des1 = new DESFramework(arriveSets, arriveTimeList,jobs,m,n, old,setting1,monitor);
//		VirtualClusterList vclist1 = des1.run();		
//		System.out.println("Objective1="+vclist1.getNewMachineNum());	
////		
////		DESFramework des2 = new DESFramework(arriveSets, arriveTimeList,jobs,m,n, old,setting2);
////		VirtualClusterList vclist2 = des2.run();		
////		System.out.println("Objective2="+vclist2.getNewMachineNum());	
////		
//		EventQueue.invokeLater(new Runnable() {
//		public void run() {
//			try {
//				ShowDESResult_Fuzzy frame1 = new ShowDESResult_Fuzzy(jobs,vclist1,m,n,arriveSets,arriveTimeList);				
//				frame1.draw();
//				frame1.setTitle("noVND");
//				frame1.setVisible(true);
////				ShowDESResult frame2 = new ShowDESResult(jobs,vclist2,m,n,arriveSets,arriveTimeList);				
////				frame2.draw();
////				frame2.setTitle("VND");
////				frame2.setVisible(true);
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//		}
//	});
	}

}
