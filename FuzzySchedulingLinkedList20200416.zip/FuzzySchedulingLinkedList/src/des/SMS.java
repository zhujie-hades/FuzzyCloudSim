package des;

import java.util.ArrayList;
import java.util.HashMap;

import Jobs.Event;
import ResourceManagement.ChargingOnOnDemand;
import ResourceManagement.EmptySlotLinkedlist;
import ResourceManagement.VirtualClusterList;
import SchedulePlan.NewObjectives;
import SchedulePlan.Schedule;
import SchedulePlan.biObject;
import Tools.CO;
import element.C;
import element.Parameters;
import neighbor.LocalSearchNeighbors;

public class SMS {

	Parameters setting;
	Event event;
	VirtualClusterList vclist;
	Schedule schedule;
	public ArrayList<Integer> getBestseq() {
		return bestseq;
	}

	public void setVclist(VirtualClusterList vclist) {
		this.vclist = vclist;
	}

	ArrayList<Integer> bestseq;
	public SMS(Parameters setting, Event event, VirtualClusterList vclist,Schedule schedule)
	{
		this.setting = setting;
		this.event = event;
		this.vclist = vclist;
		this.schedule = schedule;
	}
	
	public void setSchedule(Schedule schedule) {
		this.schedule = schedule;
	}

	public void run(LocalSearchNeighbors lsn,int curTime)
	{
//		if(event.getJobnum()==0)
//		{
//			System.out.println("zero");
//			 return;
//		}
		CO.orderJobsByDeadline(event);
		
		ArrayList<Integer> initialSeq = event.getJoblist();
		if(setting.LSMethod()==C.LS_NONE)
		{
			TTM ttm = new TTM(initialSeq,event);
			ttm.run(this.setting,this.vclist,curTime,schedule);
			bestseq = initialSeq;
			
		}
		else if(setting.LSMethod()==C.LS_VND)
		{
//			System.out.println("SMS BEFORE Clone checkinggggggggggggggggggggg");
//			vclist.CheckingLinkedList();
			//Ҫ���Լ����Σ����Կ�����������������
			bestseq = initialSeq;
			EmptySlotLinkedlist emptylist = vclist.CloneEmptySlot(curTime); 
			HashMap<String,ChargingOnOnDemand> charingondemand = vclist.getChargingOnOnDemandInfor();
			TTM ttm = new TTM(bestseq,event);			
			biObject obj = new biObject();
			int totalOldVMNum = vclist.getTotalOldMachineNum();
			obj.compute(ttm.run(this.setting,emptylist.Clone(),curTime),event,totalOldVMNum,charingondemand);
//			EmptySlotLinkedlist temp = ttm.getLinkedlist();
//			double price = temp.computeprice(totalOldVMNum, curTime);
			LS_VND ls_vnd = new LS_VND(emptylist,obj,bestseq,setting,totalOldVMNum,charingondemand);			
			ls_vnd.run(event, lsn,curTime);		
			bestseq = ls_vnd.getBestseq();
			
			//����õ��������¼���һ��
			ttm = new TTM(bestseq,event);	
			ttm.run(this.setting,this.vclist,curTime,schedule);
			
//			vclist.CloneEmptySlot(curTime).printAll();
//			if(temp.isSameTest(vclist.CloneEmptySlot(curTime))==false)
//			{
//				System.out.println("ERROR: Emptylist is different VClist");
//				System.out.println("start-------------------------------------------------------------------");
//				temp.printAll();
//				System.out.println("======================================================================");
//				vclist.CloneEmptySlot(curTime).printAll();
//				System.out.println("end-------------------------------------------------------------------");
//			}
		}
		else if(setting.LSMethod()==C.LS_GREEDY_One)
		{

			//Ҫ���Լ����Σ����Կ�����������������
			bestseq = initialSeq;
			EmptySlotLinkedlist emptylist = vclist.CloneEmptySlot(curTime); 
			HashMap<String,ChargingOnOnDemand> charingondemand = vclist.getChargingOnOnDemandInfor();
			TTM ttm = new TTM(bestseq,event);			
			biObject obj = new biObject();
			int totalOldVMNum = vclist.getTotalOldMachineNum();
			obj.compute(ttm.run(this.setting,emptylist.Clone(),curTime),event,totalOldVMNum,charingondemand);
			LS_GreedyOne go = new LS_GreedyOne(emptylist,obj,bestseq,setting,totalOldVMNum,charingondemand);			
			go.run(event, lsn,curTime);		
			bestseq = go.getBestseq();
			
			//����õ��������¼���һ��
			ttm = new TTM(bestseq,event);	
			ttm.run(this.setting,this.vclist,curTime,schedule);

		
		}
		else if(setting.LSMethod()==C.LS_GREEDY_Switch)
		{
			//Ҫ���Լ����Σ����Կ�����������������
			bestseq = initialSeq;
			EmptySlotLinkedlist emptylist = vclist.CloneEmptySlot(curTime); 
			HashMap<String,ChargingOnOnDemand> charingondemand = vclist.getChargingOnOnDemandInfor();
			TTM ttm = new TTM(bestseq,event);			
			biObject obj = new biObject();
			int totalOldVMNum = vclist.getTotalOldMachineNum();
			obj.compute(ttm.run(this.setting,emptylist.Clone(),curTime),event,totalOldVMNum,charingondemand);
			LS_GreedySwitchALL gs = new LS_GreedySwitchALL(emptylist,obj,bestseq,setting,totalOldVMNum,charingondemand);			
			gs.run(event, lsn,curTime);		
			bestseq = gs.getBestseq();
			
			//����õ��������¼���һ��
			ttm = new TTM(bestseq,event);	
			ttm.run(this.setting,this.vclist,curTime,schedule);
		}
		else if(setting.LSMethod()==C.LS_GREEDY_SwitchALL)
		{
			//Ҫ���Լ����Σ����Կ�����������������
			bestseq = initialSeq;
			EmptySlotLinkedlist emptylist = vclist.CloneEmptySlot(curTime); 
			HashMap<String,ChargingOnOnDemand> charingondemand = vclist.getChargingOnOnDemandInfor();
			TTM ttm = new TTM(bestseq,event);			
			biObject obj = new biObject();
			int totalOldVMNum = vclist.getTotalOldMachineNum();
			obj.compute(ttm.run(this.setting,emptylist.Clone(),curTime),event,totalOldVMNum,charingondemand);
			LS_GreedySwitch gs = new LS_GreedySwitch(emptylist,obj,bestseq,setting,totalOldVMNum,charingondemand);			
			gs.run(event, lsn,curTime);		
			bestseq = gs.getBestseq();
			
			//����õ��������¼���һ��
			ttm = new TTM(bestseq,event);	
			ttm.run(this.setting,this.vclist,curTime,schedule);
		}
		else if(setting.LSMethod()==C.LS_SA)
		{
//			System.out.println("SMS BEFORE Clone checkinggggggggggggggggggggg");
//			vclist.CheckingLinkedList();
			//Ҫ���Լ����Σ����Կ�����������������
			bestseq = initialSeq;
			EmptySlotLinkedlist emptylist = vclist.CloneEmptySlot(curTime); 
			HashMap<String,ChargingOnOnDemand> charingondemand = vclist.getChargingOnOnDemandInfor();
			TTM ttm = new TTM(bestseq,event);			
			biObject obj = new biObject();
			int totalOldVMNum = vclist.getTotalOldMachineNum();
			obj.compute(ttm.run(this.setting,emptylist.Clone(),curTime),event,totalOldVMNum,charingondemand);
//			EmptySlotLinkedlist temp = ttm.getLinkedlist();
//			double price = temp.computeprice(totalOldVMNum, curTime);
			LS_SA ls_sa = new LS_SA(emptylist,obj,bestseq,setting,totalOldVMNum,charingondemand);			
			ls_sa.run(event, lsn,curTime);		
			bestseq = ls_sa.getBestseq();
			
			//����õ��������¼���һ��
			ttm = new TTM(bestseq,event);	
			ttm.run(this.setting,this.vclist,curTime,schedule);

		}
		
	}
	public VirtualClusterList getVclist() {
		return vclist;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
