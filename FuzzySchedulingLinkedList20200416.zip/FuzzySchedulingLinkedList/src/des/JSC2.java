package des;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeMap;

import Experiments.ParametersRange;
import Jobs.Event;
import Jobs.FJOB;
import Jobs.FJOBS;
import ResourceManagement.Slot;
import ResourceManagement.VirtualClusterList;
import SchedulePlan.FAssignment;
import SchedulePlan.Schedule;
import Tools.FO;
import element.C;
import element.FuzzyNumber;
import element.Parameters;


public class JSC2 {

	Parameters setting;
	Event event;
	VirtualClusterList vclist;
	public JSC2(Parameters setting, Event event,VirtualClusterList vclist)
	{
		this.setting = setting;
		this.event = event;
		this.vclist = vclist;
	}
	
	private void popSortdescending(ArrayList<Integer> list,HashMap<Integer,FuzzyNumber>endlist)
	{
		int size = list.size();
		for(int i=size-1;i>0;i--)
		{
			int job1 = list.get(i-1);
			int job2 = list.get(i);
			FuzzyNumber start1 = endlist.get(job1);
			FuzzyNumber start2 = endlist.get(job2);
			if(FO.Comparison(start1,start2)==-1) 
			{
				list.set(i-1, job2);
				list.set(i, job1);
			}
		}
	}
	
	private ArrayList<Integer> jobsOrderByTime(HashMap<Integer,FuzzyNumber> jobendlist)
	{
		ArrayList<Integer> result = new ArrayList<Integer>();
		Iterator<Integer> idit = jobendlist.keySet().iterator();
		while(idit.hasNext())
		{
			int jobid = idit.next();
			result.add(jobid);
			
		}	
		this.popSortdescending(result, jobendlist);
		return result;
	}
	
	
	
	private void printRolledAssignments(HashMap<Integer,TreeMap<Integer,FAssignment>> asmap)
	{
		Iterator<Integer> it = asmap.keySet().iterator();
		while(it.hasNext())
		{
			int jobid = it.next();
			System.out.print("rolled job "+jobid+":");
			TreeMap<Integer,FAssignment> rolledstage = asmap.get(jobid);
			Iterator<Integer> sit = rolledstage.keySet().iterator();
			while(sit.hasNext())
			{
				int stageid = sit.next();
//				FAssignment fas = rolledstage.get(stageid);
				System.out.print(" "+stageid);
			}
			System.out.println();
		}
	}
	
	public void collect(Schedule schedule)
	{
		ArrayList<Slot> slotlist = new ArrayList<Slot>();
		int realat = event.getArriveTime()+C.EVENTINTERVAL;
		if(setting.LSMethod()==C.LS_VND) 
		{
			
			double upperbound = setting.getWP()*event.getJobnum()*schedule.getM();//��������task
//			System.out.println("w="+setting.getWP()+" upperbound="+upperbound);
//			slotlist = vclist.collectAssignmentAfter(realat,(int)upperbound,schedule);
			slotlist = vclist.collectAssignmentAfter(realat,-1,schedule);

			
		}
		else 
			{
//			if(setting.getTMStrategyString().equalsIgnoreCase("FEST"))
//			{
////				System.out.println("HERE");
//				if(2500-event.getJobnum()*schedule.getM()>0)
//					slotlist = vclist.collectAssignmentAfter(realat,2500-event.getJobnum()*schedule.getM(),schedule);
//					else 
//					{
//						System.out.println("event�������������Ѿ��ɹۣ������������ص�������");
////						slotlist = vclist.collectAssignmentAfter(realat,0);//event�������������Ѿ��ɹۣ�����������
//					}
//			}
//			else 
				slotlist = vclist.collectAssignmentAfter(realat,-1,schedule);//-1 means no upperbound;
				
			}
		
//		for(int i=0;i<slotlist.size()-1;i++)
//		{
//			Slot first = slotlist.get(i);
//			Slot second = slotlist.get(i+1);
//			if(FO.Comparison(first.getEnd(), second.getEnd())==C.LESS)
//			{
//				System.out.println("slotlist is not ordered ERRRRRRRRRRRRRRRRRRRRRRRR");
//			}
//		}
		
		//�ȸ���schedule�����assignment
		schedule.rollbackAssignments(slotlist);	
		
//		System.out.println("job number before re ="+event.getJobnum());
		int size = slotlist.size();
		for(int i=0;i<size;i++)//Ҫ���µ��ȵ�job����event����
		{
			int jobid = slotlist.get(i).getJobid();			
			event.addJob(schedule.getJob(jobid), jobid);
		}
		
//		System.out.println("job number after re ="+event.getJobnum());

		
		//slotlistһ��Ҫ���rollback������slotlist�����slot�����ÿ���
		vclist.rollbackAssignments(slotlist,event.getArriveTime());		
		
		

	}
	

	
	
	
}
