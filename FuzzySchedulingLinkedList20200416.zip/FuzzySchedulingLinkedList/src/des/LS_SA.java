package des;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;

import Experiments.ParametersRange;
import Jobs.Event;
import ResourceManagement.ChargingOnOnDemand;
import ResourceManagement.EmptySlotLinkedlist;
import ResourceManagement.VirtualClusterList;
import SchedulePlan.biObject;
import Tools.CO;
import element.C;
import element.Parameters;
import neighbor.LocalSearchNeighbors;

public class LS_SA {

//	VirtualClusterList bestVClist;
//	double bestObj;
//	double bestMObj;
	Parameters setting;
	ArrayList<Integer> bestseq;
	EmptySlotLinkedlist emptylist;
	biObject bestobj;
	HashMap<String,ChargingOnOnDemand> charingondemand;
	int totalOldVMNum;
	double bestprice;
	int maxiteration = 20;
	
	public LS_SA(EmptySlotLinkedlist emptylist,biObject obj,ArrayList<Integer>bestseq, Parameters setting,int totalOld,HashMap<String,ChargingOnOnDemand> charingondemand)
	{
		
		this.setting = setting;
		this.bestseq = bestseq;
//		this.bestMObj =bestMObj;
		this.bestobj = obj;
		this.emptylist = emptylist;
	    this.charingondemand = charingondemand;
	    this.totalOldVMNum = totalOld;
	}
	
//	public VND(EmptySlotLinkedlist emptylist,double bestprice,ArrayList<Integer>bestseq, Parameters setting,int totalOld,HashMap<String,ChargingOnOnDemand> charingondemand)
//	{
//		
//		this.setting = setting;
//		this.bestseq = bestseq;
////		this.bestMObj =bestMObj;
//		this.bestprice = bestprice;
//		this.emptylist = emptylist;
//	    this.charingondemand = charingondemand;
//	    this.totalOldVMNum = totalOld;
//	}
	
	
	private boolean isaccept(biObject obj,int iteration)
	{
		boolean isaccept = false;
		
			double p = Math.exp((bestobj.getCost()-obj.getCost())/(bestobj.getCost()*(maxiteration-iteration)));
			Random r = new Random();
			if(r.nextFloat()<=p) isaccept = true;
		
		return isaccept;
	}
	
	
	public void run(Event event, LocalSearchNeighbors lsn,int curT)
	{
		if(event.getJobnum()==0) return;
		HashSet<Integer> exploredcode = new HashSet<Integer>();
		exploredcode.add(bestseq.toString().hashCode());
		boolean flag = true;
		long start = System.currentTimeMillis();
		int count = 0;
		double initialcost = bestobj.getCost();
		int iteration = 0;
		int neighborid = C.SwitchNeighbor;
		ArrayList<Integer> startneighbor = bestseq;
		while(flag)
		{	
			flag = false;
			int number = lsn.getNumber(neighborid);
			for(int i=0;i<number;i++)
			{
				if(System.currentTimeMillis()-start>=C.EVENTINTERVAL) break;
				ArrayList<Integer> neighbor = CO.GenNeighbor(startneighbor, lsn.getNeighbor(neighborid));
				TTM ttm = new TTM(neighbor,event);			
				biObject obj = new biObject();
				count++;
				obj.compute(ttm.run(this.setting,emptylist.Clone(),curT),event,this.totalOldVMNum,this.charingondemand);
				
				//��ƱȽϷ���
				if(obj.getCost()<this.bestobj.getCost())
				{						
						this.bestobj = obj;
						this.bestseq = neighbor;	
						exploredcode.add(neighbor.toString().hashCode());
						startneighbor = neighbor;
						flag = true;
						lsn.initial();
//						System.out.println("iteration="+iteration+ "bestobj="+bestobj.getCost());
						break;
				}
				else if(obj.getCost()==bestobj.getCost()&&!exploredcode.contains(neighbor.toString().hashCode()))
				{
					exploredcode.add(neighbor.toString().hashCode());
					System.out.println("Find equal "+obj.getCost()+"="+bestobj.getCost()+" "+neighbor.toString().hashCode()+"!="+bestseq.toString().hashCode());
					this.bestobj = obj;
					this.bestseq = neighbor;	
					startneighbor = neighbor;
					flag = true;
					lsn.initial();
					break;
				}
				else if(this.isaccept(obj, iteration)&&!exploredcode.contains(neighbor.toString().hashCode()))
				{
					exploredcode.add(neighbor.toString().hashCode());
					flag = true;
					startneighbor = neighbor;
					lsn.initial();
//					System.out.println("iteration="+iteration+ "bestobj="+bestobj.getCost()+" acceptobj="+obj.getCost());
					break;
				}					
					if(System.currentTimeMillis()-start>=C.EVENTINTERVAL) break;
//					if(explored.size()>10) break;
				}
				
			if(System.currentTimeMillis()-start>=C.EVENTINTERVAL) break;
			
			iteration++;
		}
		exploredcode = null;
//		System.out.println("END---------------------------SA");

//		System.out.println("VND end explored "+count+" best="+bestobj.getCost()+"initialcost="+initialcost+"*****************");
	}
	
//	public void run1(Event event, ArrayList<Integer> startSeq, LocalSearchNeighbors lsn,int curT)
//	{
////		bestMObj.print();
//		int k = 1;
//		int size = startSeq.size();
//		HashSet<String> explored = new HashSet<String>();
//		boolean flag = false;
//		long start = System.currentTimeMillis();
////		CommonOperation.printLine();
//		int count = 0;
//		double initialcost = bestprice;
//		while(k<=2)
//		{	
//			//System.out.println("k="+k);
//			flag = false;
//			ArrayList<int[]> N = null;
//			if(k==2) N = lsn.getOneInsertionNeighbors(size);
//			else N = lsn.getSwitchNeighbors(size);
//			int number = N.size();
//			for(int i=0;i<number;i++)
//			{
//				if(System.currentTimeMillis()-start>=C.EVENTINTERVAL) break;
//				ArrayList<Integer> neighbor = CO.GenNeighbor(this.bestseq, N.get(i));
////				String strneighbor = neighbor.toString();
////				if(explored.contains(strneighbor)) continue;
////				explored.add(strneighbor);
////				EmptySlotLinkedlist cleanlist = this.emptylist.Clone();
////				double inner_obj = -1;
//				TTM ttm = new TTM(neighbor,event);			
////				biObject obj = new biObject();
//				count++;
////				obj.compute(ttm.run(this.setting,emptylist.Clone(),curT),event,this.totalOldVMNum,this.charingondemand);
//				ttm.run(this.setting,emptylist.Clone(),curT);
//				EmptySlotLinkedlist list = ttm.getLinkedlist();
//				double curprice = list.computeprice(totalOldVMNum, curT);
//				//��ƱȽϷ���
//				if(curprice<bestprice)
//					{
//						
//						this.bestprice = curprice;
////						System.out.println("k="+k+" "+curprice);
//						this.bestseq = neighbor;						
//						flag = true;
//						break;
//					}
//				
////					
//					
//					
//					if(System.currentTimeMillis()-start>=C.EVENTINTERVAL) break;
////					if(explored.size()>10) break;
//				}
//				
//			if(System.currentTimeMillis()-start>=C.EVENTINTERVAL) break;
//			
//			if(flag) k=1;
//			else k++;
//		}
//		explored = null;
//		System.out.println("VND end explored "+count+" best="+this.bestprice+"initialcost="+initialcost+"*****************");
//	}
	
	public ArrayList<Integer> getBestseq() {
		return bestseq;
	}

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double bestobj = 20000;
		double obj = 30000;
		
		for(int i=0;i<60;i++)
		{
			double p = Math.exp((bestobj-obj)/(bestobj/(20-i)));
			System.out.println("iteration "+i+" ���ܸ���="+p);
		}
		
	}

}
