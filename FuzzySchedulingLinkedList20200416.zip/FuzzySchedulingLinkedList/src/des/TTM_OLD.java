package des;

import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import Experiments.InstanceGenerator;
import Experiments.ParametersRange;
import Jobs.Event;
import Jobs.FJOB;
import Jobs.FJOBS;
import Jobs.FTask;
import Jobs.JobRealInfo;
import ResourceManagement.EmptySlotLinkedlist;
import ResourceManagement.HeapMin;
import ResourceManagement.Slot;
import ResourceManagement.VirtualCluster;
import ResourceManagement.VirtualClusterList;
import SchedulePlan.FAssignment;
import SchedulePlan.FJobAssignment;
import SchedulePlan.FPlan;
import SchedulePlan.Schedule;
import Tools.CO;
import Tools.FO;
import Tools.ValidationCheckingTool;
import element.Area;
import element.C;
import element.FuzzyNumber;
import element.Parameters;
import element.TaskState;
import visual.ShowDESResult_Fuzzy;

public class TTM_OLD {
	
	ArrayList<Integer> sequence;
	int jobnum;
	HeapMin hm;
	Event event;
	int m;
	Parameters setting;
	EmptySlotLinkedlist linkedlist;
	
	public TTM_OLD(ArrayList<Integer> seq, Event event)
	{
		this.sequence = seq;
		this.jobnum = event.getJobnum();
		hm = new HeapMin(jobnum);//ÿ��job����ʱ��ֻ��һ��ready task������hmֻҪm������
		this.event = event;
		this.m = event.getM();
		
	}
	

	private void initialization(EmptySlotLinkedlist linkedlist){
	
		for(int i=0;i<jobnum;i++)
		{
			int jobid = sequence.get(i);
			FJobAssignment job_as = event.getJob(jobid);
			FTask task = null;  //int length, int earliest, int latest,int jobid,int stage
			for(int j=0;j<m;j++)  //int length, int earliest, int latest,int jobid,int stage
			{
				if(job_as.getTask(j).getTaskstate()==TaskState.READY2PLAN) //ready task ��һ���ӵ�һ����ʼ�������ص��ȵ����
				{
					task = job_as.getTask(j);
					break;
				}
			}
			if(task==null)
			{
				System.out.println("ERRORRRR: have no ready task, impossible");
			}
			//��һ���������ڲ���ʽ��ʼִ��
			FuzzyNumber earliest = null;
//			if(setting.VNDflag())
					earliest = new FuzzyNumber(event.getArriveTime()+C.EVENTINTERVAL);
//				else earliest = new FuzzyNumber(event.getArriveTime());//�Ƿ���������overlap��
			if(task.getStage()>0)//���ǵ�һ�������ʱ������һ���������ʱ��֮��ʼ
			{
				FTask pretask = job_as.getTask(task.getStage()-1);
				FAssignment as = job_as.getAssignment(pretask.getStage());
				earliest = FO.Max(earliest, as.getEnd());
			}
			
			task.setEarliest(earliest);			
			String vmid = null;
			if(setting.getTMStrategy()==C.PEST)
			{
				task.setPriority(FO.Max(task.getEarliest(), earliest));
			}
			else if(setting.getTMStrategy()==C.FEST)
			{
				Slot slot = linkedlist.getRealEarliestStart(task);
				
				if(slot!=null)
				{
					FuzzyNumber earlestrealstart = slot.getStart();
					task.setPriority(earlestrealstart);
					vmid = slot.getVmid();
					
				}
				else //�÷����»�������
				{
					task.setPriority(task.getEarliest()); 
					vmid = "NEW";//��ʱ��û�а��»�������
				}
			}
			hm.insert(task,vmid);
		}
	}
	
	private void initialization(VirtualClusterList vclist){
		
		for(int i=0;i<jobnum;i++)
		{
			int jobid = sequence.get(i);
			FJobAssignment job_as = event.getJob(jobid);
			FTask task = null;
			for(int j=0;j<m;j++)  //int length, int earliest, int latest,int jobid,int stage
			{
				if(job_as.getTask(j).getTaskstate()==TaskState.READY2PLAN) 
				{
					task = job_as.getTask(j);
					break;
				}
			}
			if(task==null)
			{
				System.out.println("ERRORRRR: have no ready task, impossible");
			}
			//��һ���������ڲ���ʽ��ʼִ��
			FuzzyNumber earliest = null;
//			if(setting.VNDflag())
					earliest = new FuzzyNumber(event.getArriveTime()+C.EVENTINTERVAL);
//				else earliest = new FuzzyNumber(event.getArriveTime());//�Ƿ���������overlap��
			if(task.getStage()>0)
			{
				FTask pretask = job_as.getTask(task.getStage()-1);
				FAssignment as = job_as.getAssignment(pretask.getStage());
				earliest = FO.Max(earliest,as.getEnd());
			}
			
			task.setEarliest(earliest);
			String vmid = null;
			if(setting.getTMStrategy()==C.PEST)
			{
				task.setPriority(FO.Max(task.getEarliest(), earliest));
			}
			else if(setting.getTMStrategy()==C.FEST)
			{
				VirtualCluster vc = vclist.getList().get(task.getStage());
				FPlan plan = vc.getRealEarliestStart(task);
				
				
				if(plan.getPlanslot()!=null)
				{
					task.setPriority(plan.getPlanstart());
					vmid = plan.getPlanslot().getVmid();					
				}
				else //�÷����»�������
				{
					task.setPriority(task.getEarliest());
					vmid = "NEW";//��ʱ��û�а��»�������
				}
			}
			hm.insert(task,vmid);
		}
	}
	

	
	public double getTriangleArea(FuzzyNumber f)
	{
		return (double)(f.getHighValue()-f.getLowValue())/2;
	}
	
	
	public void run(Parameters setting,VirtualClusterList vclist,int curT,Schedule schedule)
	{
		this.setting = setting;
		this.initialization(vclist);
		while(!hm.isEmpty())
		{		
				FTask task = hm.removemin();				
				FAssignment as = vclist.Arrange(task);					
				schedule.SaveAssignment(as);
				if(as.getStage()<m-1)
				{					
					int jobid = as.getJobid();
					FJobAssignment job_as = event.getJob(jobid);
					FTask nexttask = job_as.getTask(task.getStage()+1);
					nexttask.setTaskstate(TaskState.READY2PLAN);
					FuzzyNumber earliest = as.getEnd();
					nexttask.setEarliest(earliest);
					String vmid = null;
					if(setting.getTMStrategy()==C.PEST)
					{						
						nexttask.setPriority(earliest);
					}
					else if(setting.getTMStrategy()==C.FEST)
					{
						this.updateHeap(vclist,as.getMid());//�Ѿ�ȷ��as�Ļ�����Ҫ����
						FPlan plan = vclist.getList().get(nexttask.getStage()).getRealEarliestStart(nexttask);					
						if(plan.getPlanslot()!=null)
						{
							vmid = plan.getPlanslot().getVmid();
							nexttask.setPriority(plan.getPlanstart());							
						}
						else //�÷����»�������
						{
							nexttask.setPriority(earliest);
							vmid = "NEW";//��ʱ��û�а��»�������
						}
					}
					
					hm.insert(nexttask,vmid);
				}	
		}
	}
	
	public HashMap<Integer,ArrayList<FAssignment>> run(Parameters setting,EmptySlotLinkedlist linkedlist,int curT)
	{
		this.linkedlist = linkedlist;
		HashMap<Integer,ArrayList<FAssignment>> result = new HashMap<Integer,ArrayList<FAssignment>>();
		for(int i=0;i<jobnum;i++)
		{
			result.put(sequence.get(i), new ArrayList<FAssignment>());
			
		}
		
		this.setting = setting;
		this.initialization(linkedlist);
		while(!hm.isEmpty())
		{		
				FTask task = hm.removemin();				
				FAssignment as = linkedlist.Arrange(task,curT);//TODO arrange task ��ʱ���ÿ���delay����earliest�Ѿ�����
				result.get(as.getJobid()).add(as);//ÿ�������ɵ�as����ֱ�Ӽӵ�result�����Ӧ��arraylist���				
				if(as.getStage()<m-1)
				{
					int jobid = as.getJobid();
					FJobAssignment job_as = event.getJob(jobid);
					FTask nexttask = job_as.getTask(task.getStage()+1);
					FuzzyNumber earliest = as.getEnd();
					nexttask.setEarliest(earliest);								
					String vmid = null;
					
					
					if(setting.getTMStrategy()==C.PEST)
					{						
						nexttask.setPriority(earliest);
					}
					else if(setting.getTMStrategy()==C.FEST)
					{
						this.updateHeap(linkedlist,as.getMid());//���°��ŵ�as���ڻ���mid�ϣ�����priority�����ڸû����ϵ�task���������¼������ȼ�
						Slot slot = linkedlist.getRealEarliestStart(nexttask);						
						if(slot!=null)
						{
							vmid = slot.getVmid();
							nexttask.setPriority(slot.getStart());							
						}
						else //�÷����»�������
						{
							nexttask.setPriority(earliest);
							vmid = "NEW";//��ʱ��û�а��»�������
						}
					}
					
					hm.insert(nexttask,vmid);
				}	
		}
		return result;
	}
	
	public EmptySlotLinkedlist getLinkedlist() {
		return linkedlist;
	}


	private void updateHeap(EmptySlotLinkedlist linkedlist,String vmid)
	{
		if(setting.getTMStrategy()==C.FEST) //=1 realistic ESTF
		{
			FTask[] tasklist = hm.getHeap();
			int size = hm.getSize();
			for(int i=0;i<size;i++)
			{
				if(!hm.getVmlist()[i].equalsIgnoreCase(vmid)) continue;
				Slot slot = linkedlist.getRealEarliestStart(tasklist[i]);
				if(slot==null)
				{
					tasklist[i].setPriority(tasklist[i].getEarliest()); 
//					vmid = "NEW";//��ʱ��û�а��»�������
				}
				else
				tasklist[i].setPriority(slot.getStart());
			}
			
		}
		hm.update();
	}
	
	private void updateHeap(VirtualClusterList vclist,String vmid)
	{
		if(setting.getTMStrategy()==C.FEST) //=1 realistic ESTF
		{
			FTask[] tasklist = hm.getHeap();
			int size = hm.getSize();
			for(int i=0;i<size;i++)
			{
				if(!hm.getVmlist()[i].equalsIgnoreCase(vmid)) continue;
				FPlan fplan = vclist.getList().get(tasklist[i].getStage()).getRealEarliestStart(tasklist[i]);
				tasklist[i].setPriority(fplan.getPlanstart());
			}
			
		}
		hm.update();
	}
	
	public static void main(String[] args)
	{
		
	}
}
