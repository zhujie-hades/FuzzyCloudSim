package des;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import Experiments.ParametersRange;
import Jobs.Event;
import ResourceManagement.ChargingOnOnDemand;
import ResourceManagement.EmptySlotLinkedlist;
import ResourceManagement.VirtualClusterList;
import SchedulePlan.biObject;
import Tools.CO;
import element.C;
import element.Parameters;
import neighbor.LocalSearchNeighbors;
import neighbor.LocalSearchNeighbors_old_outofmemoryerror;

public class VND_OLD_outofmemoryerror {

//	VirtualClusterList bestVClist;
//	double bestObj;
//	double bestMObj;
	Parameters setting;
	ArrayList<Integer> bestseq;
	EmptySlotLinkedlist emptylist;
	biObject bestobj;
	HashMap<String,ChargingOnOnDemand> charingondemand;
	int totalOldVMNum;
	double bestprice;
	
	public VND_OLD_outofmemoryerror(EmptySlotLinkedlist emptylist,biObject obj,ArrayList<Integer>bestseq, Parameters setting,int totalOld,HashMap<String,ChargingOnOnDemand> charingondemand)
	{
		
		this.setting = setting;
		this.bestseq = bestseq;
//		this.bestMObj =bestMObj;
		this.bestobj = obj;
		this.emptylist = emptylist;
	    this.charingondemand = charingondemand;
	    this.totalOldVMNum = totalOld;
	}
	
//	public VND(EmptySlotLinkedlist emptylist,double bestprice,ArrayList<Integer>bestseq, Parameters setting,int totalOld,HashMap<String,ChargingOnOnDemand> charingondemand)
//	{
//		
//		this.setting = setting;
//		this.bestseq = bestseq;
////		this.bestMObj =bestMObj;
//		this.bestprice = bestprice;
//		this.emptylist = emptylist;
//	    this.charingondemand = charingondemand;
//	    this.totalOldVMNum = totalOld;
//	}
	
	
	
	public void run(Event event, ArrayList<Integer> startSeq, LocalSearchNeighbors_old_outofmemoryerror lsn,int curT)
	{
//		bestMObj.print();
		int k = 1;
		int size = startSeq.size();
		HashSet<String> explored = new HashSet<String>();
		boolean flag = false;
		long start = System.currentTimeMillis();
//		CommonOperation.printLine();
		int count = 0;
		double initialcost = bestobj.getCost();
		while(k<=2)
		{	
			//System.out.println("k="+k);
			flag = false;
			ArrayList<int[]> N = null;
			if(k==2) N = lsn.getOneInsertionNeighbors(size);
			else N = lsn.getSwitchNeighbors(size);
			int number = N.size();
			for(int i=0;i<number;i++)
			{
				if(System.currentTimeMillis()-start>=C.EVENTINTERVAL) break;
				ArrayList<Integer> neighbor = CO.GenNeighbor(this.bestseq, N.get(i));
//				String strneighbor = neighbor.toString();
//				if(explored.contains(strneighbor)) continue;
//				explored.add(strneighbor);
//				EmptySlotLinkedlist cleanlist = this.emptylist.Clone();
//				double inner_obj = -1;
				TTM ttm = new TTM(neighbor,event);			
				biObject obj = new biObject();
				count++;
				obj.compute(ttm.run(this.setting,emptylist.Clone(),curT),event,this.totalOldVMNum,this.charingondemand);
				
				//��ƱȽϷ���
				if(obj.getCost()<this.bestobj.getCost())
					{
						
						this.bestobj = obj;
//						System.out.println("k="+k+" "+bestobj.getCost());
						this.bestseq = neighbor;						
						flag = true;
						break;
					}
				
//					
					
					
					if(System.currentTimeMillis()-start>=C.EVENTINTERVAL) break;
//					if(explored.size()>10) break;
				}
				
			if(System.currentTimeMillis()-start>=C.EVENTINTERVAL) break;
			
			if(flag) k=1;
			else k++;
		}
		explored = null;
//		System.out.println("VND end explored "+count+" best="+bestobj.getCost()+"initialcost="+initialcost+"*****************");
	}
	
//	public void run1(Event event, ArrayList<Integer> startSeq, LocalSearchNeighbors lsn,int curT)
//	{
////		bestMObj.print();
//		int k = 1;
//		int size = startSeq.size();
//		HashSet<String> explored = new HashSet<String>();
//		boolean flag = false;
//		long start = System.currentTimeMillis();
////		CommonOperation.printLine();
//		int count = 0;
//		double initialcost = bestprice;
//		while(k<=2)
//		{	
//			//System.out.println("k="+k);
//			flag = false;
//			ArrayList<int[]> N = null;
//			if(k==2) N = lsn.getOneInsertionNeighbors(size);
//			else N = lsn.getSwitchNeighbors(size);
//			int number = N.size();
//			for(int i=0;i<number;i++)
//			{
//				if(System.currentTimeMillis()-start>=C.EVENTINTERVAL) break;
//				ArrayList<Integer> neighbor = CO.GenNeighbor(this.bestseq, N.get(i));
////				String strneighbor = neighbor.toString();
////				if(explored.contains(strneighbor)) continue;
////				explored.add(strneighbor);
////				EmptySlotLinkedlist cleanlist = this.emptylist.Clone();
////				double inner_obj = -1;
//				TTM ttm = new TTM(neighbor,event);			
////				biObject obj = new biObject();
//				count++;
////				obj.compute(ttm.run(this.setting,emptylist.Clone(),curT),event,this.totalOldVMNum,this.charingondemand);
//				ttm.run(this.setting,emptylist.Clone(),curT);
//				EmptySlotLinkedlist list = ttm.getLinkedlist();
//				double curprice = list.computeprice(totalOldVMNum, curT);
//				//��ƱȽϷ���
//				if(curprice<bestprice)
//					{
//						
//						this.bestprice = curprice;
////						System.out.println("k="+k+" "+curprice);
//						this.bestseq = neighbor;						
//						flag = true;
//						break;
//					}
//				
////					
//					
//					
//					if(System.currentTimeMillis()-start>=C.EVENTINTERVAL) break;
////					if(explored.size()>10) break;
//				}
//				
//			if(System.currentTimeMillis()-start>=C.EVENTINTERVAL) break;
//			
//			if(flag) k=1;
//			else k++;
//		}
//		explored = null;
//		System.out.println("VND end explored "+count+" best="+this.bestprice+"initialcost="+initialcost+"*****************");
//	}
	
	public ArrayList<Integer> getBestseq() {
		return bestseq;
	}

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
