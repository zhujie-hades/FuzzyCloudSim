package Tools;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import Jobs.FJOB;
import Jobs.FJOBS;
import Jobs.JobRealInfo;
import element.FuzzyNumber;

public class TextOperation {


	public static String readLastLinefromText(String filename)
	{
		File file = new File(filename);
		if(!file.exists()) return null;
		RandomAccessFile raf = null;
		try {
			raf = new RandomAccessFile(file,"r");
			long len = raf.length();
			if(!(len==0L))
			{
				long pos = len-1;
				while(pos>0)
				{
					pos--;
					raf.seek(pos);
					if(raf.readByte()=='\n')
				    break;
				}
				if(pos==0) raf.seek(0);
				byte[] bytes = new byte[(int)(len-pos)];
				raf.read(bytes);
				String lastline = new String(bytes);
				System.out.println(lastline);
				return lastline;
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	
	public static void processing(String fileout,String filein)
	{
		BufferedWriter write = null;
		BufferedReader read = null;
		try {
		read = new BufferedReader(new InputStreamReader(new FileInputStream(fileout)));
		write = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(filein, true)));
		String data = null;
		while((data = read.readLine())!=null)
		{
			if(data.contains("Objective")) continue;
			if(data.contains("--")) continue;
			if(data.contains("Tmax")) continue;
			write.write(data);
			write.write(""+"\r\n");
		}	
		} catch (Exception e) {
		e.printStackTrace();
		} finally {
		try {
		write.close();
		read.close();
		} catch (IOException e) {
		e.printStackTrace();
		}
		}
	}
	
	public static void writeResultIntoText(String location,String filename,ArrayList<String> result)
	{
//		try {
			
			BufferedWriter out = null;
			try {
			out = new BufferedWriter(new OutputStreamWriter(
			new FileOutputStream(location+"\\"+filename+".txt", true)));
//			out.write(title+"\r\n");
//			out.write(""+"\r\n");
			int size = result.size();
			for(int i=0;i<size;i++)
			{
				out.write(result.get(i));
				out.write("\r\n");
			}
			} catch (Exception e) {
			e.printStackTrace();
			} finally {
			try {
			out.close();
			} catch (IOException e) {
			e.printStackTrace();
			}
			}
			
//			FileWriter fileWriter=new FileWriter("D:\\��������\\Experiment Results\\"+filename);
//			fileWriter.append(title);
//			fileWriter.append("\r\n");
//			fileWriter.append("");
//			fileWriter.append("\r\n");
//
//			int size = result.size();
//			for(int i=0;i<size;i++)
//			{
//				fileWriter.write(result.get(i));
//				fileWriter.write("\r\n");
//			}
//			fileWriter.flush();
//			fileWriter.close();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

	}
	
	public static FJOBS readDynamicfromtxt(String path,String instanceid,int m,int lastTime,ArrayList<Integer> arriveNumList,JobRealInfo monitor)
	{
		File file = new File(path+"\\"+instanceid+".txt");
		FJOBS jobs = new FJOBS(0,m);
		
		int curTime = 0;
		int count = 0;
		int jobid = -1;
			try {
				BufferedReader reader = new BufferedReader(new InputStreamReader(
						new FileInputStream(file), "UTF-8"));
				String str = null;
//5235,5732,5758||4369,4698,4805||4587,4850,5045 list0
//5617,4680,4843      13,14,14><13,14,14><13,14,14 list1
//14,14,14,1.35,0 list2

				while((str=reader.readLine())!=null)
				{		//System.out.println(str);
					jobid++;
					String[] list = str.split(">,");
					FuzzyNumber[] op = new FuzzyNumber[m];
					FuzzyNumber[] latency = new FuzzyNumber[m];
					
					//to get oplength
					String[] oplist = list[0].split("><");
					oplist[0] = oplist[0].substring(1, oplist[0].length());
					for(int i=0;i<m;i++)
					{
						String[] opl = oplist[i].split(",");
						op[i] = new FuzzyNumber(Integer.parseInt(opl[0]),Integer.parseInt(opl[2]),Integer.parseInt(opl[1]));
					}
					//to get latency
					String[] templist = list[1].split(",<");
					String[] latencylist = templist[1].split("><");
					for(int i=0;i<m;i++)
					{
						String[] latencyl = latencylist[i].split(",");
						latency[i] = new FuzzyNumber(Integer.parseInt(latencyl[0]),Integer.parseInt(latencyl[2]),Integer.parseInt(latencyl[1]));
					}
					//to get real oplength
					String[] realoplist = templist[0].split(",");
					for(int i=0;i<m;i++)
					monitor.addJobRealOpLength(jobid, i, Integer.parseInt(realoplist[i]));
					
					//
					templist = list[2].split(",");
					for(int i=0;i<m;i++)
						monitor.addJobRealDelay(jobid, i, Integer.parseInt(templist[i]));
					
					
					double df = Double.parseDouble(templist[m]);
					int arriveTime = Integer.parseInt(templist[m+1]);
					if(arriveTime>lastTime)
					{
						arriveNumList.add(count);
						break;
					}
					FJOB job = new FJOB(m,op,latency,arriveTime,df);
					
					jobs.addJob(job);
					
					if(arriveTime!=curTime)
					{
						arriveNumList.add(count);
						curTime+=1000;
						while(arriveTime!=curTime)
						{
							arriveNumList.add(0);
							curTime+=1000;
						}
						count=1;
						curTime = arriveTime;
					}
					else
					{
						count++;
					}					
				}
				
				reader.close();
//				jobs.print();
//				System.out.println("event number:"+arriveNumList.size());
//				System.out.println(arriveNumList.toString());
				//dboperations.writeEVAJobinfo2db(jobs,instanceid,m,n);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
     return jobs;
	}
	
	public static void mergeFliterNOLS(String from,String to)
	{
		File file = new File(from);
		String[] filelist = file.list();
		File tofile = new File(to);
			try {
				BufferedWriter out = null;							
				out = new BufferedWriter(new OutputStreamWriter(
				new FileOutputStream(tofile, true)));				
				for(int i=0;i<filelist.length;i++)
				{
					String filename = filelist[i];
					if(filename.contains(".txt"))
					{
						File subfile = new File(from+"\\"+filename);
						BufferedReader reader = new BufferedReader(new InputStreamReader(
								new FileInputStream(subfile), "UTF-8"));
						String str = null;				
						while((str=reader.readLine())!=null)
						{
							String[] list = str.split("\t");
							if(list[3].equalsIgnoreCase("VND")) continue;
							out.write(str);
							out.write("\r\n");
							
						}
						reader.close();
					}
				}
				
				out.close();
				
//				jobs.print();
//				System.out.println("event number:"+arriveNumList.size());
//				System.out.println(arriveNumList.toString());
				//dboperations.writeEVAJobinfo2db(jobs,instanceid,m,n);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	public static void mergeWithExtendInfor(String from,String to)
	{
		File file = new File(from);
		String[] filelist = file.list();
		File tofile = new File(to);
			try {
				BufferedWriter out = null;							
				out = new BufferedWriter(new OutputStreamWriter(
				new FileOutputStream(tofile, true)));				
				for(int i=0;i<filelist.length;i++)
				{
					String filename = filelist[i];
					System.out.println(filename);
					if(filename.contains(".txt"))
					{
						File subfile = new File(from+"\\"+filename);
						BufferedReader reader = new BufferedReader(new InputStreamReader(
								new FileInputStream(subfile), "UTF-8"));
						String str = null;				
						while((str=reader.readLine())!=null)
						{
							String result = "";
							String[] list = str.split("\t");
							String[] infolist = list[0].split("_");	
//							if(Integer.parseInt(infolist[0])>6) continue;
							String isLS = "LS";
							if(list[3].equalsIgnoreCase("LS_NONE")) isLS = "None";
//							if(Integer.parseInt(infolist[4])==-1) continue;
							result = str+"\t"+infolist[0]+"\t"+infolist[4]+"\t"+infolist[5]+"\t"+infolist[3]+"\t"+infolist[6]+"\t"+isLS;
							out.write(result);
							out.write("\r\n");
							
						}
						reader.close();
					}
				}
				
				out.close();
				
//				jobs.print();
//				System.out.println("event number:"+arriveNumList.size());
//				System.out.println(arriveNumList.toString());
				//dboperations.writeEVAJobinfo2db(jobs,instanceid,m,n);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	
	public static void mergeWithFixInstanceNum(String from,String to, int num)
	{
		File file = new File(from);
		String[] filelist = file.list();
		File tofile = new File(to);
			try {
				BufferedWriter out = null;							
				out = new BufferedWriter(new OutputStreamWriter(
				new FileOutputStream(tofile, true)));	
				
				for(int i=0;i<num;i++)
				{
					String filename = filelist[i];
					System.out.println(filename);
					if(filename.contains(".txt"))
					{
						File subfile = new File(from+"\\"+filename);
						BufferedReader reader = new BufferedReader(new InputStreamReader(
								new FileInputStream(subfile), "UTF-8"));
						String str = null;				
						while((str=reader.readLine())!=null)
						{
//							String result = "";
//							String[] list = str.split("\t");
//							String[] infolist = list[0].split("_");	
////							if(Integer.parseInt(infolist[0])>6) continue;
//							String isLS = "LS";
//							if(list[3].equalsIgnoreCase("LS_NONE")) isLS = "None";
////							if(Integer.parseInt(infolist[4])==-1) continue;
//							result = str+"\t"+infolist[0]+"\t"+infolist[4]+"\t"+infolist[5]+"\t"+infolist[3]+"\t"+infolist[6]+"\t"+isLS;
							out.write(str);
							out.write("\r\n");
							
						}
						reader.close();
					}
				}
				
				out.close();
				
//				jobs.print();
//				System.out.println("event number:"+arriveNumList.size());
//				System.out.println(arriveNumList.toString());
				//dboperations.writeEVAJobinfo2db(jobs,instanceid,m,n);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	
	public static void mergeWithSeparateW(String from,String to, int num)
	{
		
		File file = new File(from);
		String[] filelist = file.list();
		File tofile = new File(to);
			try {
				BufferedWriter out = null;							
				out = new BufferedWriter(new OutputStreamWriter(
				new FileOutputStream(tofile, true)));	
				int filenumber = filelist.length;
				for(int i=0;i<filenumber;i++)
				{
					String filename = filelist[i];
					System.out.println(filename);
					if(filename.contains(".txt"))
					{
						File subfile = new File(from+"\\"+filename);
						BufferedReader reader = new BufferedReader(new InputStreamReader(
								new FileInputStream(subfile), "UTF-8"));
						String str = null;	
						
						while((str=reader.readLine())!=null)
						{
							
//							String result = "";
//							String[] list = str.split("\t");
//							String[] infolist = list[0].split("_");	
////							if(Integer.parseInt(infolist[0])>6) continue;
//							String isLS = "LS";
//							if(list[3].equalsIgnoreCase("LS_NONE")) isLS = "None";
////							if(Integer.parseInt(infolist[4])==-1) continue;
//							result = str+"\t"+infolist[0]+"\t"+infolist[4]+"\t"+infolist[5]+"\t"+infolist[3]+"\t"+infolist[6]+"\t"+isLS;
							String comstr = "";
							String[] list = str.split("\t");
							for(int k=0;k<18;k++)
							{
								comstr+=list[k]+"\t";
							}
							
							for(int k=0;k<5;k++)
							{
								String temp = comstr+"0."+(k*2+1)+"\t"+list[18+k]+"\t"+list[23+k];
								out.write(temp);
								out.write("\r\n");
							}
						
						}
						reader.close();
					}
				}
				
				out.close();
				
//				jobs.print();
//				System.out.println("event number:"+arriveNumList.size());
//				System.out.println(arriveNumList.toString());
				//dboperations.writeEVAJobinfo2db(jobs,instanceid,m,n);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	public static void mergeWithSeparateWandALG(String from,String to)
	{
		
		File file = new File(from);
		if(!file.exists()) return;
		String[] filelist = file.list();
		File tofile = new File(to);
			try {
				BufferedWriter out = null;							
				out = new BufferedWriter(new OutputStreamWriter(
				new FileOutputStream(tofile, true)));	
				int filenumber = filelist.length;
				for(int i=0;i<filenumber;i++)
				{
					String filename = filelist[i];
					System.out.println(filename);
					if(filename.contains(".txt"))
					{
						File subfile = new File(from+"\\"+filename);
						BufferedReader reader = new BufferedReader(new InputStreamReader(
								new FileInputStream(subfile), "UTF-8"));
						String str = null;	
						
						while((str=reader.readLine())!=null)
						{
							String comstr1 = "";
							String[] list = str.split("\t");
							comstr1+=list[0]+"\t";
							comstr1+="HEFT\t";
							
							for(int k=2;k<18;k++)
							{
								comstr1+=list[k]+"\t";
							}
							String[] weight = {"0.0","0.2","0.4","0.6","0.8","1.0"};
							for(int k=0;k<6;k++)
							{
								
								String temp = comstr1+weight[k]+"\t"+list[18+k]+"\t"+list[24+k];
								out.write(temp);
								out.write("\r\n");
							}
							
							String comstr2 = "";
							str=reader.readLine();
							list = str.split("\t");
							comstr2+=list[0]+"\t";
							comstr2+="DES\t";
							
							for(int k=2;k<18;k++)
							{
								comstr2+=list[k]+"\t";
							}							
							for(int k=0;k<6;k++)
							{
								
								String temp = comstr1+weight[k]+"\t"+list[18+k]+"\t"+list[24+k];
								out.write(temp);
								out.write("\r\n");
							}
							
							String comstr3 = "";
							str=reader.readLine();
							String[] list1 = str.split("\t");
							str=reader.readLine();
							String[] list2 = str.split("\t");
							
							comstr3+=list[0]+"\t";
							comstr3+="FDES\t";
							for(int k=2;k<18;k++)
							{
								comstr3+=list1[k]+"\t";
							}
							for(int k=0;k<6;k++)
							{
								String temp = comstr3+weight[k]+"\t"+CO.max(Double.parseDouble(list1[18+k]), Double.parseDouble(list2[18+k]))+"\t"
											+CO.max(Double.parseDouble(list1[24+k]), Double.parseDouble(list2[24+k]));
								out.write(temp);
								out.write("\r\n");
							}
							
							
//							String result = "";
//							String[] list = str.split("\t");
//							String[] infolist = list[0].split("_");	
////							if(Integer.parseInt(infolist[0])>6) continue;
//							String isLS = "LS";
//							if(list[3].equalsIgnoreCase("LS_NONE")) isLS = "None";
////							if(Integer.parseInt(infolist[4])==-1) continue;
//							result = str+"\t"+infolist[0]+"\t"+infolist[4]+"\t"+infolist[5]+"\t"+infolist[3]+"\t"+infolist[6]+"\t"+isLS;
							
						
						}
						reader.close();
					}
				}
				
				out.close();
				
//				jobs.print();
//				System.out.println("event number:"+arriveNumList.size());
//				System.out.println(arriveNumList.toString());
				//dboperations.writeEVAJobinfo2db(jobs,instanceid,m,n);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	
	public static void main(String[] args) {
		
//		TextOperation.readLastLinefromText("E:\\fuzzyScheduling\\Experiment Results\\m=3 Possion\\3_0_[10,15].txt");
//		String from = "D:\\��������\\Experiment Results\\Fuzzy\\Experiment Results NewObjectives\\m=10 Possion\\Compare";
//		String to = "D:\\��������\\Experiment Results\\Fuzzy\\Experiment Results NewObjectives\\m=10 Possion\\Compare\\merge_all_possion.txt";

//		for(int i=3;i<=10;i++)
//	    {String from = "D:\\��������\\Experiment Results\\Fuzzy\\Experiment Results NewObjectives\\m="+i+" Uniform";
//		String to = "D:\\��������\\Experiment Results\\Fuzzy\\Experiment Results NewObjectives\\merge_all_uniform.txt";
//		//		TextOperation.mergeWithExtendInfor(from);
//		TextOperation.mergeFliterNOLS(from,to);}
//		int num = 1;
		for(int i=3;i<=10;i++)
	    {
		String from = "D:\\��������\\Experiment Results\\Fuzzy\\Experiment Results LinkedList\\2019-03-22-compare\\m="+i+" Possion";
		String to =   "D:\\��������\\Experiment Results\\Fuzzy\\Experiment Results LinkedList\\2019-03-22-compare\\merge_detail_possion_sepw95_20190322"+".txt";
		TextOperation.mergeWithSeparateWandALG(from,to);
		}
		for(int i=3;i<=10;i++)
	    {
		String from = "D:\\��������\\Experiment Results\\Fuzzy\\Experiment Results LinkedList\\2019-03-22-compare\\m="+i+" Uniform";
		String to =   "D:\\��������\\Experiment Results\\Fuzzy\\Experiment Results LinkedList\\2019-03-22-compare\\merge_detail_uniform_sepw95_20190322"+".txt";
		TextOperation.mergeWithSeparateWandALG(from,to);
		}
		
	}

}
