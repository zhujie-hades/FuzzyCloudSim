package Tools;

//import java.rmi.server.Operation;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeMap;

import Jobs.Event;
import Jobs.FJOB;
import Jobs.FTask;
import ResourceManagement.Slot;
import SchedulePlan.FAssignment;
import SchedulePlan.FJobAssignment;
import SchedulePlan.Schedule;
import element.FuzzyNumber;

public class CO {
	
	public static int getStageFromMid(String mid)
	{
		String[] str = mid.split("_");
		return Integer.parseInt(str[0]);
	}
	
	public static String getSlotString(Slot slot)
	{
		if(slot==null) return "";
		return slot.toString();
	}
	
	public static void checkingTwoCopyList(Slot head, Slot copyhead)//�������������Ҫ��������ͬ����ַ��ͬ
	{
		if(head==copyhead&&head!=null)
		{
			System.out.println("ERROR: same head"); return;
		}
		Slot p = head;
		Slot cp = copyhead;
		while(p!=null&&cp!=null)
		{
			if(!p.toString().equalsIgnoreCase(cp.toString()))
			{
				System.out.println("ERROR: different content"); return;				
			}
			p = p.getNextSlot();
			cp = cp.getNextSlot();
		}
		if(p!=null||cp!=null)
		{
			System.out.println("ERROR: different length"); return;		
		}
	}
	
//	public static boolean inSameCloud(FAssignment prefas, FAssignment fas)
//	{
//		boolean preOnNew = CO.isNewVM(prefas.getMid());
//		boolean thisOnNew = CO.isNewVM(fas.getMid());
//		if(preOnNew&&thisOnNew||!preOnNew&&!thisOnNew) return true;
//		return false;
//	}
	
	public static boolean inSameCloud(FAssignment prefas, FAssignment fas)
	{
		boolean preOnNew = CO.isNewVM(prefas.getMid());
		boolean thisOnNew = CO.isNewVM(fas.getMid());
		if(preOnNew&&thisOnNew||!preOnNew&&!thisOnNew) return true;
		return false;
	}
	
	public static double max(double a,double b)
	{
		if(a>b) return a;
		return b;
	}
	
	public static int max(int a,int b)
	{
		if(a>b) return a;
		return b;
	}
	public static int min(int a,int b)
	{
		if(a<b) return a;
		return b;
	}
	
		
	public static void orderJobsByDeadline(Event event)
	{
		ArrayList<Integer> list = event.getJoblist();
		int size = list.size();
		for(int i=0;i<size;i++)
		{
			for(int j=i+1;j<size;j++)
			{
				int firstjob = list.get(i);
				int secondjob = list.get(j);
				FJobAssignment job1 = event.getJob(firstjob);
				FJobAssignment job2 = event.getJob(secondjob);
//				if(job1.getDeadline()>job2.getDeadline())
				if(job1==null||job2==null)
				{
					System.out.println("ERROR: NULL job "+firstjob+" "+secondjob);
				}
				int com=FO.Comparison(job1.getDeadline(), job2.getDeadline());
				if(com==1)
				{
					list.set(i, secondjob);
					list.set(j, firstjob);
				}
			}
		}
	}
	
	public static double getSatisfactionDegree(FuzzyNumber jobend, FuzzyNumber deadline)
	{
		double rate = 0;
		
		double end = jobend.getMostValue();
		
		if(end<=deadline.getMostValue()) rate = 1;
		if(end>=deadline.getHighValue()) rate = 0;
		else
		{
			rate = (deadline.getHighValue()-end)/(deadline.getHighValue()-deadline.getMostValue());
		}
		return rate;
	}
	
	public static ArrayList<Integer> GenNeighbor(ArrayList<Integer> startseq, int[] neighbor)
	{
		ArrayList<Integer> result = new ArrayList<Integer>();
		for(int i=0;i<neighbor.length;i++)
		{
			result.add(startseq.get(neighbor[i]));
		}
		return result;
	}
	
	
	
	public static int getMachineNumberID(String id)
	{
		int num = id.indexOf("NEW");
		String numstr = null;
		if(num<0)
		{
			num = id.indexOf("OLD");
		}
		num += 3;
		numstr = id.substring(num, id.length());
		return Integer.parseInt(numstr);
	}

	
	
	
	
	public static boolean isNewVM(String mid)
	{
		if(mid.contains("NEW")) return true;
		return false;
	}
	
	public static void printLine()
	{
		System.out.println("---------------------------------------------------");
	}
	
	public static void main(String args[])
	{
		System.out.println(CO.getMachineNumberID("4_OLD44"));
	}
}
