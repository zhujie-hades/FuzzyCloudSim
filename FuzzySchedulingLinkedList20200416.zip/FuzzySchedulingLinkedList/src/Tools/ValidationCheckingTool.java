package Tools;

import java.util.ArrayList;

import Experiments.ParametersRange;
import Jobs.FJOB;
import Jobs.FJOBS;
import Jobs.JobRealInfo;
import ResourceManagement.Slot;
import ResourceManagement.VirtualCluster;
import ResourceManagement.VirtualClusterList;
import ResourceManagement.VirtualMachine;
import SchedulePlan.FAssignment;
import SchedulePlan.FJobAssignment;
import SchedulePlan.Schedule;
import element.C;
import element.FuzzyNumber;

public class ValidationCheckingTool {

	public static boolean VMChecking(VirtualClusterList vclist)
	{
		boolean result = true;
		int m = vclist.getM();
		for(int i=0;i<m;i++)
		{
			VirtualCluster vc = vclist.getList().get(i);
			if(vc.CheckValidation()==false) return false;
		}		
		return result;
	}
	
	public static boolean JobChecking(VirtualClusterList vclist, Schedule schedule,JobRealInfo realinfo)
	{
		
		int m = schedule.getM();
		int n = schedule.getN();
//		System.out.println("Start checking");
		for(int i=0;i<n;i++)
		{
			Slot[] fslist = vclist.getSlotsOfJob(i);
			if(fslist==null) continue;
			
			int arriveTime = schedule.getJob(i).getArriveTime();
			
			for(int j=0;j<m;j++)
			{
				Slot fas = fslist[j];
				if(j==0)//��鵽��ʱ�������
				{
					if(FO.Comparison(fas.getStart(), arriveTime)<0)
					{
						System.out.println("ERROR:Start before its arrival");
						return false;
					}
				}
				//�жϴ���ʱ������ȷ��
				boolean isStart = !FO.isFuzzyNumber(fas.getStart());
				boolean isEnd = !FO.isFuzzyNumber(fas.getEnd());
				if(isStart&&isEnd)
				{
					int realLength = realinfo.getJobRealOpLength(i, j);
					if(FO.Comparison(FO.Subtraction(fas.getEnd(), fas.getStart()), realLength)==C.LESS)
					{
						System.out.println("ERROR:Processing Time invalid 0");
						return false;
					}
				}
				else
				{
					FuzzyNumber length = schedule.getJob(i).getAssignment(j).getOp();
					if(FO.Comparison(FO.Addition(fas.getStart(), length), fas.getEnd())!=0)
					{
						System.out.println("ERROR:Processing Time invalid 1");
						fas.print();
						length.print();
						return false;
					}
				}
				//�ж�precedence constraint
				if(j>0)
				{
					if(FO.Comparison(fas.getStart(), fslist[j-1].getEnd())==C.LESS)
					{
						System.out.println("ERROR:Precedence Constraint invalid:");
						fas.print();
						fslist[j-1].print();
						return false;
					}
				}
			}
			
		}
		return true;
	}
	
	public static boolean JobChecking(VirtualClusterList vclist, FJOBS jobs,JobRealInfo realinfo)
	{
		
		int m = jobs.getM();
		int n = jobs.getN();
//		System.out.println("Start checking");
		for(int i=0;i<n;i++)
		{
			Slot[] fslist = vclist.getSlotsOfJob(i);
			if(fslist==null) continue;
			FJOB job = jobs.getJob(i);
			int arriveTime = job.getArriveTime();
			
			for(int j=0;j<m;j++)
			{
				Slot fas = fslist[j];
				if(j==0)//��鵽��ʱ�������
				{
					if(FO.Comparison(fas.getStart(), arriveTime)==C.LESS)
					{
						System.out.println("ERROR:Start before its arrival");
						return false;
					}
				}
				//�жϴ���ʱ������ȷ��
				boolean isStart = !FO.isFuzzyNumber(fas.getStart());
				boolean isEnd = !FO.isFuzzyNumber(fas.getEnd());
				if(isStart&&isEnd)
				{
					int realLength = realinfo.getJobRealOpLength(i, j);
					if(FO.Comparison(FO.Subtraction(fas.getEnd(), fas.getStart()), realLength)==C.LESS)
					{
						System.out.println("ERROR:Processing Time invalid 0");
						return false;
					}
				}
				else
				{
					FuzzyNumber length = job.getOp()[j];
					if(FO.Comparison(FO.Addition(fas.getStart(), length), fas.getEnd())!=0)
					{
						System.out.println("ERROR:Processing Time invalid 1");
						fas.print();
						length.print();
						return false;
					}
				}
				//�ж�precedence constraint
				if(j>0)
				{
					if(FO.Comparison(fas.getStart(), fslist[j-1].getEnd())==C.LESS)
					{
						System.out.println("ERROR:Precedence Constraint invalid");
						return false;
					}
				}
			}
			
		}
		return true;
	}
	
	//����delay������£�����assignment�ļ�飬ǰ������ʱ�����>=delay
//	public static boolean JobCheckingConsiderDelay(Schedule schedule, FJOBS jobs,JobRealInfo monitor)
//	{
//		
//		int m = jobs.getM();
//		int n = jobs.getN();
//		
//		boolean flag = true;
//		for(int i=0;i<n;i++)
//		{
//			FJobAssignment jobas = schedule.getJob(i);			
//			int arriveTime = jobas.getArriveTime();
//			
//			for(int j=0;j<m;j++)
//			{
//				FAssignment fas = jobas.getAssignment(j);
//				if(j==0)//��鵽��ʱ�������
//				{
//					if(FO.Comparison(fas.getStart(), arriveTime)<0)
//					{
//						System.out.print("ERROR-Start before its arrival: arriveTime="+arriveTime+" startTime=");
//						fas.print();						
//						flag = false;
//					}
//				}
//				//�жϴ���ʱ������ȷ��
//				boolean isStart = !FO.isFuzzyNumber(fas.getStart());
//				boolean isEnd = !FO.isFuzzyNumber(fas.getEnd());
//				if(isStart&&isEnd)
//				{
//					int realLength = monitor.getJobRealOpLength(i, j);
//					if(FO.Comparison(FO.Subtraction(fas.getEnd(), fas.getStart()), realLength)!=0)
//					{
//						System.out.println("ERROR:Processing Time invalid 0");
//						flag = false;
//					}
//				}
//				else
//				{
//					FuzzyNumber length = jobas.getTask(j).getLength();
//					if(FO.Comparison(FO.Subtraction(fas.getEnd(), fas.getStart()), length)!=0)
//					{
//						System.out.println("ERROR:Processing Time invalid 1");
//						flag = false;
//					}
//				}
//				//�ж�precedence constraint
//				if(j>0)
//				{
//					int realDelay = monitor.getJobRealDelay(i, j-1);
//					FAssignment prefas = jobas.getAssignment(j-1);
//					FuzzyNumber fuzzyDelay =jobas.getTask(j-1).getDelay();
//					// Start ���ǻ��������µ�delay����
//					if(ParametersRange.problemMode==0)
//					{
//						if(CO.inSameCloud(prefas, fas)) 
//						{
//						realDelay = 0;
//						fuzzyDelay = new FuzzyNumber(0);
//						}	
//					}
//					else if(ParametersRange.problemMode==1) 
//					{
//						realDelay = 0;
//						fuzzyDelay = new FuzzyNumber(0);
//					}
//					 
//					fuzzyDelay.print();
//					// End ���ǻ��������µ�delay����
//					if(jobas.getAssignment(j-1).isDone())
//					{
//						if(FO.Comparison(fas.getStart(), FO.Addition(prefas.getEnd(), realDelay))<0)
//						{
//							System.out.println("ERROR-Precedence Constraint invalid: lastEnd="+prefas.getEnd().toString()+" thisStart="+fas.getStart().toString()+" delay="+realDelay);
//							prefas.print();
//							fas.print();
//							flag = false;
//						}
//					}					
//					else 
//					{
//						if(FO.Comparison(fas.getStart(), FO.Addition(jobas.getAssignment(j-1).getEnd(), fuzzyDelay))<0)
//						{
//							System.out.println("ERROR-Precedence Constraint invalid: lastEnd="+jobas.getAssignment(j-1).getEnd().toString()+" thisStart="+fas.getStart().toString()+" delay="+fuzzyDelay.toString());
//							flag = false;
//						}
//					}
//					
//				}
//			}
//			
//		}
//		return flag;
//	}
	
	
//	public static boolean JobChecking(VirtualClusterList vclist, FJOBS jobs,JobProcessingMonitor monitor, int currentTime)
//	{
//		
//		int m = jobs.getM();
//		int n = jobs.getN();
//		for(int i=0;i<n;i++)
//		{
//			FAssignment[] fslist = vclist.getStartTimesOfJob(i);
//			if(fslist==null) continue;
//			FJOB job = jobs.getJob(i);
//			int arriveTime = job.getArriveTime();
//			
//			for(int j=0;j<m;j++)
//			{
//				FAssignment fas = fslist[j];
//				if(j==0)//��鵽��ʱ�������
//				{
//					if(FuzzyOperation.Comparison(fas.getStart(), arriveTime)<0)
//					{
//						System.out.println("ERROR:Start before its arrival");
//						return false;
//					}
//					
//				}
//				
//				
//				if(FuzzyOperation.Comparison(fas.getStart(), currentTime)<0&&FuzzyOperation.isFuzzyNumber(fas.getStart()))
//				{
//					fas.print();
//					System.out.println("ERROR:the task should have started at "+currentTime);
//					return false;
//				}
//				//�жϴ���ʱ������ȷ��
//				boolean isStart = !FuzzyOperation.isFuzzyNumber(fas.getStart());
//				boolean isEnd = !FuzzyOperation.isFuzzyNumber(fas.getEnd());
//				if(isStart&&isEnd)
//				{
//					int realLength = monitor.getJobRealOpLength(i, j);
//					if(FuzzyOperation.Comparison(FuzzyOperation.Subtraction(fas.getEnd(), fas.getStart()), realLength)!=0)
//					{
//						System.out.println("ERROR:Processing Time invalid 0");
//						return false;
//					}
//				}
//				else
//				{
//					FuzzyNumber length = job.getOp()[j];
//					if(FuzzyOperation.Comparison(FuzzyOperation.Subtraction(fas.getEnd(), fas.getStart()), length)!=0)
//					{
//						System.out.println("ERROR:Processing Time invalid 1");
//						return false;
//					}
//				}
//				//�ж�precedence constraint
//				if(j>0)
//				{
//					if(FuzzyOperation.Comparison(fas.getStart(), fslist[j-1].getEnd())<0)
//					{
//						System.out.println("ERROR:Precedence Constraint invalid");
//						return false;
//					}
//				}
//			}
//			
//		}
//		return true;
//	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
