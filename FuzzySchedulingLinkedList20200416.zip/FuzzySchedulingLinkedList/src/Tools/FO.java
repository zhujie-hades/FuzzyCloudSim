package Tools;

import java.util.Random;

import element.C;
import element.FuzzyNumber;

public class FO {
	   
      
	public static  FuzzyNumber Addition(FuzzyNumber a,FuzzyNumber b){
    	   FuzzyNumber c=new FuzzyNumber(a.getLowValue()+b.getLowValue(),a.getHighValue()+b.getHighValue(),a.getMostValue()+b.getMostValue());
     	   return c;
       }
	
	   public static int max(int a,int b)
	   {
		   if(a>b) return a;
		   return b;
	   }
	   public static int min(int a,int b)
	   {
		   if(a<b) return a;
		   return b;
	   }
      
       public static FuzzyNumber Max(FuzzyNumber a,FuzzyNumber b){
    	  FuzzyNumber c=new FuzzyNumber(max(a.getLowValue(),b.getLowValue()),max(a.getHighValue(),b.getHighValue()),max(a.getMostValue(),b.getMostValue()));    	   
		  return c;
		}
       
       public static FuzzyNumber Max(FuzzyNumber a,int b){
     	  FuzzyNumber c=new FuzzyNumber(max(a.getLowValue(),b),max(a.getHighValue(),b),max(a.getMostValue(),b));    	   
 		  return c;
 		}
       
       public static FuzzyNumber Min(FuzzyNumber a,FuzzyNumber b){
     	  FuzzyNumber c=new FuzzyNumber(min(a.getLowValue(),b.getLowValue()),min(a.getHighValue(),b.getHighValue()),min(a.getMostValue(),b.getMostValue()));    	   
 		  return c;
 		}
       
       public static FuzzyNumber Multipy(FuzzyNumber a,double factor)
       {
    	   FuzzyNumber c=new FuzzyNumber((int)(a.getLowValue()*factor),(int)(a.getHighValue()*factor),(int)(a.getMostValue()*factor));
    	   return c;
       }
       
       public static int compareC1(FuzzyNumber a,FuzzyNumber b)
       {
    	   double a1 = (double)(a.getHighValue()+a.getLowValue()+2*a.getMostValue())/4;
    	   double b1 = (double)(b.getHighValue()+b.getLowValue()+2*b.getMostValue())/4;
    	   if(a1>b1) return C.MORE;
    	   if(a1<b1) return C.LESS;
    	   return C.EQUARE;
       }
       
       public static int compareC2(FuzzyNumber a,FuzzyNumber b)
       {
    	   double a1 = a.getMostValue();
    	   double b1 = b.getMostValue();
    	   if(a1>b1) return C.MORE;
    	   if(a1<b1) return C.LESS;
    	   return C.EQUARE;
       }
       
       public static int compareC3(FuzzyNumber a,FuzzyNumber b)
       {
    	   double a1 = a.getHighValue()-a.getLowValue();
    	   double b1 = b.getHighValue()-b.getLowValue();
    	   if(a1>b1) return C.MORE;
    	   if(a1<b1) return C.LESS;
    	   return C.EQUARE;
       }
       
       public static int Comparison(FuzzyNumber a,FuzzyNumber b){
    	   int comp = compareC1(a,b);
    	   if(comp!=C.EQUARE) return comp;
    	   comp = compareC2(a,b);
    	   if(comp!=C.EQUARE) return comp;
    	   comp = compareC3(a,b);
    	   return comp;
       }
       
       public static FuzzyNumber genRanFuzzyNumber()
       {
    	   Random r = new Random();
    	   int low = r.nextInt(50);
			int high =low+ r.nextInt(50);
			int dif = high-low;
			int most = low+r.nextInt(dif);
    	   FuzzyNumber f = new FuzzyNumber(low,high,most);
    	   return f;
       }
       
       public static int Comparison(FuzzyNumber a,int realtime){
    	   FuzzyNumber b = new FuzzyNumber(realtime,realtime,realtime);
    	   int comp = compareC1(a,b);
    	   if(comp!=C.EQUARE) return comp;
    	   comp = compareC2(a,b);
    	   if(comp!=C.EQUARE) return comp;
    	   comp = compareC3(a,b);
    	   return comp;
       }
       
       public static FuzzyNumber Subtraction(FuzzyNumber a,FuzzyNumber b){
//    	   FuzzyNumber c=new FuzzyNumber(a.getLowValue()-b.getLowValue(),a.getHighValue()-b.getHighValue(),a.getMostValue()-b.getMostValue());
    	   FuzzyNumber c=new FuzzyNumber(a.getLowValue()-b.getHighValue(),a.getHighValue()-b.getLowValue(),a.getMostValue()-b.getMostValue());

    	   return c;
       }

       public static boolean isFuzzyNumber(FuzzyNumber f)
       {
    	   if(f.getLowValue()!=f.getMostValue()) return true;
    	   if(f.getMostValue()!=f.getHighValue()) return true;
    	   return false;
       }
       
	public static FuzzyNumber Addition(FuzzyNumber a, int b) {
		// TODO Auto-generated method stub
		return new FuzzyNumber(a.getLowValue()+b,a.getHighValue()+b,a.getMostValue()+b);
	}
	
	public static void main(String args[])
	{
		double a1 = (double)(5+9+2*4)/4;
		System.out.println(a1);
	}
       
      }
