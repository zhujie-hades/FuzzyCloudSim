package Tools;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFPictureData;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Experiments.AliItem;

public class AliDataProcess {
	
	ArrayList<AliItem> alilist;
	int size = 0;
	int jobnumber = 0;
	public ArrayList<Integer> getArriveTimeList(int m)
	{
		ArrayList<Integer> arriveTimeList = new ArrayList<Integer>();
		int starttime = alilist.get(0).getArriveTime();
		for(int i=0;i<size;i++)
		{
			AliItem item = this.alilist.get(i);
			int arriveTime = item.getArriveTime()-starttime;
			int tasknum = item.getTaskNum();
			int jobnum = tasknum/m;
			jobnumber += jobnum;
			for(int j=0;j<jobnum;j++)
				arriveTimeList.add(arriveTime*1000);
		}
		return arriveTimeList;
	}
	public void print()
	{
		for(int i=0;i<size;i++)
			alilist.get(i).print();
	}
	
	public ArrayList<AliItem> getAlilist() {
		return alilist;
	}

	public int getSize() {
		return size;
	}

	public int getJobnumber() {
		return jobnumber;
	}

	public void getAliInfo(String fileprefix,int wid,int max)
	{
		alilist = new ArrayList<AliItem>();
		String filename = fileprefix+"_"+wid+".txt";
		File file = new File(filename);
		int count = 0;
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					new FileInputStream(file), "UTF-8"));
			String str = null;
			while((str=reader.readLine())!=null&&count<max)
			{		
				String[] temp = str.split("\t");
				double avg = Double.parseDouble(temp[3]);
				if(avg<0.05) avg = 0.05;
				AliItem item = new AliItem(Integer.parseInt(temp[0]),Integer.parseInt(temp[1]),avg);
				alilist.add(item);	
				count+=Integer.parseInt(temp[1]);
			}
			reader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		size = alilist.size();
	}
	
	public void processArrivingRateProcess(String source, String target)//ÿ��Сʱ����һ���ļ�
	{
		BufferedWriter write = null;
		BufferedReader read = null;
		int id = 0;
		String filename = target+id+".txt";
		File file=new File(filename);   
		
		try {
		if(!file.exists())
		file.createNewFile();   
		read = new BufferedReader(new InputStreamReader(new FileInputStream(source)));
		write = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(filename, true)));
		String data = null;
		read.readLine();//����title
        //ʱ�̡�ÿ�����ڵ���������
		int curTime = -1;
		int curNum = 0;
		int totalDuration = 0;
		while((data = read.readLine())!=null)
		{
			String[] arrays = data.split("\t");
			int timestamp = Integer.parseInt(arrays[0]);
			int instancenumber = Integer.parseInt(arrays[5]);
			int duration =  Integer.parseInt(arrays[2]);
			if(curTime==-1)
			{
				curTime = timestamp;
				curNum += instancenumber;
				totalDuration += duration;
				continue;
			}
			if(curTime!=timestamp)
			{
				int newcurTime = curTime%3600;
				String line = newcurTime+"\t"+curNum+"\t"+totalDuration;
				double avg = (double)totalDuration/curNum;
				DecimalFormat format_2 =new   java.text.DecimalFormat("#.##"); 
				line +="\t"+format_2.format(avg);				
				curTime = timestamp;
				curNum = instancenumber;
				totalDuration = duration;
				if(curTime/3600>id)
				{
					id = curTime/3600;
					filename = target+id+".txt";
					file=new File(filename);  
					System.out.println("creat file "+id+" curt="+curTime);
					write.close();
					write = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(filename, true)));
				}
				else
				{
					write.write(line);
					write.write(""+"\r\n");
				}
			}
			else
			{
				curNum += instancenumber;
				totalDuration += duration;
			}
		}	
		} catch (Exception e) {
		e.printStackTrace();
		} finally {
		try {
		write.close();
		read.close();
		} catch (IOException e) {
		e.printStackTrace();
		}
		}
	}
	
	public void processExcel(String filename,String txtfile)
	{
		
		File excelFile = new File(filename);
		BufferedWriter write = null;

		XSSFWorkbook wb;
		try {
			write = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(txtfile, true)));
			wb = new XSSFWorkbook(new FileInputStream(excelFile));			
			XSSFSheet sheet = wb.getSheetAt(0);	
			
			for (Row row : sheet) {
				Cell cell_start = row.getCell(1);
				Cell cell_end = row.getCell(2);
				int duration = Integer.parseInt(cell_end.getStringCellValue())-Integer.parseInt(cell_start.getStringCellValue());
				if(duration<=0) continue;
				Cell cell_num = row.getCell(0);
//				Cell cell_tasktype = row.getCell(3);
//				if(!cell_tasktype.getStringCellValue().equalsIgnoreCase("1")) continue;
				Cell cell_cpu = row.getCell(3);
				Cell cell_mem = row.getCell(4);
//				if(cell_tasktype.getNumericCellValue()==2)
				String line = cell_start.getStringCellValue()+"\t"+cell_end.getStringCellValue()+"\t"+duration+"\t"+cell_num.getStringCellValue()
								+"\t"+cell_cpu.getStringCellValue()+"\t"+cell_mem.getStringCellValue();
				write.write(line);
				write.write(""+"\r\n");
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			write.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AliDataProcess ap = new AliDataProcess();
		String source = "D:\\��������\\Dynamic_Instances_newFuzzy_Ali\\arrival_rate.txt";
		String target = "D:\\��������\\Dynamic_Instances_newFuzzy_Ali\\ali_instance2017_";
		ap.processArrivingRateProcess(source,target);
		
	}

}
